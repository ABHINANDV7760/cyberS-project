"""
database.py – SQLite persistence for CyberShield 360.

Uses parameterised queries throughout. Never stores file contents, URL query
strings, or API keys.

Schema migrations are additive only (ALTER TABLE ADD COLUMN IF NOT EXISTS).
The `init_db()` function is safe to call multiple times.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional

from config import DB_PATH
from models import Finding, RiskCategory, Scan


# ---------------------------------------------------------------------------
# Schema — core tables
# ---------------------------------------------------------------------------

_CREATE_SCANS = """
CREATE TABLE IF NOT EXISTS scans (
    scan_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    module           TEXT NOT NULL,
    target_label     TEXT NOT NULL,
    target_hash      TEXT,
    target_type      TEXT,
    risk_category    TEXT,
    score            REAL DEFAULT 0,
    is_simulated     INTEGER DEFAULT 0,
    duration_seconds REAL,
    scanned_at       TEXT NOT NULL
);
"""

_CREATE_FINDINGS = """
CREATE TABLE IF NOT EXISTS findings (
    finding_id_row  INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id      TEXT,                      -- UUID (may be NULL for old rows)
    scan_id         INTEGER NOT NULL REFERENCES scans(scan_id),
    rule_id         TEXT NOT NULL,
    title           TEXT NOT NULL,
    description     TEXT,
    risk_category   TEXT,
    confidence_note TEXT,
    remediation     TEXT,
    source          TEXT,
    input_type      TEXT DEFAULT 'file',
    is_simulated    INTEGER DEFAULT 0,
    evidence_json   TEXT,
    triggered_at    TEXT NOT NULL
);
"""

_CREATE_SETTINGS = """
CREATE TABLE IF NOT EXISTS settings (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
"""

# ---------------------------------------------------------------------------
# Migration helpers — add new columns to existing DBs without breaking them
# ---------------------------------------------------------------------------

# Each entry is (table, column, definition).
# We try to ALTER TABLE; if the column already exists SQLite raises an error
# which we swallow.
_MIGRATIONS: list[tuple[str, str, str]] = [
    ("scans",    "duration_seconds", "REAL"),
    ("findings", "finding_id",       "TEXT"),
    ("findings", "input_type",       "TEXT DEFAULT 'file'"),
]


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------

def _get_db_path() -> Path:
    return DB_PATH


@contextmanager
def _connect() -> Generator[sqlite3.Connection, None, None]:
    db_path = _get_db_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    """
    Create tables if they do not exist, then apply any pending column migrations.
    Safe to call multiple times — all operations are idempotent.
    """
    with _connect() as conn:
        conn.execute(_CREATE_SCANS)
        conn.execute(_CREATE_FINDINGS)
        conn.execute(_CREATE_SETTINGS)

        # Apply additive migrations (add missing columns to existing tables)
        for table, column, definition in _MIGRATIONS:
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
            except sqlite3.OperationalError:
                # Column already exists — that's fine
                pass


# ---------------------------------------------------------------------------
# Write helpers
# ---------------------------------------------------------------------------

def add_scan(scan: Scan) -> int:
    """
    Persist a Scan (without findings) and return the new scan_id.

    The target_label for URLs must have the query string stripped before
    calling this function (enforced by download_guard.py).
    """
    init_db()
    with _connect() as conn:
        cur = conn.execute(
            """
            INSERT INTO scans
                (module, target_label, target_hash, target_type,
                 risk_category, score, is_simulated, duration_seconds, scanned_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                scan.module,
                scan.target_label,
                scan.target_hash,
                scan.target_type,
                scan.risk_category.value if scan.risk_category else None,
                scan.score,
                1 if scan.is_simulated else 0,
                scan.duration_seconds,
                scan.scanned_at.isoformat(),
            ),
        )
        scan_id: int = cur.lastrowid  # type: ignore[assignment]
        scan.scan_id = scan_id
        return scan_id


def add_finding(scan_id: int, finding: Finding) -> int:
    """Persist a single Finding attached to an existing scan."""
    init_db()
    with _connect() as conn:
        cur = conn.execute(
            """
            INSERT INTO findings
                (finding_id, scan_id, rule_id, title, description, risk_category,
                 confidence_note, remediation, source, input_type, is_simulated,
                 evidence_json, triggered_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                finding.finding_id,
                scan_id,
                finding.rule_id,
                finding.title,
                finding.description,
                finding.risk_category.value,
                finding.confidence_note,
                finding.remediation,
                finding.source,
                finding.input_type,
                1 if finding.is_simulated else 0,
                json.dumps([e.__dict__ for e in finding.evidence]),
                finding.triggered_at.isoformat(),
            ),
        )
        return cur.lastrowid  # type: ignore[return-value]


def add_scan_with_findings(scan: Scan) -> int:
    """Convenience: persist scan + all findings, return scan_id."""
    scan_id = add_scan(scan)
    for finding in scan.findings:
        add_finding(scan_id, finding)
    return scan_id


# ---------------------------------------------------------------------------
# Settings helpers
# ---------------------------------------------------------------------------

def set_setting(key: str, value: Any) -> None:
    """
    Persist a key/value setting (string-serialised JSON).
    Replaces any existing value for that key.
    """
    init_db()
    with _connect() as conn:
        conn.execute(
            """
            INSERT INTO settings (key, value, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
            """,
            (key, json.dumps(value), datetime.utcnow().isoformat()),
        )


def get_setting(key: str, default: Any = None) -> Any:
    """Return the stored value for *key*, or *default* if not present."""
    init_db()
    with _connect() as conn:
        row = conn.execute(
            "SELECT value FROM settings WHERE key = ?", (key,)
        ).fetchone()
    if row is None:
        return default
    return json.loads(row["value"])


# ---------------------------------------------------------------------------
# Read helpers
# ---------------------------------------------------------------------------

def get_recent_scans(module: Optional[str] = None, limit: int = 50) -> List[dict]:
    """Return the most recent scans, optionally filtered by module."""
    init_db()
    with _connect() as conn:
        if module:
            rows = conn.execute(
                "SELECT * FROM scans WHERE module = ? ORDER BY scan_id DESC LIMIT ?",
                (module, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM scans ORDER BY scan_id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]


def get_findings_for_scan(scan_id: int) -> List[dict]:
    """Return all findings for a given scan_id."""
    init_db()
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM findings WHERE scan_id = ? ORDER BY finding_id_row",
            (scan_id,),
        ).fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Deletion / retention helpers
# ---------------------------------------------------------------------------

def delete_scan(scan_id: int) -> bool:
    """
    Delete a single scan and all its findings.
    Returns True if a scan was deleted, False if the scan_id was not found.

    Foreign key cascade is NOT relied upon here — findings are deleted first
    so this function works even if the SQLite build omits FK support.
    """
    init_db()
    with _connect() as conn:
        conn.execute("DELETE FROM findings WHERE scan_id = ?", (scan_id,))
        result = conn.execute("DELETE FROM scans WHERE scan_id = ?", (scan_id,))
        return result.rowcount > 0


def delete_scans_older_than(days: int, module: Optional[str] = None) -> int:
    """
    Delete scans (and their findings) older than *days* days.

    Args:
        days:   Retain scans no older than this many days.
        module: If given, restrict deletion to that module only.

    Returns:
        Number of scans deleted.
    """
    if days < 0:
        raise ValueError("days must be non-negative")

    init_db()
    # Calculate the cutoff ISO timestamp
    from datetime import timedelta
    cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()

    with _connect() as conn:
        if module:
            old_ids = [
                row[0]
                for row in conn.execute(
                    "SELECT scan_id FROM scans WHERE scanned_at < ? AND module = ?",
                    (cutoff, module),
                ).fetchall()
            ]
        else:
            old_ids = [
                row[0]
                for row in conn.execute(
                    "SELECT scan_id FROM scans WHERE scanned_at < ?", (cutoff,)
                ).fetchall()
            ]

        if not old_ids:
            return 0

        placeholders = ",".join("?" * len(old_ids))
        conn.execute(
            f"DELETE FROM findings WHERE scan_id IN ({placeholders})", old_ids
        )
        conn.execute(
            f"DELETE FROM scans WHERE scan_id IN ({placeholders})", old_ids
        )
        return len(old_ids)
