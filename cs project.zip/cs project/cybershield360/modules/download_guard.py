"""
modules/download_guard.py – Core analysis logic for the Download Guard module.

This module provides:
  - detect_type()     : magic-byte signature detection
  - sha256_file()     : chunked SHA-256 computation
  - shannon_entropy() : entropy calculation over a byte sample
  - analyze_file()    : full local file analysis → list[Finding]
  - analyze_folder()  : recursive folder scan → list[FileRecord]
  - analyze_url()     : URL metadata analysis → list[Finding]

SAFETY GUARANTEES (hard requirements):
  * This module NEVER writes, moves, renames, deletes, executes, opens, or
    previews any file or downloaded content.
  * Files are opened in "rb" mode only; reads are capped at FILE_CHUNK_SIZE.
  * No eval / exec / subprocess / os.system / pickle on any input.
  * All outbound HTTP goes through utils.safe_fetch.fetch_url_metadata().
  * File names and header values are never passed to unsafe_allow_html.
"""
from __future__ import annotations

import hashlib
import math
import os
import stat
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Generator, List, Optional, Tuple

from config import (
    FILE_CHUNK_SIZE,
    FILE_EMPTY_THRESHOLD_BYTES,
    FILE_ENTROPY_THRESHOLD,
    FILE_ENTROPY_WINDOW,
    FILE_MAX_SIZE_BYTES,
    FOLDER_MAX_DEPTH,
    FOLDER_MAX_FILES,
    MODULE_DOWNLOAD_GUARD,
)
from engine.risk_engine import RULE_DEFINITIONS
from models import Evidence, Finding, RiskCategory
from utils.logging_utils import safe_event


# ---------------------------------------------------------------------------
# Detected-type dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class DetectedType:
    name: str           # Short label, e.g. "PE Executable"
    group: str          # Broad group: "executable", "document", "archive", "image", "text", "unknown"
    mime_hint: str = "" # e.g. "application/x-dosexec"


UNKNOWN_TYPE = DetectedType(name="Unknown", group="unknown")


# ---------------------------------------------------------------------------
# Magic byte table
# ---------------------------------------------------------------------------
# Each entry: (label, group, mime_hint, offset, magic_bytes)
# offset is the byte offset within the file where the magic bytes appear.

_MAGIC_TABLE: List[Tuple[str, str, str, int, bytes]] = [
    # Executables
    ("PE Executable (EXE/DLL)",  "executable", "application/x-dosexec",    0, b"MZ"),
    ("ELF Executable",            "executable", "application/x-elf",         0, b"\x7fELF"),
    ("Mach-O 32-bit",             "executable", "application/x-mach-binary", 0, b"\xfe\xed\xfa\xce"),
    ("Mach-O 64-bit",             "executable", "application/x-mach-binary", 0, b"\xfe\xed\xfa\xcf"),
    ("Mach-O 32-bit (reversed)",  "executable", "application/x-mach-binary", 0, b"\xce\xfa\xed\xfe"),
    ("Mach-O 64-bit (reversed)",  "executable", "application/x-mach-binary", 0, b"\xcf\xfa\xed\xfe"),
    ("Mach-O Universal Binary",   "executable", "application/x-mach-binary", 0, b"\xca\xfe\xba\xbe"),
    # Documents
    ("PDF Document",              "document",   "application/pdf",           0, b"%PDF"),
    ("RTF Document",              "document",   "application/rtf",           0, b"{\\rtf"),
    ("OLE2 (Legacy Office/MSI)",  "document",   "application/x-ole-storage", 0, b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"),
    # Archives / containers (ZIP last so Office formats matched by extension)
    ("RAR Archive",               "archive",    "application/x-rar",         0, b"Rar!"),
    ("7-Zip Archive",             "archive",    "application/x-7z-compressed",0, b"7z\xbc\xaf\x27\x1c"),
    ("GZIP Archive",              "archive",    "application/gzip",          0, b"\x1f\x8b"),
    ("BZIP2 Archive",             "archive",    "application/x-bzip2",       0, b"BZh"),
    ("XZ Archive",                "archive",    "application/x-xz",          0, b"\xfd7zXZ\x00"),
    ("ZIP Archive",               "archive",    "application/zip",           0, b"PK\x03\x04"),
    ("ZIP (empty)",               "archive",    "application/zip",           0, b"PK\x05\x06"),
    ("ZIP (spanned)",             "archive",    "application/zip",           0, b"PK\x07\x08"),
    # Images
    ("PNG Image",                 "image",      "image/png",                 0, b"\x89PNG\r\n\x1a\n"),
    ("JPEG Image",                "image",      "image/jpeg",                0, b"\xff\xd8\xff"),
    ("GIF Image",                 "image",      "image/gif",                 0, b"GIF87a"),
    ("GIF Image",                 "image",      "image/gif",                 0, b"GIF89a"),
    ("BMP Image",                 "image",      "image/bmp",                 0, b"BM"),
    # Windows LNK shortcut
    ("Windows LNK Shortcut",      "executable", "application/x-ms-shortcut", 0,
     b"\x4c\x00\x00\x00\x01\x14\x02\x00"),
    # ISO (sector 16 contains the volume descriptor; check bytes 32769–32772)
    # Handled separately due to non-zero offset
]

# ISO detection offset
_ISO_OFFSET = 32769
_ISO_MAGIC = b"CD001"


def detect_type(header_bytes: bytes) -> Optional[DetectedType]:
    """
    Detect the file type from its leading bytes (magic numbers).

    Parameters
    ----------
    header_bytes:
        At least the first 256 bytes of the file (more is better).
        Pass an empty bytes object for an empty file.

    Returns
    -------
    DetectedType if a signature matched, None if nothing matched (unknown).

    Note: ZIP-based Office formats (docx, xlsx, pptx, jar, apk) share the
    ZIP magic bytes. Callers should use extension + signature together to
    identify them precisely.
    """
    if not header_bytes:
        return None

    # Standard offset-0 magic checks
    for name, group, mime, offset, magic in _MAGIC_TABLE:
        end = offset + len(magic)
        if len(header_bytes) >= end and header_bytes[offset:end] == magic:
            return DetectedType(name=name, group=group, mime_hint=mime)

    # ISO: offset 32769 — only if caller passed enough bytes
    if (
        len(header_bytes) >= _ISO_OFFSET + len(_ISO_MAGIC)
        and header_bytes[_ISO_OFFSET: _ISO_OFFSET + len(_ISO_MAGIC)] == _ISO_MAGIC
    ):
        return DetectedType(
            name="ISO Disk Image",
            group="archive",
            mime_hint="application/x-iso9660-image",
        )

    # Shebang script
    if header_bytes[:2] == b"#!":
        return DetectedType(
            name="Script (shebang)",
            group="executable",
            mime_hint="text/x-shellscript",
        )

    # Plain text / UTF-8 heuristic (no null bytes in first 512 bytes)
    sample = header_bytes[:512]
    if b"\x00" not in sample:
        try:
            sample.decode("utf-8")
            return DetectedType(name="Plain Text / UTF-8", group="text", mime_hint="text/plain")
        except UnicodeDecodeError:
            pass

    return None


# ---------------------------------------------------------------------------
# Extension → expected group mapping
# ---------------------------------------------------------------------------

# Extensions mapped to the group they should belong to.
_EXT_TO_GROUP: Dict[str, str] = {
    # Documents
    ".pdf": "document", ".doc": "document", ".docx": "document",
    ".xls": "document", ".xlsx": "document", ".ppt": "document",
    ".pptx": "document", ".odt": "document", ".ods": "document",
    ".odp": "document", ".rtf": "document", ".txt": "text",
    ".csv": "text",    ".json": "text",   ".xml": "text",
    ".html": "text",   ".htm": "text",    ".md": "text",
    # Images
    ".png": "image",   ".jpg": "image",   ".jpeg": "image",
    ".gif": "image",   ".bmp": "image",   ".tiff": "image",
    ".tif": "image",   ".svg": "image",   ".webp": "image",
    # Archives
    ".zip": "archive", ".rar": "archive", ".7z": "archive",
    ".gz": "archive",  ".tar": "archive", ".bz2": "archive",
    ".xz": "archive",  ".iso": "archive", ".img": "archive",
    # Executables
    ".exe": "executable", ".dll": "executable", ".elf": "executable",
    ".scr": "executable", ".bat": "executable", ".cmd": "executable",
    ".ps1": "executable", ".vbs": "executable", ".js": "executable",
    ".jse": "executable", ".wsf": "executable", ".hta": "executable",
    ".msi": "executable", ".lnk": "executable", ".com": "executable",
    ".reg": "executable", ".sh": "executable",  ".bin": "executable",
    # ZIP-based Office / mobile (signature is ZIP but extension identifies type)
    ".docm": "document", ".xlsm": "document", ".pptm": "document",
    ".jar": "archive",   ".apk": "archive",
}

# Extensions considered "risky" (rule FILE-RISKY-EXT)
_RISKY_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".exe", ".scr", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jse",
        ".wsf", ".hta", ".msi", ".lnk", ".jar", ".iso", ".img",
        ".dll", ".com", ".reg",
    }
)

# Extensions capable of carrying macros (rule FILE-MACRO-CAPABLE)
_MACRO_CAPABLE_EXTENSIONS: frozenset[str] = frozenset(
    {".docm", ".xlsm", ".pptm", ".doc", ".xls", ".ppt"}
)

# Invisible / bidirectional control characters that can disguise file names
_BIDI_CHARS: frozenset[int] = frozenset(
    {
        0x202E,  # RIGHT-TO-LEFT OVERRIDE
        0x202D,  # LEFT-TO-RIGHT OVERRIDE
        0x202C,  # POP DIRECTIONAL FORMATTING
        0x202B,  # RIGHT-TO-LEFT EMBEDDING
        0x202A,  # LEFT-TO-RIGHT EMBEDDING
        0x200F,  # RIGHT-TO-LEFT MARK
        0x200E,  # LEFT-TO-RIGHT MARK
        0x2066,  # LEFT-TO-RIGHT ISOLATE
        0x2067,  # RIGHT-TO-LEFT ISOLATE
        0x2069,  # POP DIRECTIONAL ISOLATE
        0x00AD,  # SOFT HYPHEN (invisible)
        0x200B,  # ZERO WIDTH SPACE
        0x200C,  # ZERO WIDTH NON-JOINER
        0x200D,  # ZERO WIDTH JOINER
        0xFEFF,  # BOM / ZERO WIDTH NO-BREAK SPACE
    }
)


# ---------------------------------------------------------------------------
# SHA-256 (chunked)
# ---------------------------------------------------------------------------

def sha256_file(data: bytes) -> str:
    """
    Compute SHA-256 of bytes already in memory.
    Use sha256_stream() for large files.
    """
    return hashlib.sha256(data).hexdigest()


def sha256_stream(
    read_fn: Callable[[int], bytes],
    chunk_size: int = FILE_CHUNK_SIZE,
) -> str:
    """
    Compute SHA-256 by calling read_fn(chunk_size) repeatedly until b'' is returned.
    Never loads the whole file at once.
    """
    h = hashlib.sha256()
    while True:
        chunk = read_fn(chunk_size)
        if not chunk:
            break
        h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Shannon entropy
# ---------------------------------------------------------------------------

def shannon_entropy(data: bytes) -> float:
    """
    Compute Shannon entropy (bits per byte) over ``data``.
    Returns 0.0 for empty input. Maximum is 8.0.
    """
    if not data:
        return 0.0
    n = len(data)
    counts: Dict[int, int] = {}
    for byte in data:
        counts[byte] = counts.get(byte, 0) + 1
    entropy = 0.0
    for count in counts.values():
        p = count / n
        entropy -= p * math.log2(p)
    return entropy


# ---------------------------------------------------------------------------
# File analysis
# ---------------------------------------------------------------------------

def _get_stem_extensions(filename: str) -> List[str]:
    """Return all extensions from a filename as lowercase strings, e.g. ['pdf', 'exe']."""
    # pathlib only gives the final extension; we need all of them
    parts = filename.lower().split(".")
    if len(parts) <= 1:
        return []
    return ["." + p for p in parts[1:] if p]


def _has_bidi_char(text: str) -> Tuple[bool, str]:
    """Return (found, description)."""
    found_chars = []
    for ch in text:
        if ord(ch) in _BIDI_CHARS:
            found_chars.append(f"U+{ord(ch):04X} ({ch!r})")
    if found_chars:
        return True, ", ".join(found_chars[:5])
    return False, ""


def analyze_file(
    filename: str,
    file_bytes: bytes,
    source: str = "local analysis",
    is_simulated: bool = False,
) -> List[Finding]:
    """
    Analyse a file's bytes and filename; produce a list of Findings.

    Parameters
    ----------
    filename:
        Original file name (basename only; never a full path).
    file_bytes:
        File content. May be any size up to FILE_MAX_SIZE_BYTES; callers
        should read at most that many bytes.
    source:
        Label for the Finding.source field.
    is_simulated:
        True for demo/synthetic fixtures.

    Returns
    -------
    List of Finding objects. May be empty if no rules fire.

    SAFETY: This function never writes, executes, or opens any file.
    """
    findings: List[Finding] = []
    ext_list = _get_stem_extensions(filename)
    final_ext = ext_list[-1] if ext_list else ""
    all_exts = ext_list

    # 1. SHA-256 (from bytes already in memory; stream variant used by folder scan)
    file_hash = sha256_file(file_bytes)

    # 2. Magic-byte detection (use first 256 bytes + ISO needs more)
    header = file_bytes[: max(256, _ISO_OFFSET + len(_ISO_MAGIC))]
    detected = detect_type(header)

    # 3. Empty / truncated check
    file_size = len(file_bytes)
    if file_size == 0:
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-EMPTY-OR-TRUNCATED",
                title=RULE_DEFINITIONS["FILE-EMPTY-OR-TRUNCATED"].title,
                description="File is zero bytes.",
                risk_category=RiskCategory.LOW,
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", filename),
                    Evidence("File size", "0 bytes"),
                ],
            )
        )
        return findings  # nothing more to check

    # 4. RTLO / bidi check
    has_bidi, bidi_detail = _has_bidi_char(filename)
    if has_bidi:
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-RTLO",
                title=RULE_DEFINITIONS["FILE-RTLO"].title,
                description=(
                    f"File name contains bidirectional/invisible control character(s): {bidi_detail}"
                ),
                risk_category=RiskCategory.HIGH,
                confidence_note="Automatic detection; visually inspect the raw file name.",
                remediation=(
                    "Do not open this file. Verify the true file name with a hex editor "
                    "or terminal. Ask the sender to confirm the file over an official channel."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", repr(filename)),
                    Evidence("Control characters found", bidi_detail),
                ],
            )
        )

    # 5. Double extension check
    if len(all_exts) >= 2:
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-DOUBLE-EXT",
                title=RULE_DEFINITIONS["FILE-DOUBLE-EXT"].title,
                description=(
                    f"File has multiple extensions: {', '.join(all_exts)}. "
                    "The displayed extension may not be the active one."
                ),
                risk_category=RiskCategory.HIGH,
                confidence_note="Heuristic: multiple dots in filename.",
                remediation=(
                    "Verify the true extension of the file. Do not open it if the "
                    "last extension is an executable type."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", filename),
                    Evidence("All extensions", ", ".join(all_exts)),
                    Evidence("Final (active) extension", final_ext),
                ],
            )
        )

    # Check trailing dots/spaces in extension
    raw_final = all_exts[-1] if all_exts else ""
    if raw_final.endswith((" ", ".")):
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-DOUBLE-EXT",
                title=RULE_DEFINITIONS["FILE-DOUBLE-EXT"].title,
                description=(
                    f"File extension ends with a trailing space or dot: {raw_final!r}. "
                    "This can hide the real extension on some systems."
                ),
                risk_category=RiskCategory.HIGH,
                source=source,
                is_simulated=is_simulated,
                evidence=[Evidence("File name", filename)],
            )
        )

    # 6. Executable signature detection
    is_exec_sig = detected is not None and detected.group == "executable"

    # 6a. FILE-EXEC-DISGUISED: executable signature + non-executable extension
    expected_group = _EXT_TO_GROUP.get(final_ext, "unknown")
    if is_exec_sig and expected_group not in ("executable", "unknown", ""):
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-EXEC-DISGUISED",
                title=RULE_DEFINITIONS["FILE-EXEC-DISGUISED"].title,
                description=(
                    f"File has an executable signature ({detected.name}) "
                    f"but its extension ({final_ext!r}) suggests it is a {expected_group}. "
                    "This is a common malware delivery technique."
                ),
                risk_category=RiskCategory.HIGH,
                confidence_note=(
                    "Magic-byte detection is heuristic. Some legitimate tools embed "
                    "PE stubs in non-executable containers."
                ),
                remediation=(
                    "Do not open this file. Verify with the publisher over an official "
                    "channel. Compare the hash with the publisher's published hash. "
                    "Scan with up-to-date endpoint protection or a sandbox."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", filename),
                    Evidence("Detected signature", detected.name),
                    Evidence("Extension", final_ext),
                    Evidence("Expected type group for extension", expected_group),
                    Evidence("SHA-256", file_hash),
                ],
            )
        )

    # 7. FILE-RISKY-EXT
    if final_ext in _RISKY_EXTENSIONS and "FILE-EXEC-DISGUISED" not in {f.rule_id for f in findings}:
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-RISKY-EXT",
                title=RULE_DEFINITIONS["FILE-RISKY-EXT"].title,
                description=(
                    f"The extension {final_ext!r} belongs to a high-risk category "
                    "frequently used for malicious code delivery."
                ),
                risk_category=RiskCategory.MEDIUM,
                remediation=(
                    "Verify this file is expected from a trusted publisher. "
                    "Scan with up-to-date endpoint protection before running."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", filename),
                    Evidence("Extension", final_ext),
                ],
            )
        )

    # 8. FILE-MACRO-CAPABLE
    if final_ext in _MACRO_CAPABLE_EXTENSIONS or (
        detected is not None and detected.name == "OLE2 (Legacy Office/MSI)"
    ):
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-MACRO-CAPABLE",
                title=RULE_DEFINITIONS["FILE-MACRO-CAPABLE"].title,
                description=(
                    "This file format can contain embedded macros. "
                    "Macros are a common malware delivery vector."
                ),
                risk_category=RiskCategory.MEDIUM,
                confidence_note=(
                    "The presence of the macro-capable format is noted. "
                    "Whether macros are actually present is not checked by this tool."
                ),
                remediation=(
                    "Disable macro execution in your Office application. "
                    "Do not enable macros unless you trust the source."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", filename),
                    Evidence("Extension", final_ext),
                    Evidence(
                        "Detected signature",
                        detected.name if detected else "Not detected",
                    ),
                ],
            )
        )

    # 9. FILE-ARCHIVE-UNINSPECTED
    if detected is not None and detected.group == "archive" and final_ext not in (
        ".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".pptm", ".jar", ".apk"
    ):
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-ARCHIVE-UNINSPECTED",
                title=RULE_DEFINITIONS["FILE-ARCHIVE-UNINSPECTED"].title,
                description=(
                    f"This file is an archive ({detected.name}). "
                    "Its contents were NOT inspected. "
                    "Malicious content inside the archive cannot be ruled out."
                ),
                risk_category=RiskCategory.LOW,
                confidence_note="Archive contents are never extracted by this tool.",
                remediation=(
                    "Scan the archive with up-to-date endpoint protection "
                    "before extracting. Never extract archives from untrusted sources "
                    "without verification."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", filename),
                    Evidence("Detected archive type", detected.name),
                ],
            )
        )

    # 10. FILE-TYPE-MISMATCH (non-executable cases not already covered)
    if (
        detected is not None
        and final_ext
        and expected_group not in ("unknown", "")
        and detected.group != expected_group
        and "FILE-EXEC-DISGUISED" not in {f.rule_id for f in findings}
    ):
        # ZIP-based Office formats are consistent
        zip_based_office = detected.group == "archive" and final_ext in (
            ".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".pptm", ".jar", ".apk"
        )
        if not zip_based_office:
            findings.append(
                Finding(
                    module=MODULE_DOWNLOAD_GUARD,
                    rule_id="FILE-TYPE-MISMATCH",
                    title=RULE_DEFINITIONS["FILE-TYPE-MISMATCH"].title,
                    description=(
                        f"The extension {final_ext!r} suggests a {expected_group} file, "
                        f"but the detected signature is {detected.name!r} ({detected.group})."
                    ),
                    risk_category=RiskCategory.LOW,
                    confidence_note="Magic-byte detection is heuristic.",
                    remediation=(
                        "Verify the file type with the publisher. "
                        "Do not open files whose declared type does not match their content."
                    ),
                    source=source,
                    is_simulated=is_simulated,
                    evidence=[
                        Evidence("File name", filename),
                        Evidence("Extension", final_ext),
                        Evidence("Expected type group", expected_group),
                        Evidence("Detected signature", detected.name),
                        Evidence("Detected group", detected.group),
                    ],
                )
            )

    # 11. FILE-HIGH-ENTROPY
    entropy_sample = file_bytes[:FILE_ENTROPY_WINDOW]
    entropy = shannon_entropy(entropy_sample)
    if entropy >= FILE_ENTROPY_THRESHOLD:
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-HIGH-ENTROPY",
                title=RULE_DEFINITIONS["FILE-HIGH-ENTROPY"].title,
                description=(
                    f"Shannon entropy of the first {len(entropy_sample):,} bytes: "
                    f"{entropy:.3f} bits/byte (threshold: {FILE_ENTROPY_THRESHOLD}). "
                    "This is consistent with packed, compressed, or encrypted content, "
                    "but also with normal compressed files."
                ),
                risk_category=RiskCategory.INFORMATIONAL,
                confidence_note=(
                    "High entropy alone is not a reliable indicator. "
                    "Normal ZIP/GZIP/JPEG files also score high. "
                    "Consider together with other signals."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", filename),
                    Evidence("Entropy", f"{entropy:.4f} bits/byte"),
                    Evidence("Sample size", f"{len(entropy_sample):,} bytes"),
                ],
            )
        )

    # 12. FILE-CONSISTENT (informational, only when no mismatch found)
    mismatch_rules = {"FILE-EXEC-DISGUISED", "FILE-TYPE-MISMATCH"}
    triggered = {f.rule_id for f in findings}
    if detected is not None and final_ext and not (mismatch_rules & triggered):
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="FILE-CONSISTENT",
                title=RULE_DEFINITIONS["FILE-CONSISTENT"].title,
                description=(
                    f"The extension {final_ext!r} and the detected signature "
                    f"({detected.name}) are consistent. "
                    "This is informational only and does not indicate the file is safe."
                ),
                risk_category=RiskCategory.INFORMATIONAL,
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("File name", filename),
                    Evidence("Detected type", detected.name),
                ],
            )
        )

    safe_event(
        "download_guard.file_analyzed",
        extra={
            "filename": filename,
            "size": file_size,
            "findings": len(findings),
        },
    )
    return findings


# ---------------------------------------------------------------------------
# Folder scan
# ---------------------------------------------------------------------------

@dataclass
class FileRecord:
    rel_path: str
    size_bytes: int
    detected_type: str
    sha256: Optional[str]
    risk_category: Optional[str]
    triggered_rules: List[str]
    skipped_reason: Optional[str] = None
    findings: List[Finding] = field(default_factory=list)


def walk_folder(
    root: Path,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    cancel_flag: Optional[Callable[[], bool]] = None,
) -> Generator[FileRecord, None, None]:
    """
    Walk ``root`` recursively, yielding FileRecord for each file.

    Safety guards:
    - followlinks=False (never follows symlinks)
    - Skips symlinks, device files, FIFOs, sockets
    - Caps total files at FOLDER_MAX_FILES
    - Caps per-file size at FILE_MAX_SIZE_BYTES
    - Caps depth at FOLDER_MAX_DEPTH
    - Opens files in "rb" mode only
    - Unreadable files are yielded as skipped, never crash
    - progress_callback(processed_count, total_estimate) called per file
    - cancel_flag(): return True to stop the walk early

    Parameters
    ----------
    root:
        Absolute resolved path to the directory.
    progress_callback:
        Called with (files_processed, total_estimate) after each file.
    cancel_flag:
        Called before processing each file; if True, walk is stopped.
    """
    total_processed = 0
    root_depth = len(root.parts)

    for dirpath, dirnames, filenames in os.walk(str(root), followlinks=False):
        current_depth = len(Path(dirpath).parts) - root_depth
        if current_depth >= FOLDER_MAX_DEPTH:
            dirnames.clear()  # prune deeper traversal
            continue

        # Sort for determinism
        dirnames.sort()
        filenames.sort()

        for fname in filenames:
            if cancel_flag and cancel_flag():
                return

            if total_processed >= FOLDER_MAX_FILES:
                yield FileRecord(
                    rel_path="[SCAN LIMIT REACHED]",
                    size_bytes=0,
                    detected_type="",
                    sha256=None,
                    risk_category=None,
                    triggered_rules=[],
                    skipped_reason=(
                        f"Scan stopped: {FOLDER_MAX_FILES} file limit reached."
                    ),
                )
                return

            fpath = Path(dirpath) / fname
            rel = str(fpath.relative_to(root))

            # Skip symlinks
            try:
                st = fpath.lstat()
            except OSError as exc:
                yield FileRecord(
                    rel_path=rel,
                    size_bytes=0,
                    detected_type="",
                    sha256=None,
                    risk_category=None,
                    triggered_rules=[],
                    skipped_reason=f"stat error: {exc}",
                )
                total_processed += 1
                continue

            mode = st.st_mode
            if stat.S_ISLNK(mode):
                yield FileRecord(
                    rel_path=rel,
                    size_bytes=0,
                    detected_type="",
                    sha256=None,
                    risk_category=None,
                    triggered_rules=[],
                    skipped_reason="skipped: symbolic link",
                )
                total_processed += 1
                continue
            if not stat.S_ISREG(mode):
                yield FileRecord(
                    rel_path=rel,
                    size_bytes=0,
                    detected_type="",
                    sha256=None,
                    risk_category=None,
                    triggered_rules=[],
                    skipped_reason="skipped: not a regular file (device/FIFO/socket)",
                )
                total_processed += 1
                continue

            # Size cap
            file_size = st.st_size
            if file_size > FILE_MAX_SIZE_BYTES:
                yield FileRecord(
                    rel_path=rel,
                    size_bytes=file_size,
                    detected_type="",
                    sha256=None,
                    risk_category=None,
                    triggered_rules=[],
                    skipped_reason=(
                        f"skipped: file exceeds {FILE_MAX_SIZE_BYTES // (1024*1024)} MB limit"
                    ),
                )
                total_processed += 1
                if progress_callback:
                    progress_callback(total_processed, total_processed)
                continue

            # Read file (rb only, chunked)
            try:
                with open(str(fpath), "rb") as fh:
                    file_bytes = fh.read(FILE_MAX_SIZE_BYTES)
            except OSError as exc:
                yield FileRecord(
                    rel_path=rel,
                    size_bytes=file_size,
                    detected_type="",
                    sha256=None,
                    risk_category=None,
                    triggered_rules=[],
                    skipped_reason=f"skipped: unreadable — {exc}",
                )
                total_processed += 1
                continue

            # Analyze
            from engine.risk_engine import compute_score  # avoid circular at module level

            findings = analyze_file(fname, file_bytes)
            score_result = compute_score(findings)
            detected_obj = detect_type(file_bytes[:256])

            record = FileRecord(
                rel_path=rel,
                size_bytes=len(file_bytes),
                detected_type=detected_obj.name if detected_obj else "Unknown",
                sha256=sha256_file(file_bytes),
                risk_category=score_result.category.value,
                triggered_rules=[f.rule_id for f in findings],
                findings=findings,
            )

            total_processed += 1
            if progress_callback:
                progress_callback(total_processed, total_processed)

            yield record


# ---------------------------------------------------------------------------
# URL analysis
# ---------------------------------------------------------------------------

def analyze_url(
    url: str,
    fetch_result,  # FetchResult from utils.safe_fetch
    source: str = "safe_fetch",
    is_simulated: bool = False,
) -> List[Finding]:
    """
    Produce Findings from a FetchResult returned by safe_fetch.fetch_url_metadata().

    Parameters
    ----------
    url:
        The original URL (will be stored defanged).
    fetch_result:
        A FetchResult object.
    source:
        Label for Finding.source.
    is_simulated:
        True for demo entries.

    Returns
    -------
    List of Findings representing URL-level risks.
    """
    from utils.safe_fetch import defang_url  # avoid circular
    findings: List[Finding] = []

    # SSRF block
    if fetch_result.blocked:
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="URL-SSRF-BLOCKED",
                title=RULE_DEFINITIONS["URL-SSRF-BLOCKED"].title,
                description=(
                    f"The URL was blocked: {fetch_result.block_reason}. "
                    "No network request was sent."
                ),
                risk_category=RiskCategory.BLOCKED,
                remediation=(
                    "This URL resolves to an internal/private address. "
                    "Do not attempt to access it. Report to your security team if unexpected."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("URL (defanged)", defang_url(url)),
                    Evidence("Block reason", fetch_result.block_reason),
                ],
            )
        )
        return findings

    # Redirect chain signals
    for i, hop in enumerate(fetch_result.redirect_chain or []):
        if hop.https_downgrade:
            findings.append(
                Finding(
                    module=MODULE_DOWNLOAD_GUARD,
                    rule_id="URL-REDIRECT-HTTPS-DOWNGRADE",
                    title=RULE_DEFINITIONS["URL-REDIRECT-HTTPS-DOWNGRADE"].title,
                    description=(
                        f"Hop {i + 1} downgrades from HTTPS to HTTP. "
                        "Subsequent communication is unencrypted."
                    ),
                    risk_category=RiskCategory.MEDIUM,
                    source=source,
                    is_simulated=is_simulated,
                    evidence=[
                        Evidence("Hop", str(i + 1)),
                        Evidence("URL (defanged)", hop.url),
                    ],
                )
            )
        if hop.cross_domain and i > 0:
            findings.append(
                Finding(
                    module=MODULE_DOWNLOAD_GUARD,
                    rule_id="URL-REDIRECT-CROSS-DOMAIN",
                    title=RULE_DEFINITIONS["URL-REDIRECT-CROSS-DOMAIN"].title,
                    description=f"Hop {i + 1} redirects to a different domain.",
                    risk_category=RiskCategory.LOW,
                    source=source,
                    is_simulated=is_simulated,
                    evidence=[
                        Evidence("Hop", str(i + 1)),
                        Evidence("URL (defanged)", hop.url),
                    ],
                )
            )
        if hop.ip_literal_redirect:
            findings.append(
                Finding(
                    module=MODULE_DOWNLOAD_GUARD,
                    rule_id="URL-REDIRECT-IP-LITERAL",
                    title=RULE_DEFINITIONS["URL-REDIRECT-IP-LITERAL"].title,
                    description=f"Hop {i + 1} redirects to an IP-literal address.",
                    risk_category=RiskCategory.MEDIUM,
                    source=source,
                    is_simulated=is_simulated,
                    evidence=[
                        Evidence("Hop", str(i + 1)),
                        Evidence("URL (defanged)", hop.url),
                    ],
                )
            )

    # Content-Type / extension / Content-Disposition mismatch
    if fetch_result.success:
        _check_content_type_mismatch(url, fetch_result, findings, source, is_simulated)

    return findings


def _ext_from_url(url: str) -> str:
    """Extract the file extension from a URL path."""
    from urllib.parse import urlparse
    path = urlparse(url).path.lower()
    if "." in path:
        return "." + path.rsplit(".", 1)[-1]
    return ""


def _ext_from_content_disposition(cd: str) -> str:
    """Extract filename extension from Content-Disposition header."""
    import re
    m = re.search(r'filename\*?=(?:UTF-8\'\')?["\']?([^\s;"\']+)', cd, re.IGNORECASE)
    if m:
        fname = m.group(1).strip('"\'')
        if "." in fname:
            return "." + fname.rsplit(".", 1)[-1].lower()
    return ""


def _check_content_type_mismatch(
    url: str,
    fetch_result,
    findings: List[Finding],
    source: str,
    is_simulated: bool,
) -> None:
    from utils.safe_fetch import defang_url

    url_ext = _ext_from_url(url)
    ct_ext = ""
    cd_ext = ""

    ct = (fetch_result.content_type or "").lower().split(";")[0].strip()
    cd = fetch_result.content_disposition or ""

    # Map common content-types to extensions
    ct_to_ext = {
        "application/pdf": ".pdf",
        "application/zip": ".zip",
        "application/x-zip-compressed": ".zip",
        "application/x-7z-compressed": ".7z",
        "application/x-rar-compressed": ".rar",
        "application/x-dosexec": ".exe",
        "application/x-msdownload": ".exe",
        "application/x-executable": ".exe",
        "application/x-msi": ".msi",
        "application/x-iso9660-image": ".iso",
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/gif": ".gif",
        "text/plain": ".txt",
        "text/html": ".html",
    }
    ct_ext = ct_to_ext.get(ct, "")

    if cd:
        cd_ext = _ext_from_content_disposition(cd)

    mismatches = []
    if url_ext and ct_ext and url_ext != ct_ext:
        mismatches.append(f"URL extension {url_ext!r} vs Content-Type {ct!r} (implies {ct_ext!r})")
    if url_ext and cd_ext and url_ext != cd_ext:
        mismatches.append(f"URL extension {url_ext!r} vs Content-Disposition filename extension {cd_ext!r}")
    if ct_ext and cd_ext and ct_ext != cd_ext:
        mismatches.append(f"Content-Type {ct!r} vs Content-Disposition filename extension {cd_ext!r}")

    if mismatches:
        findings.append(
            Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="URL-CONTENT-TYPE-MISMATCH",
                title=RULE_DEFINITIONS["URL-CONTENT-TYPE-MISMATCH"].title,
                description=(
                    "Mismatch detected between URL extension, Content-Type, "
                    "and/or Content-Disposition filename: "
                    + "; ".join(mismatches)
                ),
                risk_category=RiskCategory.LOW,
                confidence_note=(
                    "Content-Type is server-declared; it may be wrong or deliberately misleading."
                ),
                remediation=(
                    "Verify the file type with the publisher before opening."
                ),
                source=source,
                is_simulated=is_simulated,
                evidence=[
                    Evidence("URL (defanged)", defang_url(url)),
                    Evidence("URL extension", url_ext or "(none)"),
                    Evidence("Content-Type", ct or "(none)"),
                    Evidence("Content-Disposition", cd or "(none)"),
                ],
            )
        )
