"""
modules/fraud_call_detector.py – Core analysis logic for the Fraud Call Detector.

What this module does
---------------------
Analyses a pasted call transcript (plain text) for patterns associated with
social-engineering and scam calls. It applies a set of documented rule
definitions, returns Finding objects, and highlights the exact matched phrases.

What this module does NOT do
-----------------------------
* It NEVER listens to, records, or retains audio.
* It NEVER claims to identify the caller by voice or phone number.
* It NEVER accesses call logs, contacts, or phone APIs.
* It NEVER performs any network activity.
* It NEVER claims the call is "definitely a scam". Every result is a
  pattern-match assessment, not proof of fraud.
* Full transcripts are NOT persisted. Only matched-phrase snippets and
  rule IDs are stored.

Safety guarantees
-----------------
* No eval / exec / subprocess / pickle on any input.
* Input truncated to MAX_TRANSCRIPT_CHARS before processing.
* All untrusted strings HTML-escaped before display (done in the UI layer).
"""
from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from config import MODULE_FRAUD_CALL_DETECTOR
from models import Evidence, Finding, RiskCategory


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Transcripts larger than this are silently truncated before analysis.
MAX_TRANSCRIPT_CHARS = 50_000   # ~8,000 words

# A "snippet" is a short window around a match; never the full transcript.
SNIPPET_WINDOW = 80             # characters on each side of the match centre


# ---------------------------------------------------------------------------
# Rule definitions (each ID must be registered in engine/risk_engine.py too)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CallRuleDefinition:
    """Mirrors engine.risk_engine.RuleDefinition but for call-analysis rules."""
    rule_id: str
    title: str
    description: str
    base_weight: float
    min_category: RiskCategory
    # Explanation shown to the user per finding
    user_explanation: str
    # One or more regex patterns (case-insensitive, applied to normalised text)
    patterns: Tuple[str, ...]


# ── All call-detector rules ────────────────────────────────────────────────
CALL_RULE_DEFINITIONS: Dict[str, CallRuleDefinition] = {
    r.rule_id: r
    for r in [

        CallRuleDefinition(
            rule_id="CALL-OTP-REQUEST",
            title="OTP / PIN / password / credential request",
            description=(
                "The transcript contains a request for a one-time password, "
                "PIN, security code, banking password, or similar credential. "
                "Legitimate banks, government agencies, and tech companies "
                "never ask for these by phone."
            ),
            base_weight=80.0,
            min_category=RiskCategory.HIGH,
            user_explanation=(
                "Legitimate organisations NEVER ask you to read out an OTP, PIN, "
                "or password over the phone. If someone does, hang up immediately."
            ),
            patterns=(
                r"\botp\b",
                r"\bone[- ]time[- ](?:password|code|pin)\b",
                r"\bverification[- ]code\b",
                r"\bsecurity[- ]code\b",
                r"\bconfirmation[- ]code\b",
                r"\benter[- ](?:your[- ])?(?:pin|password|passcode)\b",
                r"\bread[- ](?:out[- ])?(?:the[- ])?(?:otp|code|pin)\b",
                r"\bshare[- ](?:your[- ])?(?:otp|code|pin|password)\b",
                r"\btell[- ](?:me[- ])?(?:the[- ])?(?:otp|code|pin|password)\b",
                r"\bpassword\b.*\bover[- ](?:the[- ])?phone\b",
                r"\bsend[- ](?:you[- ])?(?:a[- ])?(?:code|otp|pin)\b",
                r"\bbank(?:ing)?[- ]password\b",
                r"\bnetbank(?:ing)?[- ](?:password|pin|code)\b",
                r"\binternet[- ]banking[- ](?:password|pin|code)\b",
            ),
        ),

        CallRuleDefinition(
            rule_id="CALL-URGENT-PAYMENT",
            title="Urgent payment pressure",
            description=(
                "The transcript contains urgent pressure to make an immediate "
                "payment. Scammers typically create artificial urgency to prevent "
                "victims from pausing to verify the request."
            ),
            base_weight=60.0,
            min_category=RiskCategory.HIGH,
            user_explanation=(
                "Artificial urgency ('pay now or you'll be arrested/sued/cut off') "
                "is a core scam tactic. A genuine organisation will allow you time "
                "to verify the request through an official channel before paying."
            ),
            patterns=(
                r"\bpay[- ](?:now|immediately|right[- ]now|today|within[- ]\d+[- ](?:minute|hour))\b",
                r"\bpayment[- ](?:required[- ])?(?:now|immediately|urgent(?:ly)?|overdue)\b",
                r"\bimmediately[- ](?:pay|transfer|send[- ]money)\b",
                r"\bfinal[- ](?:notice|warning|demand)\b",
                r"\baccount[- ](?:will[- ]be[- ])?(?:suspended|blocked|closed|frozen)\b.*\b(?:pay|payment)\b",
                r"\blegal[- ]action[- ](?:will[- ]be[- ])?taken\b",
                r"\barrested?[- ]if[- ](?:you[- ])?(?:don'?t|do[- ]not)\b",
                r"\bwarrant[- ](?:has[- ]been[- ])?issued\b",
                r"\bfines?[- ](?:will[- ](?:double|increase))\b",
                r"\blast[- ]chance\b",
                r"\bdeadline[- ](?:is[- ])?today\b",
                r"\bwithin[- ](?:the[- ])?next[- ]\d+[- ](?:minute|hour|day)\b.*\bpay\b",
                r"\bdo[- ]not[- ]hang[- ]up\b",
                r"\bdo[- ]not[- ]call[- ]anyone[- ]else\b",
            ),
        ),

        CallRuleDefinition(
            rule_id="CALL-IMPERSONATION",
            title="Bank, government, or tech-support impersonation",
            description=(
                "The transcript contains claims of affiliation with a bank, "
                "government authority, police force, HMRC/IRS/ATO/tax authority, "
                "or a technology company's support department. Impersonation of "
                "these organisations is a very common scam pattern."
            ),
            base_weight=50.0,
            min_category=RiskCategory.MEDIUM,
            user_explanation=(
                "Scammers frequently impersonate banks, government agencies, "
                "police, and tech companies. Hang up and call back using the "
                "number printed on your card or on the official website."
            ),
            patterns=(
                r"\bfrom[- ](?:your[- ])?(?:bank|barclays|lloyds|hsbc|natwest|santander|'your'[- ]bank)\b",
                r"\bfrom[- ](?:the[- ])?(?:hmrc|irs|ato|tax[- ](?:office|authority|department))\b",
                r"\bfrom[- ](?:the[- ])?(?:police|fbi|nca|gchq|interpol|fraud[- ]squad)\b",
                r"\bfrom[- ](?:microsoft|apple|amazon|google)[- ]support\b",
                r"\btech(?:nical)?[- ]support[- ](?:team|department|centre|center)\b",
                r"\byour[- ]computer[- ](?:has[- ])?(?:been[- ])?(?:hacked|infected|compromised)\b",
                r"\bwindows[- ](?:technical[- ])?support\b",
                r"\bapple[- ]care\b",
                r"\bamazon[- ](?:prime[- ])?(?:support|team)\b",
                r"\bnational[- ](?:crime|fraud)\b",
                r"\bfraud[- ](?:prevention[- ])?team\b",
                r"\bsocial[- ]security[- ](?:administration|number|benefit)\b",
                r"\buk[- ]government\b",
                r"\bhm[- ]revenue\b",
            ),
        ),

        CallRuleDefinition(
            rule_id="CALL-THREAT-COERCION",
            title="Threats or coercion",
            description=(
                "The transcript contains explicit threats, including threats of "
                "arrest, legal action, bailiff visits, or account suspension, "
                "used to coerce the target into complying."
            ),
            base_weight=70.0,
            min_category=RiskCategory.HIGH,
            user_explanation=(
                "Using threats (arrest, legal action, account suspension) to "
                "pressure someone is coercive and a hallmark of fraud. "
                "Legitimate organisations do not threaten immediate arrest."
            ),
            patterns=(
                r"\bwill[- ]be[- ]arrested?\b",
                r"\bsendan[- ]officer\b",
                r"\bsend[- ](?:an[- ])?(?:officer|bailiff|agent)\b",
                r"\bpolice[- ](?:will[- ])?(?:come|arrive|visit)\b",
                r"\bcriminal[- ](?:charges?|record|proceedings?)\b",
                r"\bprosecuted?\b",
                r"\bdetained?\b",
                r"\bjailed?\b",
                r"\bwarrant[- ]for[- ]your[- ]arrest\b",
                r"\bwill[- ]take[- ]you[- ]to[- ]court\b",
                r"\byour[- ](?:assets?|property|home)[- ](?:will[- ])?(?:be[- ])?(?:seized|frozen|confiscated)\b",
                r"\byour[- ](?:passport|licence?|license)[- ](?:will[- ])?(?:be[- ])?(?:revoked|cancelled?|suspended)\b",
            ),
        ),

        CallRuleDefinition(
            rule_id="CALL-PRIZE-LOTTERY",
            title="Prize, lottery, or unexpected-windfall claim",
            description=(
                "The transcript claims the target has won a prize, lottery, "
                "competition, or unexpected sum of money, often as a prelude "
                "to requesting fees or personal information."
            ),
            base_weight=55.0,
            min_category=RiskCategory.HIGH,
            user_explanation=(
                "Unsolicited prize notifications ('you've won!') are almost "
                "always advance-fee or phishing scams. You cannot win a lottery "
                "you did not enter."
            ),
            patterns=(
                r"\byou(?:'ve| have)[- ]won\b",
                r"\bcongratulations?[,!].*\b(?:won|winner|prize)\b",
                r"\blottery[- ](?:winner|winning|prize)\b",
                r"\bprize[- ](?:money|fund|claim|winner)\b",
                r"\byou[- ](?:are[- ])?(?:a[- ])?(?:winner|lucky[- ]winner)\b",
                r"\bunexpected[- ](?:inheritance|fund|transfer)\b",
                r"\bclaim[- ]your[- ](?:prize|winnings|reward)\b",
                r"\bsweepstake\b",
                r"\bjackpot\b",
                r"\bmillion[- ](?:dollars?|pounds?|euros?)[- ](?:prize|award)\b",
            ),
        ),

        CallRuleDefinition(
            rule_id="CALL-REMOTE-ACCESS",
            title="Remote access software request",
            description=(
                "The transcript requests that the target install or open a "
                "remote-access tool (AnyDesk, TeamViewer, etc.). This is used "
                "by scammers to take control of the victim's computer and access "
                "banking, files, or install malware."
            ),
            base_weight=85.0,
            min_category=RiskCategory.HIGH,
            user_explanation=(
                "Legitimate banks and government agencies NEVER ask you to "
                "install remote-access software or share your screen. Doing so "
                "gives the caller full control of your computer."
            ),
            patterns=(
                r"\banydesk\b",
                r"\bteamviewer\b",
                r"\blogmein\b",
                r"\bsupreme[- ]remote\b",
                r"\bremote[- ]access[- ](?:software|tool|app|session)\b",
                r"\bshare[- ](?:your[- ])?screen\b",
                r"\bscreen[- ]sharing\b",
                r"\bscreen[- ]share\b",
                r"\ballow[- ](?:me[- ])?(?:to[- ])?(?:access|control)[- ]your[- ]computer\b",
                r"\bremote[- ](?:desktop|session|control)\b",
                r"\binstall[- ](?:this[- ])?(?:software|app|program|tool)\b.*\b(?:remote|access|control)\b",
                r"\bquick[- ]assist\b",
                r"\bconnect[- ]to[- ]your[- ](?:device|computer|pc|laptop)\b",
            ),
        ),

        CallRuleDefinition(
            rule_id="CALL-SUSPICIOUS-URL",
            title="Suspicious URL in transcript",
            description=(
                "The transcript contains a URL. URLs delivered in unexpected "
                "calls may point to phishing pages, malware downloads, or "
                "fake banking portals."
            ),
            base_weight=30.0,
            min_category=RiskCategory.MEDIUM,
            user_explanation=(
                "Never open a URL given to you during an unexpected call. "
                "Navigate directly to your bank or service provider's official "
                "website by typing the address yourself."
            ),
            patterns=(
                # Matches http/https URLs and bare domain-like patterns
                r"https?://[^\s]{4,}",
                r"\bwww\.[a-z0-9\-]{2,}\.[a-z]{2,}(?:/[^\s]*)?\b",
                r"\bgo[- ]to[- ](?:this[- ])?(?:link|website|url|site)\b",
                r"\bclick[- ](?:on[- ])?(?:the[- ])?(?:link|url)\b",
                r"\bvisit[- ](?:this[- ])?(?:site|website|page|link)\b",
            ),
        ),

        CallRuleDefinition(
            rule_id="CALL-UNUSUAL-PAYMENT",
            title="Unusual payment instruction",
            description=(
                "The transcript requests payment via gift cards, cryptocurrency, "
                "wire transfer to an unfamiliar account, or other non-standard "
                "method. Legitimate organisations accept standard payment methods "
                "and do not ask you to buy gift cards."
            ),
            base_weight=75.0,
            min_category=RiskCategory.HIGH,
            user_explanation=(
                "Requests to pay by gift card (iTunes, Google Play, Amazon), "
                "cryptocurrency, or immediate wire transfer are classic scam tactics. "
                "A genuine organisation will accept payment through normal, reversible "
                "channels."
            ),
            patterns=(
                r"\bgift[- ]card[s]?\b",
                r"\bitunes[- ](?:card|gift[- ]card)\b",
                r"\bgoogle[- ]play[- ](?:card|gift[- ]card)\b",
                r"\bamazon[- ](?:gift[- ]card|voucher)\b",
                r"\bsteam[- ](?:card|wallet|gift[- ]card)\b",
                r"\bpaysafe(?:card)?\b",
                r"\bcryptocurrenc(?:y|ies)\b",
                r"\bbitcoin\b",
                r"\bethereum\b",
                r"\bcrypto[- ]wallet\b",
                r"\bwire[- ]transfer\b",
                r"\bbank[- ]transfer[- ](?:to[- ])?(?:a[- ])?(?:new|different|this)\b",
                r"\btransfer[- ](?:the[- ])?(?:money|funds?)[- ](?:to[- ])?(?:a[- ])?(?:safe|secure|new)[- ]account\b",
                r"\bsafe[- ]account\b",
                r"\bprotective[- ]account\b",
                r"\bmoneygramm?\b",
                r"\bwestern[- ]union\b",
            ),
        ),
    ]
}


# ---------------------------------------------------------------------------
# URL extraction helper
# ---------------------------------------------------------------------------

_URL_REGEX = re.compile(
    # Full http/https URL  OR  www. domain (handles multi-part TLDs like .co.uk)
    r"https?://[^\s<>\"']{4,}"
    r"|www\.[a-z0-9\-]{2,}(?:\.[a-z0-9\-]{2,})+(?:/[^\s<>\"']*)?",
    re.IGNORECASE,
)


def extract_urls(transcript: str) -> List[str]:
    """
    Extract and normalise URLs found in the transcript.
    Returns a deduplicated list (case-folded, stripped).
    These are used as indicators for cross-module correlation.
    """
    found = _URL_REGEX.findall(transcript)
    seen: set[str] = set()
    result: List[str] = []
    for u in found:
        norm = u.strip().lower()
        if norm not in seen:
            seen.add(norm)
            result.append(norm)
    return result


# ---------------------------------------------------------------------------
# Snippet extraction (never stores full transcript)
# ---------------------------------------------------------------------------

def _make_snippet(text: str, match: re.Match, window: int = SNIPPET_WINDOW) -> str:
    """
    Return a short context snippet around *match* within *text*.
    The snippet is at most 2×window+len(match) characters.
    Never returns the full transcript.
    """
    start = max(0, match.start() - window)
    end   = min(len(text), match.end() + window)
    snippet = text[start:end].strip()
    # Mark the matched portion with angle brackets for highlighting
    rel_start = match.start() - start
    rel_end   = match.end() - start
    if 0 <= rel_start < rel_end <= len(snippet):
        snippet = (
            snippet[:rel_start]
            + ">>>"
            + snippet[rel_start:rel_end]
            + "<<<"
            + snippet[rel_end:]
        )
    return snippet


# ---------------------------------------------------------------------------
# Main analysis function
# ---------------------------------------------------------------------------

def analyse_transcript(
    transcript: str,
    is_simulated: bool = False,
) -> "AnalysisResult":
    """
    Analyse a call transcript for social-engineering indicators.

    Parameters
    ----------
    transcript:
        Plain-text transcript. Truncated to MAX_TRANSCRIPT_CHARS.
    is_simulated:
        True for demo / synthetic transcripts.

    Returns
    -------
    AnalysisResult with findings, extracted URLs, and a mandatory disclaimer.
    """
    if not transcript or not transcript.strip():
        return AnalysisResult(
            findings=[],
            extracted_urls=[],
            is_simulated=is_simulated,
            input_length=0,
            was_truncated=False,
        )

    # Truncate first — never process unbounded input
    was_truncated = len(transcript) > MAX_TRANSCRIPT_CHARS
    text = transcript[:MAX_TRANSCRIPT_CHARS]

    # Normalise for matching: lower-case, collapse whitespace
    # We keep the original (truncated) text to extract real snippets
    norm = re.sub(r"\s+", " ", text.lower())

    findings: List[Finding] = []

    for rule in CALL_RULE_DEFINITIONS.values():
        matched_snippets: List[str] = []
        matched_phrases: List[str] = []

        for pattern in rule.patterns:
            regex = re.compile(pattern, re.IGNORECASE)
            for match in regex.finditer(norm):
                snippet = _make_snippet(norm, match)
                matched_snippets.append(snippet)
                matched_phrases.append(match.group(0))
                if len(matched_snippets) >= 5:
                    # Cap at 5 snippets per rule to avoid storing too much
                    break
            if len(matched_snippets) >= 5:
                break

        if not matched_snippets:
            continue

        # Build evidence list — short snippets only, never full transcript
        evidence: List[Evidence] = []
        for i, snippet in enumerate(matched_snippets):
            evidence.append(Evidence(
                label=f"Matched phrase {i + 1}",
                # HTML-escape the snippet before storage; the UI must also escape
                value=html.escape(snippet, quote=True),
                raw=html.escape(matched_phrases[i] if i < len(matched_phrases) else snippet),
                is_observed_fact=True,
            ))
        evidence.append(Evidence(
            label="Explanation",
            value=rule.user_explanation,
            is_observed_fact=False,  # This is interpretive guidance
        ))

        findings.append(Finding(
            module=MODULE_FRAUD_CALL_DETECTOR,
            rule_id=rule.rule_id,
            title=rule.title,
            description=rule.description,
            risk_category=rule.min_category,
            confidence_note=(
                "Pattern match on transcript text only. "
                "This is an assessment, not proof of fraud."
            ),
            remediation=rule.user_explanation,
            source="local transcript analysis",
            is_simulated=is_simulated,
            evidence=evidence,
            input_type="transcript",
        ))

    # Extract URLs as correlation indicators
    extracted_urls = extract_urls(text)

    return AnalysisResult(
        findings=findings,
        extracted_urls=extracted_urls,
        is_simulated=is_simulated,
        input_length=len(text),
        was_truncated=was_truncated,
    )


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class AnalysisResult:
    findings: List[Finding]
    extracted_urls: List[str]
    is_simulated: bool
    input_length: int
    was_truncated: bool

    # Mandatory disclaimer — always attached; never removed
    disclaimer: str = (
        "This is an assessment based on pattern matching of transcript text only. "
        "It is NOT proof of fraud. Some legitimate calls may trigger indicators "
        "(false positives). A negative result does NOT guarantee a call is safe."
    )

    # Safety guidance shown for every result
    safety_actions: List[str] = field(default_factory=lambda: [
        "If anything made you uncomfortable, hang up immediately.",
        "Call your bank on the number printed on the back of your card (not a number given to you during the call).",
        "Never share OTPs, PINs, passwords, or security codes with anyone who called you.",
        "Never install software or allow screen access to someone who called you.",
        "Report suspected scam calls to your national cybercrime or fraud authority.",
    ])
