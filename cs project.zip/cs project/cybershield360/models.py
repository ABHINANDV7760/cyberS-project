"""
models.py – Core data models for CyberShield 360.

Defines Finding, Evidence, and the risk category hierarchy shared by all
modules. Import from here; never define these elsewhere.
"""
from __future__ import annotations

import dataclasses
import uuid
from datetime import datetime
from enum import Enum
from typing import List, Optional


# ---------------------------------------------------------------------------
# Risk categories (ordered from least to most severe)
# ---------------------------------------------------------------------------

class RiskCategory(str, Enum):
    INFORMATIONAL = "Informational"
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"
    UNKNOWN = "Unknown"   # Insufficient evidence to score
    BLOCKED = "Blocked"   # SSRF / policy block – not a risk score


RISK_ORDER: dict[RiskCategory, int] = {
    RiskCategory.INFORMATIONAL: 0,
    RiskCategory.LOW: 1,
    RiskCategory.MEDIUM: 2,
    RiskCategory.HIGH: 3,
    RiskCategory.CRITICAL: 4,
    RiskCategory.UNKNOWN: -1,
    RiskCategory.BLOCKED: -1,
}

RISK_ICONS: dict[RiskCategory, str] = {
    RiskCategory.INFORMATIONAL: "ℹ️",
    RiskCategory.LOW: "🟢",
    RiskCategory.MEDIUM: "🟡",
    RiskCategory.HIGH: "🟠",
    RiskCategory.CRITICAL: "🔴",
    RiskCategory.UNKNOWN: "❓",
    RiskCategory.BLOCKED: "🚫",
}


def risk_label(category: RiskCategory) -> str:
    """Return an icon + text label, e.g. '🔴 Critical'."""
    icon = RISK_ICONS.get(category, "❓")
    return f"{icon} {category.value}"


# ---------------------------------------------------------------------------
# Evidence attached to a Finding
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class Evidence:
    label: str          # Short label, e.g. "Detected type"
    value: str          # Human-readable value
    raw: Optional[str] = None  # Technical detail (truncated, never full content)
    # Marks whether this evidence item is an observed fact (True) or an
    # inferred / interpreted item (False). Used for the fact-vs-inference split
    # in the Section B log-analysis display and in shared reports.
    is_observed_fact: bool = True


# ---------------------------------------------------------------------------
# Finding – one triggered rule
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class Finding:
    module: str                   # e.g. "Download Guard"
    rule_id: str                  # e.g. "FILE-EXEC-DISGUISED"
    title: str                    # Short human-readable title
    description: str              # What was found
    risk_category: RiskCategory
    confidence_note: str = ""     # Caveats about confidence
    remediation: str = ""         # Recommended next action
    source: str = ""              # e.g. "local analysis", "VirusTotal"
    is_simulated: bool = False    # True for demo/synthetic results
    evidence: List[Evidence] = dataclasses.field(default_factory=list)
    triggered_at: datetime = dataclasses.field(default_factory=datetime.utcnow)
    # Stable identifier for cross-module correlation; generated on creation.
    finding_id: str = dataclasses.field(default_factory=lambda: str(uuid.uuid4()))
    # The kind of input that triggered this finding: "file", "url", "website",
    # "log", or "transcript".
    input_type: str = "file"

    def to_dict(self) -> dict:
        return {
            "finding_id": self.finding_id,
            "module": self.module,
            "rule_id": self.rule_id,
            "title": self.title,
            "description": self.description,
            "risk_category": self.risk_category.value,
            "confidence_note": self.confidence_note,
            "remediation": self.remediation,
            "source": self.source,
            "is_simulated": self.is_simulated,
            "input_type": self.input_type,
            "evidence": [dataclasses.asdict(e) for e in self.evidence],
            "triggered_at": self.triggered_at.isoformat(),
        }


# ---------------------------------------------------------------------------
# Scan – top-level record (one per user action)
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class Scan:
    module: str
    target_label: str     # Filename, URL (no query string), or folder path
    target_hash: Optional[str] = None   # SHA-256 when available
    target_type: Optional[str] = None   # Detected/declared type
    risk_category: Optional[RiskCategory] = None
    score: float = 0.0
    is_simulated: bool = False
    findings: List[Finding] = dataclasses.field(default_factory=list)
    scan_id: Optional[int] = None
    scanned_at: datetime = dataclasses.field(default_factory=datetime.utcnow)
    # Seconds the check took end-to-end (optional; set by callers that measure it)
    duration_seconds: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "scan_id": self.scan_id,
            "module": self.module,
            "target_label": self.target_label,
            "target_hash": self.target_hash,
            "target_type": self.target_type,
            "risk_category": self.risk_category.value if self.risk_category else None,
            "score": self.score,
            "is_simulated": self.is_simulated,
            "findings": [f.to_dict() for f in self.findings],
            "scanned_at": self.scanned_at.isoformat(),
            "duration_seconds": self.duration_seconds,
        }
