# CyberShield 360 — Download Guard

**CyberShield 360** is a defensive, read-only inspection tool built with Python and Streamlit.
It helps you evaluate the risk of files and URLs **before** you open them.

> **This tool is read-only.** It never deletes, moves, renames, executes, previews, writes to, or quarantines any file or downloaded content.

---

## Quick Start

### 1. Install dependencies

```bash
cd cybershield360
pip install streamlit pandas plotly requests urllib3
```

### 2. Generate sample fixtures

```bash
python scripts/make_samples.py
```

### 3. Run the app

```bash
streamlit run app.py
```

### 4. Run tests

```bash
pytest tests/ -v
```

---

## Project layout

```
cybershield360/
├── app.py                          # Streamlit entry point
├── config.py                       # All configuration constants
├── models.py                       # Finding, Evidence, RiskCategory, Scan
├── database.py                     # SQLite persistence (parameterised SQL)
│
├── engine/
│   └── risk_engine.py              # Rule weights, thresholds, overrides
│
├── modules/
│   └── download_guard.py           # Core analysis logic (file + URL)
│
├── utils/
│   ├── safe_fetch.py               # SSRF-safe HTTP layer
│   └── logging_utils.py            # Safe structured logging
│
├── integrations/
│   └── reputation_provider.py      # Threat-intel adapters + No-API provider
│
├── data/
│   └── demo_download_urls.json     # Synthetic demo URL entries
│
├── samples/                        # Inert synthetic fixtures (make_samples.py)
│   ├── harmless-sample.txt
│   ├── invoice.pdf.exe             # Double-extension demo
│   ├── photo.zip                   # PNG-magic-in-.zip demo
│   ├── report.pdf                  # MZ-magic-in-.pdf demo
│   ├── macro-demo.docm             # Macro-capable extension demo
│   └── archive-demo.zip            # Archive demo
│
├── scripts/
│   └── make_samples.py             # Generates sample fixtures
│
└── tests/
    ├── conftest.py
    ├── test_download_guard.py
    ├── test_safe_fetch.py
    └── test_risk_engine.py
```

---

## Usage

### Page: Download Guard

The app provides four input modes via tabs:

| Tab | What it does |
|---|---|
| 🔗 Paste URL | Validate + fetch metadata for any download URL |
| 📄 Single File | Upload a file; analysed in memory only, never saved |
| 📁 Scan Folder | Recursive read-only scan of a local directory |
| 🧪 Sample Inspector | Inspect the bundled synthetic fixtures |

---

## Risk model

### Score calculation

```
Score = sum of triggered rule weights

Threshold → Category
────────────────────
≥ 80  → Critical
≥ 50  → High
≥ 20  → Medium
≥  1  → Low
   0  → Informational
(no findings) → Unknown
```

### Rule definitions

| Rule ID | Weight | Min Category | Description |
|---|---|---|---|
| `FILE-EXEC-DISGUISED` | 80 | High | Executable signature with non-executable extension |
| `FILE-DOUBLE-EXT` | 60 | High | Multiple extensions or trailing dots/spaces |
| `FILE-RTLO` | 90 | High | Bidirectional / invisible control character in name |
| `FILE-RISKY-EXT` | 40 | Medium | High-risk extension (.exe .ps1 .bat etc.) |
| `FILE-MACRO-CAPABLE` | 30 | Medium | Macro-capable format (.docm .xlsm .pptm or OLE2) |
| `FILE-ARCHIVE-UNINSPECTED` | 15 | Low | Archive (contents not inspected) |
| `FILE-TYPE-MISMATCH` | 25 | Low | Extension ≠ detected signature |
| `FILE-HIGH-ENTROPY` | 10 | Informational | Shannon entropy > 7.2 bits/byte |
| `FILE-EMPTY-OR-TRUNCATED` | 20 | Low | Zero bytes or implausibly short |
| `FILE-CONSISTENT` | 0 | Informational | Extension and signature agree |
| `URL-BAD-SCHEME` | 100 | Critical | Non-HTTP(S) scheme |
| `URL-CREDENTIALS` | 70 | High | Credentials embedded in URL |
| `URL-SSRF-BLOCKED` | 100 | Blocked | Resolves to non-public address |
| `URL-REDIRECT-HTTPS-DOWNGRADE` | 35 | Medium | HTTPS → HTTP in redirect chain |
| `URL-REDIRECT-CROSS-DOMAIN` | 20 | Low | Redirect crosses domains |
| `URL-REDIRECT-IP-LITERAL` | 30 | Medium | Redirect to IP-literal address |
| `URL-CONTENT-TYPE-MISMATCH` | 25 | Low | Content-Type / extension / filename mismatch |
| `URL-IP-LITERAL-HOST` | 15 | Low | Host is an IP address |
| `URL-LONG` | 5 | Informational | URL > 1,024 characters |
| `URL-UNUSUAL-TLD` | 5 | Informational | Uncommon TLD |
| `URL-MANY-SUBDOMAINS` | 5 | Informational | Many subdomain labels |
| `REP-MALICIOUS-REPORTED` | 100 | Critical | Reputation provider flagged as malicious |

### Hard overrides (take priority over computed score)

1. `URL-SSRF-BLOCKED` → **Blocked** (request never sent)
2. `REP-MALICIOUS-REPORTED` → **Critical**
3. `FILE-EXEC-DISGUISED` → at least **High**
4. Each rule's `min_category` floor is enforced

---

## SSRF protections

`utils/safe_fetch.py` enforces these protections on **every** outbound request:

1. **Scheme allowlist**: only `http://` and `https://` are accepted.
2. **Credential rejection**: `user:pass@host` URLs are blocked.
3. **Port allowlist**: only 80, 443, 8080, 8443.
4. **DNS resolution + IP check**: all A/AAAA records are resolved and checked. If **any** address is non-globally-routable, the request is blocked. Blocked ranges include:
   - Loopback (127.0.0.0/8, ::1)
   - RFC1918 (10/8, 172.16/12, 192.168/16)
   - Link-local (169.254.0.0/16, fe80::/10) — including cloud metadata endpoints
   - CGNAT (100.64.0.0/10)
   - Multicast, unspecified, reserved
   - IPv6 ULA (fc00::/7)
   - IPv4-mapped / 6to4 / NAT64 embedding non-public IPv4
5. **DNS rebinding prevention**: the validated IP is pinned before connection. The hostname is never re-resolved.
6. **Manual redirects**: auto-follow is disabled; each hop is independently validated (max 5 hops). Cross-domain, HTTPS→HTTP downgrades, and IP-literal redirects are flagged.
7. **No body download**: only HEAD (or zero-range GET) is sent. Any accidental body bytes are capped at 64 KB and discarded.
8. **Timeouts**: 3 s connect, 5 s read, 8 s wall-clock budget.
9. **Rate limit**: max 20 URL checks per minute per session; one in-flight request at a time.
10. **No cookies, no auth, no env proxies**.

---

## Reputation lookups

Supported providers (configure via environment variables):

| Provider | Environment variable |
|---|---|
| URLhaus | `URLHAUS_API_KEY` (optional; anonymous lookups supported) |
| VirusTotal | `VIRUSTOTAL_API_KEY` |
| Google Safe Browsing | `GOOGLE_SAFE_BROWSING_API_KEY` |
| No-API (demo/synthetic) | Always available; no key required |

**Mandatory wording for `no_data`:** "No reputation data. This does NOT mean the URL is safe."

**Persistent notice:** A reputation lookup is not a malware scan. It only reports what a database already knows. It cannot inspect the file's contents.

---

## No-API / Demo mode

When no real API keys are configured, the app runs in No-API mode:

- Local analysis (signature detection, entropy, rules) runs on real files.
- A "Demo URLs" selectbox lets you explore synthetic scenarios without network calls.
- All synthetic results are labeled **SYNTHETIC** and stored with `is_simulated=True`.

---

## Environment variables

```bash
# Optional API keys for reputation providers
VIRUSTOTAL_API_KEY=...
URLHAUS_API_KEY=...
GOOGLE_SAFE_BROWSING_API_KEY=...
```

**Keys are never hardcoded, logged, or displayed in the UI.**

---

## Threat model

This tool addresses the following threats:

| Threat | Mitigation |
|---|---|
| Malware disguised as a document | `FILE-EXEC-DISGUISED`, magic-byte detection |
| RTLO / homoglyph file name tricks | `FILE-RTLO`, bidi character scan |
| Archive containing malicious payload | `FILE-ARCHIVE-UNINSPECTED` (flags for manual review) |
| Macro-based Office attacks | `FILE-MACRO-CAPABLE` |
| SSRF via URL input | `safe_fetch.py` with DNS pinning, IP range checks |
| DNS rebinding | Pinned-IP HTTPAdapter, single DNS resolution |
| Malicious redirect chains | Manual hop-by-hop validation |
| Credential theft via URL | Credentials-in-URL rejection |
| Internal network access via metadata IP | 169.254.0.0/16 blocked in SSRF checks |

---

## Limitations

> **Read this section before drawing conclusions from the results.**

1. **Signatures are heuristic.** Magic-byte detection can be fooled. A file can present a benign signature header and contain malicious content after the header bytes. This tool does NOT perform deep content analysis.

2. **Archive contents are not inspected.** ZIP, RAR, 7z, and other archives are identified but their contents are never extracted or examined. Malicious files inside archives are invisible to this tool.

3. **Entropy produces false positives.** High Shannon entropy is a signal, not a verdict. Normal compressed files (JPEG, ZIP, GZIP) also score high. The `FILE-HIGH-ENTROPY` rule has a low weight (10) for this reason.

4. **Reputation lookups are not malware scans.** They report only what a threat-intelligence database already knows. A brand-new malicious URL will return `no_data`. A URL removed from a blocklist may still be dangerous.

5. **This tool cannot prove a file or URL is safe.** The lowest category text is always: *"No issues detected by these checks. This does not guarantee the file or URL is safe."*

6. **The tool is read-only.** It never quarantines, blocks, or removes files. Remediation must be performed by the user or an endpoint protection product.

7. **Local path scan requires local execution.** The folder path tab only works when the app runs on the user's machine, not in a cloud or hosted environment.

8. **No deep inspection of Office documents.** Whether a .docm or .doc file actually contains macros is not checked — only the format capability is noted.

---

## Security constraints

- No `eval` / `exec` / `subprocess` / `os.system` / `pickle` on any user input.
- All file reads use `"rb"` mode only.
- All database writes use parameterised SQL.
- URLs are stored without query strings.
- File contents are never stored; only name, hash, and type.
- All outbound HTTP goes through `utils/safe_fetch.py`. No code path bypasses it.
- API keys are never logged or displayed.
- Untrusted strings (file names, headers) are never passed to `unsafe_allow_html`.

---

## Running tests

```bash
cd cybershield360
pytest tests/ -v
```

Tests use only synthetic data. No real network calls are made (DNS and HTTP are mocked).
No real malware is used or created.
