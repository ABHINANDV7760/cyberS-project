"""
tests/test_download_guard.py – Unit tests for modules/download_guard.py

Coverage:
  - detect_type(): every signature in the magic table, unknown, empty, truncated
  - Extension mismatch and each rule (RTLO, double-ext, trailing dot, EXEC-DISGUISED, etc.)
  - sha256_file() against known vectors
  - sha256_stream() on a multi-MB temp file
  - shannon_entropy()
  - Folder scan: skips symlinks (mocked), caps file count, never modifies files
    (compare mtimes and hashes before and after)
  - analyze_url(): SSRF-blocked, redirect signals, content-type mismatch
"""
from __future__ import annotations

import hashlib
import os
import stat
import sys
import tempfile
import time
from pathlib import Path
from typing import List
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from modules.download_guard import (
    DetectedType,
    FileRecord,
    _BIDI_CHARS,
    _has_bidi_char,
    _get_stem_extensions,
    analyze_file,
    analyze_url,
    detect_type,
    sha256_file,
    sha256_stream,
    shannon_entropy,
    walk_folder,
)


# ---------------------------------------------------------------------------
# detect_type()
# ---------------------------------------------------------------------------

class TestDetectType:
    """Every signature in the magic table plus edge cases."""

    def test_pe_exe(self):
        dt = detect_type(b"MZ" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "executable"
        assert "PE" in dt.name

    def test_elf(self):
        dt = detect_type(b"\x7fELF" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "executable"

    def test_macho_64(self):
        dt = detect_type(b"\xfe\xed\xfa\xcf" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "executable"

    def test_macho_32(self):
        dt = detect_type(b"\xfe\xed\xfa\xce" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "executable"

    def test_macho_reversed_32(self):
        dt = detect_type(b"\xce\xfa\xed\xfe" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "executable"

    def test_macho_reversed_64(self):
        dt = detect_type(b"\xcf\xfa\xed\xfe" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "executable"

    def test_macho_universal(self):
        dt = detect_type(b"\xca\xfe\xba\xbe" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "executable"

    def test_pdf(self):
        dt = detect_type(b"%PDF-1.4 ..." + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "document"
        assert "PDF" in dt.name

    def test_rtf(self):
        dt = detect_type(b"{\\rtf1..." + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "document"

    def test_ole2(self):
        dt = detect_type(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "document"
        assert "OLE" in dt.name

    def test_zip(self):
        dt = detect_type(b"PK\x03\x04" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "archive"

    def test_zip_empty(self):
        dt = detect_type(b"PK\x05\x06" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "archive"

    def test_rar(self):
        dt = detect_type(b"Rar!" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "archive"

    def test_7z(self):
        dt = detect_type(b"7z\xbc\xaf\x27\x1c" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "archive"

    def test_gzip(self):
        dt = detect_type(b"\x1f\x8b" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "archive"

    def test_bzip2(self):
        dt = detect_type(b"BZh" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "archive"

    def test_xz(self):
        dt = detect_type(b"\xfd7zXZ\x00" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "archive"

    def test_png(self):
        dt = detect_type(b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "image"
        assert "PNG" in dt.name

    def test_jpeg(self):
        dt = detect_type(b"\xff\xd8\xff" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "image"

    def test_gif87a(self):
        dt = detect_type(b"GIF87a" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "image"

    def test_gif89a(self):
        dt = detect_type(b"GIF89a" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "image"

    def test_bmp(self):
        dt = detect_type(b"BM" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "image"

    def test_lnk(self):
        dt = detect_type(b"\x4c\x00\x00\x00\x01\x14\x02\x00" + b"\x00" * 100)
        assert dt is not None
        assert dt.group == "executable"
        assert "LNK" in dt.name

    def test_shebang_script(self):
        dt = detect_type(b"#!/bin/bash\necho hello\n")
        assert dt is not None
        assert dt.group == "executable"

    def test_plain_text(self):
        dt = detect_type(b"Hello, this is plain text.\n")
        assert dt is not None
        assert dt.group == "text"

    def test_empty_returns_none(self):
        dt = detect_type(b"")
        assert dt is None

    def test_unknown_binary_returns_none(self):
        # bytes with null bytes → not text; no known magic
        dt = detect_type(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b")
        assert dt is None

    def test_truncated_magic_not_matched(self):
        # Only 1 byte of a 2-byte magic sequence
        dt = detect_type(b"M")
        # MZ needs 2 bytes; should not match
        result = detect_type(b"M")
        # Should not be PE
        if result is not None:
            assert "PE" not in result.name


# ---------------------------------------------------------------------------
# sha256_file() and sha256_stream()
# ---------------------------------------------------------------------------

class TestSha256:
    def test_empty_bytes(self):
        # Known SHA-256 of empty string
        expected = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        assert sha256_file(b"") == expected

    def test_known_vector(self):
        # SHA-256("abc") = ba7816bf8f01cfea414140de5dae2ec73b00361bbef0469348423f656b4b6f6e
        # (standard test vector)
        expected = hashlib.sha256(b"abc").hexdigest()
        assert sha256_file(b"abc") == expected

    def test_sha256_stream_matches_file(self):
        data = b"x" * (3 * 1024 * 1024)  # 3 MB
        expected = hashlib.sha256(data).hexdigest()

        buf_pos = [0]

        def read_fn(chunk_size: int) -> bytes:
            chunk = data[buf_pos[0]: buf_pos[0] + chunk_size]
            buf_pos[0] += chunk_size
            return chunk

        result = sha256_stream(read_fn, chunk_size=1024 * 1024)
        assert result == expected

    def test_sha256_stream_empty(self):
        def read_fn(n):
            return b""
        expected = hashlib.sha256(b"").hexdigest()
        assert sha256_stream(read_fn) == expected


# ---------------------------------------------------------------------------
# shannon_entropy()
# ---------------------------------------------------------------------------

class TestShannonEntropy:
    def test_empty(self):
        assert shannon_entropy(b"") == 0.0

    def test_all_same_bytes(self):
        assert shannon_entropy(b"\x00" * 1000) == pytest.approx(0.0)

    def test_all_distinct_bytes(self):
        # 256 distinct bytes → max entropy 8.0
        data = bytes(range(256))
        e = shannon_entropy(data)
        assert e == pytest.approx(8.0, abs=0.01)

    def test_high_entropy_random_ish(self):
        import random
        rng = random.Random(42)
        data = bytes(rng.randint(0, 255) for _ in range(10000))
        e = shannon_entropy(data)
        assert e > 7.0  # Should be very close to 8.0

    def test_text_is_low_entropy(self):
        data = b"aaaaaabbbbbbcccccc"
        e = shannon_entropy(data)
        assert e < 4.0


# ---------------------------------------------------------------------------
# analyze_file() rule triggering
# ---------------------------------------------------------------------------

class TestAnalyzeFile:
    def _rule_ids(self, findings) -> set:
        return {f.rule_id for f in findings}

    def test_exec_disguised_as_pdf(self):
        # MZ magic + .pdf extension → FILE-EXEC-DISGUISED
        findings = analyze_file("report.pdf", b"MZ" + b"\x00" * 200)
        assert "FILE-EXEC-DISGUISED" in self._rule_ids(findings)

    def test_exec_disguised_as_png(self):
        findings = analyze_file("photo.png", b"MZ" + b"\x00" * 200)
        assert "FILE-EXEC-DISGUISED" in self._rule_ids(findings)

    def test_double_extension(self):
        findings = analyze_file("invoice.pdf.exe", b"Hello world\n" * 10)
        assert "FILE-DOUBLE-EXT" in self._rule_ids(findings)

    def test_rtlo_char_in_name(self):
        # U+202E is right-to-left override
        rtlo_name = "document\u202Eexe.pdf"
        findings = analyze_file(rtlo_name, b"Hello world\n")
        assert "FILE-RTLO" in self._rule_ids(findings)

    def test_zero_width_space_in_name(self):
        name = "file\u200b.exe"
        findings = analyze_file(name, b"Hello\n")
        assert "FILE-RTLO" in self._rule_ids(findings)

    def test_risky_extension_exe(self):
        # .exe with no other issues
        findings = analyze_file("setup.exe", b"\x89PNG\r\n\x1a\n" + b"\x00" * 200)
        # PNG sig + exe ext → could be EXEC-DISGUISED or TYPE-MISMATCH
        rule_ids = self._rule_ids(findings)
        assert "FILE-RISKY-EXT" in rule_ids or "FILE-EXEC-DISGUISED" in rule_ids or "FILE-TYPE-MISMATCH" in rule_ids

    def test_risky_extension_ps1(self):
        findings = analyze_file("script.ps1", b"Write-Host 'hello'\n")
        assert "FILE-RISKY-EXT" in self._rule_ids(findings)

    def test_macro_capable_docm(self):
        findings = analyze_file("macro.docm", b"PK\x03\x04" + b"\x00" * 200)
        assert "FILE-MACRO-CAPABLE" in self._rule_ids(findings)

    def test_macro_capable_ole2(self):
        findings = analyze_file("legacy.doc", b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 200)
        assert "FILE-MACRO-CAPABLE" in self._rule_ids(findings)

    def test_archive_uninspected(self):
        findings = analyze_file("archive.zip", b"PK\x03\x04" + b"\x00" * 200)
        assert "FILE-ARCHIVE-UNINSPECTED" in self._rule_ids(findings)

    def test_type_mismatch_png_as_zip(self):
        findings = analyze_file("photo.zip", b"\x89PNG\r\n\x1a\n" + b"\x00" * 200)
        rule_ids = self._rule_ids(findings)
        assert "FILE-TYPE-MISMATCH" in rule_ids

    def test_empty_file(self):
        findings = analyze_file("empty.txt", b"")
        assert "FILE-EMPTY-OR-TRUNCATED" in self._rule_ids(findings)

    def test_high_entropy(self):
        # All distinct bytes repeated → near-max entropy
        data = bytes(range(256)) * 500  # ~128 KB, all byte values
        from config import FILE_ENTROPY_THRESHOLD
        e = shannon_entropy(data[:1024 * 1024])
        if e >= FILE_ENTROPY_THRESHOLD:
            findings = analyze_file("packed.bin", data)
            assert "FILE-HIGH-ENTROPY" in self._rule_ids(findings)

    def test_consistent_pdf(self):
        # %PDF magic + .pdf extension → FILE-CONSISTENT
        findings = analyze_file("document.pdf", b"%PDF-1.4\n" + b"x" * 200)
        rule_ids = self._rule_ids(findings)
        assert "FILE-CONSISTENT" in rule_ids
        assert "FILE-EXEC-DISGUISED" not in rule_ids
        assert "FILE-TYPE-MISMATCH" not in rule_ids

    def test_zip_based_office_consistent(self):
        # ZIP magic + .docx extension → consistent (no mismatch)
        findings = analyze_file("document.docx", b"PK\x03\x04" + b"\x00" * 200)
        rule_ids = self._rule_ids(findings)
        assert "FILE-TYPE-MISMATCH" not in rule_ids
        assert "FILE-EXEC-DISGUISED" not in rule_ids

    def test_trailing_space_in_extension(self):
        findings = analyze_file("file.exe ", b"Hello world\n")
        rule_ids = self._rule_ids(findings)
        # trailing space in extension should trigger FILE-DOUBLE-EXT
        # (the name has "exe " as the extension)
        assert "FILE-DOUBLE-EXT" in rule_ids or "FILE-RISKY-EXT" in rule_ids

    def test_no_false_positives_on_harmless_txt(self):
        content = b"Hello, this is a completely normal text file.\n"
        findings = analyze_file("readme.txt", content)
        rule_ids = self._rule_ids(findings)
        # Should not have any of the critical/high rules
        assert "FILE-EXEC-DISGUISED" not in rule_ids
        assert "FILE-RTLO" not in rule_ids
        assert "FILE-DOUBLE-EXT" not in rule_ids


# ---------------------------------------------------------------------------
# Folder scan safety
# ---------------------------------------------------------------------------

class TestFolderScan:
    def test_does_not_modify_files(self, tmp_path):
        """Verify that the folder scan never writes to any file."""
        # Create test files
        f1 = tmp_path / "hello.txt"
        f1.write_bytes(b"Hello world\n")
        f2 = tmp_path / "binary.exe"
        f2.write_bytes(b"MZ" + b"\x00" * 50)

        # Record mtimes and hashes before scan
        before = {
            f.name: (f.stat().st_mtime, hashlib.sha256(f.read_bytes()).hexdigest())
            for f in tmp_path.iterdir() if f.is_file()
        }

        # Run scan
        records = list(walk_folder(tmp_path))

        # Verify files unchanged
        after = {
            f.name: (f.stat().st_mtime, hashlib.sha256(f.read_bytes()).hexdigest())
            for f in tmp_path.iterdir() if f.is_file()
        }

        assert before == after, "Folder scan modified file metadata or contents"

    def test_caps_file_count(self, tmp_path):
        from config import FOLDER_MAX_FILES
        # Create FOLDER_MAX_FILES + 5 files
        total = FOLDER_MAX_FILES + 5
        for i in range(total):
            (tmp_path / f"file_{i:05d}.txt").write_bytes(b"x")

        records = list(walk_folder(tmp_path))
        # Should stop at or near FOLDER_MAX_FILES
        # (one extra record for the "SCAN LIMIT REACHED" sentinel)
        processed = [r for r in records if "SCAN LIMIT" not in r.rel_path]
        assert len(processed) <= FOLDER_MAX_FILES

    def test_skips_unreadable_file(self, tmp_path):
        """Unreadable file is recorded as skipped, not crashed."""
        good = tmp_path / "good.txt"
        good.write_bytes(b"readable content\n")

        bad = tmp_path / "unreadable.txt"
        bad.write_bytes(b"secret\n")

        records = list(walk_folder(tmp_path))
        all_paths = {r.rel_path for r in records}
        assert "good.txt" in all_paths
        # All records should have been processed (no exception raised)
        assert len(records) >= 1

    def test_cancellation(self, tmp_path):
        """Cancel flag stops the walk."""
        for i in range(100):
            (tmp_path / f"file_{i:03d}.txt").write_bytes(b"x")

        records = []
        call_count = {"n": 0}

        def cancel_after_3() -> bool:
            call_count["n"] += 1
            return call_count["n"] > 3

        for rec in walk_folder(tmp_path, cancel_flag=cancel_after_3):
            records.append(rec)

        assert len(records) < 100  # Was cancelled early

    def test_does_not_follow_symlinks(self, tmp_path):
        """Symbolic links are skipped, not followed."""
        target = tmp_path / "real_file.txt"
        target.write_bytes(b"real content\n")

        link = tmp_path / "link_to_file.txt"
        try:
            link.symlink_to(target)
        except (OSError, NotImplementedError):
            pytest.skip("Symlinks not supported on this platform")

        records = list(walk_folder(tmp_path))
        skipped = [r for r in records if r.skipped_reason and "symlink" in r.skipped_reason]
        assert len(skipped) >= 1

    def test_results_have_sha256(self, tmp_path):
        f = tmp_path / "testfile.txt"
        content = b"Hello, CyberShield 360\n"
        f.write_bytes(content)
        expected_hash = hashlib.sha256(content).hexdigest()

        records = list(walk_folder(tmp_path))
        found = [r for r in records if r.rel_path == "testfile.txt"]
        assert len(found) == 1
        assert found[0].sha256 == expected_hash


# ---------------------------------------------------------------------------
# analyze_url()
# ---------------------------------------------------------------------------

class TestAnalyzeUrl:
    def _make_blocked_result(self, reason: str = "IP-literal host is non-public: private"):
        r = MagicMock()
        r.blocked = True
        r.block_reason = reason
        r.success = False
        r.redirect_chain = []
        r.warnings = []
        r.content_type = None
        r.content_length = None
        r.content_disposition = None
        return r

    def _make_success_result(self, ct="application/pdf", cd=None, hops=None):
        r = MagicMock()
        r.blocked = False
        r.block_reason = ""
        r.success = True
        r.redirect_chain = hops or []
        r.warnings = []
        r.content_type = ct
        r.content_length = 1024
        r.content_disposition = cd
        return r

    def test_ssrf_blocked(self):
        fetch_result = self._make_blocked_result("private IP")
        findings = analyze_url("http://192.168.0.1/", fetch_result)
        rule_ids = {f.rule_id for f in findings}
        assert "URL-SSRF-BLOCKED" in rule_ids

    def test_https_downgrade_flagged(self):
        hop = MagicMock()
        hop.https_downgrade = True
        hop.cross_domain = False
        hop.ip_literal_redirect = False
        hop.url = "hxxp://example[.]com/file"
        hop.status_code = 302

        result = self._make_success_result(hops=[hop])
        findings = analyze_url("https://example.com/file", result)
        rule_ids = {f.rule_id for f in findings}
        assert "URL-REDIRECT-HTTPS-DOWNGRADE" in rule_ids

    def test_cross_domain_redirect(self):
        hop0 = MagicMock()
        hop0.https_downgrade = False
        hop0.cross_domain = False
        hop0.ip_literal_redirect = False
        hop0.url = "hxxps://origin[.]com/"
        hop0.status_code = 302

        hop1 = MagicMock()
        hop1.https_downgrade = False
        hop1.cross_domain = True
        hop1.ip_literal_redirect = False
        hop1.url = "hxxps://different[.]com/"
        hop1.status_code = 200

        result = self._make_success_result(hops=[hop0, hop1])
        findings = analyze_url("https://origin.com/", result)
        rule_ids = {f.rule_id for f in findings}
        assert "URL-REDIRECT-CROSS-DOMAIN" in rule_ids

    def test_ip_literal_redirect(self):
        hop = MagicMock()
        hop.https_downgrade = False
        hop.cross_domain = False
        hop.ip_literal_redirect = True
        hop.url = "hxxps://8[.]8[.]8[.]8/"
        hop.status_code = 301

        result = self._make_success_result(hops=[hop])
        findings = analyze_url("https://example.com/", result)
        rule_ids = {f.rule_id for f in findings}
        assert "URL-REDIRECT-IP-LITERAL" in rule_ids

    def test_content_type_mismatch(self):
        # URL says .pdf, Content-Type says .exe
        result = self._make_success_result(ct="application/x-dosexec")
        findings = analyze_url("https://example.com/file.pdf", result)
        rule_ids = {f.rule_id for f in findings}
        assert "URL-CONTENT-TYPE-MISMATCH" in rule_ids

    def test_content_disposition_mismatch(self):
        result = self._make_success_result(
            ct="application/pdf",
            cd='attachment; filename="evil.exe"',
        )
        findings = analyze_url("https://example.com/document.pdf", result)
        rule_ids = {f.rule_id for f in findings}
        assert "URL-CONTENT-TYPE-MISMATCH" in rule_ids

    def test_no_issues_returns_empty_or_informational(self):
        result = self._make_success_result(ct="application/pdf")
        findings = analyze_url("https://example.com/report.pdf", result)
        # No mismatch, no redirect → either empty or only informational
        non_info = [
            f for f in findings
            if f.risk_category not in (
                __import__("models").RiskCategory.INFORMATIONAL,
            )
        ]
        assert len(non_info) == 0
