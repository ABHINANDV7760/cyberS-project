"""
tests/test_risk_engine.py – Unit tests for engine/risk_engine.py

Coverage:
  - score_to_category() thresholds
  - compute_score() with triggered rules
  - Overrides: SSRF-BLOCKED, REP-MALICIOUS-REPORTED, FILE-EXEC-DISGUISED floor
  - "Unknown" when no findings
  - No output ever says "safe" unqualified
  - Reputation: no_data uses mandatory wording
  - Findings are persisted with correct is_simulated flags
  - No query strings stored in database
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import List
from datetime import datetime, timezone

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from engine.risk_engine import (
    RULE_DEFINITIONS,
    SCORE_THRESHOLDS,
    ScoreResult,
    compute_score,
    score_to_category,
)
from models import Evidence, Finding, RiskCategory


# ---------------------------------------------------------------------------
# score_to_category() thresholds
# ---------------------------------------------------------------------------

class TestScoreToCategory:
    def test_zero_is_informational(self):
        assert score_to_category(0.0) == RiskCategory.INFORMATIONAL

    def test_below_1_is_informational(self):
        assert score_to_category(0.5) == RiskCategory.INFORMATIONAL

    def test_1_is_low(self):
        assert score_to_category(1.0) == RiskCategory.LOW

    def test_19_is_low(self):
        assert score_to_category(19.9) == RiskCategory.LOW

    def test_20_is_medium(self):
        assert score_to_category(20.0) == RiskCategory.MEDIUM

    def test_49_is_medium(self):
        assert score_to_category(49.9) == RiskCategory.MEDIUM

    def test_50_is_high(self):
        assert score_to_category(50.0) == RiskCategory.HIGH

    def test_79_is_high(self):
        assert score_to_category(79.9) == RiskCategory.HIGH

    def test_80_is_critical(self):
        assert score_to_category(80.0) == RiskCategory.CRITICAL

    def test_large_score_is_critical(self):
        assert score_to_category(1000.0) == RiskCategory.CRITICAL


# ---------------------------------------------------------------------------
# compute_score()
# ---------------------------------------------------------------------------

def _make_finding(rule_id: str, is_simulated: bool = False) -> Finding:
    rule = RULE_DEFINITIONS.get(rule_id)
    if rule is None:
        title = rule_id
        description = f"Test finding for {rule_id}"
        risk_category = RiskCategory.LOW
    else:
        title = rule.title
        description = rule.description
        risk_category = rule.min_category
    return Finding(
        module="Download Guard",
        rule_id=rule_id,
        title=title,
        description=description,
        risk_category=risk_category,
        is_simulated=is_simulated,
    )


class TestComputeScore:
    def test_no_findings_returns_unknown(self):
        result = compute_score([])
        assert result.category == RiskCategory.UNKNOWN

    def test_single_low_rule(self):
        # FILE-ARCHIVE-UNINSPECTED = 15.0 → Low
        result = compute_score([_make_finding("FILE-ARCHIVE-UNINSPECTED")])
        assert result.category == RiskCategory.LOW
        assert result.score == pytest.approx(15.0)

    def test_two_medium_rules_stacks(self):
        # FILE-RISKY-EXT (40) + FILE-MACRO-CAPABLE (30) = 70 → High
        findings = [
            _make_finding("FILE-RISKY-EXT"),
            _make_finding("FILE-MACRO-CAPABLE"),
        ]
        result = compute_score(findings)
        assert result.score == pytest.approx(70.0)
        assert result.category == RiskCategory.HIGH

    def test_exec_disguised_floor_high(self):
        # FILE-HIGH-ENTROPY alone = 10 (Informational by score), but FILE-EXEC-DISGUISED
        # override lifts to HIGH
        findings = [
            _make_finding("FILE-HIGH-ENTROPY"),
            _make_finding("FILE-EXEC-DISGUISED"),
        ]
        result = compute_score(findings)
        assert result.category in (RiskCategory.HIGH, RiskCategory.CRITICAL)

    def test_ssrf_block_returns_blocked(self):
        result = compute_score([_make_finding("URL-SSRF-BLOCKED")])
        assert result.category == RiskCategory.BLOCKED

    def test_rep_malicious_returns_critical(self):
        result = compute_score([_make_finding("REP-MALICIOUS-REPORTED")])
        assert result.category == RiskCategory.CRITICAL

    def test_override_note_present_for_overrides(self):
        result = compute_score([_make_finding("REP-MALICIOUS-REPORTED")])
        assert result.override_note is not None

    def test_breakdown_contains_all_findings(self):
        findings = [
            _make_finding("FILE-RISKY-EXT"),
            _make_finding("FILE-ARCHIVE-UNINSPECTED"),
        ]
        result = compute_score(findings)
        rule_ids_in_breakdown = {entry["rule_id"] for entry in result.breakdown}
        assert "FILE-RISKY-EXT" in rule_ids_in_breakdown
        assert "FILE-ARCHIVE-UNINSPECTED" in rule_ids_in_breakdown

    def test_score_is_sum_of_weights(self):
        findings = [
            _make_finding("FILE-RISKY-EXT"),       # 40
            _make_finding("FILE-HIGH-ENTROPY"),     # 10
        ]
        result = compute_score(findings)
        expected = (
            RULE_DEFINITIONS["FILE-RISKY-EXT"].base_weight +
            RULE_DEFINITIONS["FILE-HIGH-ENTROPY"].base_weight
        )
        assert result.score == pytest.approx(expected)

    def test_critical_score_rtlo(self):
        # FILE-RTLO = 90 → Critical
        result = compute_score([_make_finding("FILE-RTLO")])
        assert result.category == RiskCategory.CRITICAL

    def test_informational_consistent(self):
        # FILE-CONSISTENT = 0 weight → Informational
        result = compute_score([_make_finding("FILE-CONSISTENT")])
        assert result.category == RiskCategory.INFORMATIONAL
        assert result.score == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# "Safe" / unqualified language is never used
# ---------------------------------------------------------------------------

class TestNoSafeLanguage:
    def test_no_issues_text_does_not_say_safe(self):
        result = compute_score([])
        # ScoreResult has a no_issues_text field; it must not say "safe" unqualified
        text = result.no_issues_text.lower()
        # The text says "does not guarantee" so "safe" appears but is qualified
        assert "does not guarantee" in text
        # It must NOT say "this file is safe" or "url is safe" as a flat assertion
        assert "this file is safe" not in text
        assert "is safe." not in text.replace("does not guarantee the file or url is safe.", "")

    def test_risk_categories_never_say_safe(self):
        for cat in RiskCategory:
            assert "safe" not in cat.value.lower()

    def test_no_data_wording_mandatory(self):
        from integrations.reputation_provider import ReputationResult
        result = ReputationResult(
            status="no_data",
            detail="anything",
            source="test",
        )
        assert "does NOT mean" in result.display_detail
        assert "safe" in result.display_detail.lower()  # mentions safe but in the "does not mean safe" sense
        assert "No reputation data" in result.display_detail


# ---------------------------------------------------------------------------
# Persistence: is_simulated flag and no query strings
# ---------------------------------------------------------------------------

class TestPersistence:
    def test_simulated_finding_flag_preserved(self):
        finding = _make_finding("FILE-ARCHIVE-UNINSPECTED", is_simulated=True)
        assert finding.is_simulated is True

    def test_non_simulated_finding_flag(self):
        finding = _make_finding("FILE-RISKY-EXT", is_simulated=False)
        assert finding.is_simulated is False

    def test_no_query_string_in_to_dict(self):
        from models import Scan
        scan = Scan(
            module="Download Guard",
            target_label="https://example.com/file.pdf",
            risk_category=RiskCategory.LOW,
            score=15.0,
        )
        d = scan.to_dict()
        assert "?" not in d["target_label"]

    def test_scan_with_simulated_flag(self):
        from models import Scan
        scan = Scan(
            module="Download Guard",
            target_label="https://demo.example.test/clean.pdf",
            is_simulated=True,
            risk_category=RiskCategory.INFORMATIONAL,
            score=0.0,
        )
        d = scan.to_dict()
        assert d["is_simulated"] is True

    def test_database_add_and_retrieve(self, tmp_path):
        """Integration test: write to a temp DB and read back."""
        import os

        # Point DB to temp path
        os.environ["CYBERSHIELD360_DB"] = str(tmp_path / "test.db")

        # Patch DB_PATH
        import config as cfg_mod
        original_db = cfg_mod.DB_PATH
        cfg_mod.DB_PATH = tmp_path / "test.db"

        try:
            import database as db_mod
            db_mod.DB_PATH = tmp_path / "test.db"
            # Re-import to pick up patched path
            import importlib
            importlib.reload(db_mod)

            finding = _make_finding("FILE-RISKY-EXT", is_simulated=True)
            from models import Scan
            scan = Scan(
                module="Download Guard",
                target_label="test_file.exe",
                target_hash="abc123",
                target_type="PE Executable",
                risk_category=RiskCategory.MEDIUM,
                score=40.0,
                is_simulated=True,
                findings=[finding],
            )
            scan_id = db_mod.add_scan_with_findings(scan)
            assert scan_id > 0

            scans = db_mod.get_recent_scans(module="Download Guard")
            assert any(s["scan_id"] == scan_id for s in scans)

            findings_back = db_mod.get_findings_for_scan(scan_id)
            assert len(findings_back) == 1
            assert findings_back[0]["rule_id"] == "FILE-RISKY-EXT"
            assert findings_back[0]["is_simulated"] == 1

        finally:
            cfg_mod.DB_PATH = original_db
            if "CYBERSHIELD360_DB" in os.environ:
                del os.environ["CYBERSHIELD360_DB"]


# ---------------------------------------------------------------------------
# Rule definition completeness
# ---------------------------------------------------------------------------

class TestRuleDefinitions:
    def test_all_rules_have_required_fields(self):
        for rule_id, rule in RULE_DEFINITIONS.items():
            assert rule.rule_id == rule_id
            assert rule.title
            assert rule.description
            assert rule.base_weight >= 0
            assert isinstance(rule.min_category, RiskCategory)

    def test_min_categories_are_valid(self):
        valid_categories = set(RiskCategory)
        for rule in RULE_DEFINITIONS.values():
            assert rule.min_category in valid_categories

    def test_score_thresholds_are_descending(self):
        thresholds = [t for t, _ in SCORE_THRESHOLDS]
        assert thresholds == sorted(thresholds, reverse=True)
