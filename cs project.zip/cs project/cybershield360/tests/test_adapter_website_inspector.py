"""
tests/test_adapter_website_inspector.py
────────────────────────────────────────
Unit tests for cybershield360/adapters/website_inspector.py

Coverage
--------
  Adapter core:
    - Valid posture report → Scan with correct fields
    - Checks → Findings with correct RiskCategory mapping
    - Skipped entries → INFORMATIONAL Findings
    - Synthetic-data flag propagation (several sources)
    - AdapterError on bad input (None, non-dict, ok=false, missing checks)
    - Severity mapping (all 5 levels + unknown fallback)
    - Score and risk roll-up logic
    - Timestamp parsing (Z suffix, naive, malformed, missing)
    - Evidence items built from check fields
    - rule_id slug sanitisation
    - Target label has no query string

  Database integration:
    - settings table: set/get round-trip, overwrite, default on missing
    - delete_scan: removes scan + findings, returns True/False
    - delete_scans_older_than: respects days threshold, module filter
    - finding_id / input_type round-trip through DB
    - migration idempotency: calling init_db() twice does not error

  Model extensions:
    - Finding.finding_id is populated (UUID)
    - Evidence.is_observed_fact defaults to True
    - Scan.duration_seconds serialised in to_dict()
    - Finding.input_type serialised in to_dict()
"""
from __future__ import annotations

import json
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import pytest

# Put the project root on the path
sys.path.insert(0, str(Path(__file__).parent.parent))

from adapters.website_inspector import (
    AdapterError,
    MODULE_NAME,
    _check_to_finding,
    _map_severity,
    _parse_timestamp,
    _rule_id_from_check_id,
    _skipped_to_finding,
    posture_report_to_scan,
)
from models import Evidence, Finding, RiskCategory, Scan


# ─── Fixtures ────────────────────────────────────────────────────────────────

def _minimal_check(**kwargs) -> dict:
    """Return a minimal valid check dict, overriding any fields via kwargs."""
    base = {
        "id":         "header-x-frame-options",
        "tier":       1,
        "name":       "HTTP header: X-Frame-Options",
        "severity":   "Medium",
        "confidence": "High",
        "issue":      "X-Frame-Options header is missing",
        "remediation": "Add X-Frame-Options: DENY",
        "timestamp":  "2024-06-01T12:00:00.000Z",
    }
    base.update(kwargs)
    return base


def _minimal_report(**kwargs) -> dict:
    """Return a minimal valid posture report dict."""
    base = {
        "ok":              True,
        "reportTimestamp": "2024-06-01T12:00:00.000Z",
        "hostname":        "example.com",
        "targetUrl":       "https://example.com",
        "authorized":      True,
        "checks":          [_minimal_check()],
        "skipped":         [],
    }
    base.update(kwargs)
    return base


# ─── Severity mapping ────────────────────────────────────────────────────────

class TestMapSeverity:
    def test_critical(self):
        assert _map_severity("Critical") is RiskCategory.CRITICAL

    def test_high(self):
        assert _map_severity("High") is RiskCategory.HIGH

    def test_medium(self):
        assert _map_severity("Medium") is RiskCategory.MEDIUM

    def test_low(self):
        assert _map_severity("Low") is RiskCategory.LOW

    def test_info(self):
        assert _map_severity("Info") is RiskCategory.INFORMATIONAL

    def test_info_lowercase(self):
        assert _map_severity("info") is RiskCategory.INFORMATIONAL

    def test_unknown_string_fallback(self):
        assert _map_severity("wibble") is RiskCategory.INFORMATIONAL

    def test_none_fallback(self):
        assert _map_severity(None) is RiskCategory.UNKNOWN

    def test_integer_fallback(self):
        assert _map_severity(42) is RiskCategory.UNKNOWN


# ─── rule_id slug sanitisation ───────────────────────────────────────────────

class TestRuleIdFromCheckId:
    def test_normal(self):
        rid = _rule_id_from_check_id("header-x-frame-options")
        assert rid == "WSI-CHECK-HEADER-X-FRAME-OPTIONS"

    def test_special_chars_replaced(self):
        rid = _rule_id_from_check_id("foo bar!baz")
        # Spaces and '!' should be replaced with '-'
        assert "!" not in rid
        assert " " not in rid
        assert rid.startswith("WSI-CHECK-")

    def test_empty_string(self):
        rid = _rule_id_from_check_id("")
        assert rid.startswith("WSI-CHECK-")

    def test_none(self):
        rid = _rule_id_from_check_id(None)
        assert rid.startswith("WSI-CHECK-")


# ─── Timestamp parsing ───────────────────────────────────────────────────────

class TestParseTimestamp:
    def test_z_suffix(self):
        dt = _parse_timestamp("2024-06-01T12:00:00.000Z")
        assert dt.year == 2024
        assert dt.month == 6
        assert dt.tzinfo is None  # Stripped to naive

    def test_offset_stripped(self):
        dt = _parse_timestamp("2024-06-01T12:00:00+01:00")
        assert dt.tzinfo is None

    def test_malformed_returns_now(self):
        before = datetime.utcnow()
        dt = _parse_timestamp("not-a-date")
        after = datetime.utcnow()
        assert before <= dt <= after

    def test_none_returns_now(self):
        before = datetime.utcnow()
        dt = _parse_timestamp(None)
        after = datetime.utcnow()
        assert before <= dt <= after


# ─── check_to_finding ────────────────────────────────────────────────────────

class TestCheckToFinding:
    def test_basic_fields(self):
        check = _minimal_check()
        finding = _check_to_finding(check, is_simulated=False)

        assert finding.module == MODULE_NAME
        assert finding.rule_id == "WSI-CHECK-HEADER-X-FRAME-OPTIONS"
        assert finding.title == "HTTP header: X-Frame-Options"
        assert "X-Frame-Options header is missing" in finding.description
        assert finding.risk_category is RiskCategory.MEDIUM
        assert finding.is_simulated is False
        assert finding.input_type == "website"

    def test_simulated_propagated(self):
        finding = _check_to_finding(_minimal_check(), is_simulated=True)
        assert finding.is_simulated is True

    def test_evidence_has_tier(self):
        finding = _check_to_finding(_minimal_check(tier=0), is_simulated=False)
        tier_items = [e for e in finding.evidence if e.label == "Check tier"]
        assert tier_items
        assert "0" in tier_items[0].value

    def test_evidence_remediation_is_not_observed_fact(self):
        finding = _check_to_finding(_minimal_check(), is_simulated=False)
        remediation_items = [
            e for e in finding.evidence if e.label == "Suggested remediation"
        ]
        assert remediation_items
        assert remediation_items[0].is_observed_fact is False

    def test_evidence_timestamp_is_observed_fact(self):
        finding = _check_to_finding(_minimal_check(), is_simulated=False)
        ts_items = [e for e in finding.evidence if e.label == "Check timestamp (UTC)"]
        assert ts_items
        assert ts_items[0].is_observed_fact is True

    def test_missing_remediation_no_evidence_item(self):
        check = _minimal_check()
        check.pop("remediation", None)
        finding = _check_to_finding(check, is_simulated=False)
        rem_items = [e for e in finding.evidence if e.label == "Suggested remediation"]
        assert rem_items == []

    def test_finding_id_is_uuid(self):
        finding = _check_to_finding(_minimal_check(), is_simulated=False)
        import uuid
        # Should not raise
        uuid.UUID(finding.finding_id)

    def test_critical_check(self):
        finding = _check_to_finding(_minimal_check(severity="Critical"), is_simulated=False)
        assert finding.risk_category is RiskCategory.CRITICAL

    def test_info_check(self):
        finding = _check_to_finding(_minimal_check(severity="Info"), is_simulated=False)
        assert finding.risk_category is RiskCategory.INFORMATIONAL


# ─── skipped_to_finding ──────────────────────────────────────────────────────

class TestSkippedToFinding:
    def test_basic_fields(self):
        skipped = {
            "check":  "TLS certificate",
            "reason": "Locked — authorization confirmation required",
            "tier":   1,
        }
        finding = _skipped_to_finding(skipped, is_simulated=False)

        assert finding.risk_category is RiskCategory.INFORMATIONAL
        assert "WSI-SKIPPED" in finding.rule_id
        assert "TLS" in finding.rule_id or "TLS" in finding.title
        assert "Locked" in finding.description
        assert finding.input_type == "website"

    def test_reason_in_evidence(self):
        skipped = {"check": "DNS", "reason": "Timeout after 3s", "tier": 0}
        finding = _skipped_to_finding(skipped, is_simulated=False)
        reason_items = [e for e in finding.evidence if e.label == "Reason skipped"]
        assert reason_items
        assert "Timeout" in reason_items[0].value

    def test_missing_fields_do_not_crash(self):
        finding = _skipped_to_finding({}, is_simulated=False)
        assert finding.risk_category is RiskCategory.INFORMATIONAL


# ─── posture_report_to_scan ──────────────────────────────────────────────────

class TestPostureReportToScan:
    def test_happy_path(self):
        report = _minimal_report()
        scan = posture_report_to_scan(report)

        assert isinstance(scan, Scan)
        assert scan.module == MODULE_NAME
        assert scan.target_label == "https://example.com"  # No query string
        assert scan.target_type == "website"
        assert scan.scan_id is None  # Not yet persisted
        assert len(scan.findings) >= 1

    def test_query_string_stripped(self):
        report = _minimal_report(targetUrl="https://example.com/page?token=abc&id=1")
        scan = posture_report_to_scan(report)
        assert "?" not in scan.target_label
        assert "token" not in scan.target_label

    def test_skipped_entries_become_findings(self):
        skipped = [{"check": "TLS certificate", "reason": "Locked", "tier": 1}]
        report = _minimal_report(skipped=skipped)
        scan = posture_report_to_scan(report)
        skipped_findings = [
            f for f in scan.findings if f.rule_id.startswith("WSI-SKIPPED")
        ]
        assert len(skipped_findings) == 1

    def test_risk_rollup_critical_dominates(self):
        checks = [
            _minimal_check(severity="Info"),
            _minimal_check(id="crit-check", severity="Critical"),
            _minimal_check(id="low-check",  severity="Low"),
        ]
        report = _minimal_report(checks=checks)
        scan = posture_report_to_scan(report)
        assert scan.risk_category is RiskCategory.CRITICAL

    def test_score_increases_with_severity(self):
        low_report  = _minimal_report(checks=[_minimal_check(severity="Low")])
        high_report = _minimal_report(checks=[_minimal_check(severity="High")])
        assert posture_report_to_scan(high_report).score > posture_report_to_scan(low_report).score

    def test_empty_checks_returns_unknown_risk(self):
        report = _minimal_report(checks=[], skipped=[])
        scan = posture_report_to_scan(report)
        assert scan.risk_category is RiskCategory.UNKNOWN

    # ── Synthetic data flag detection ────────────────────────────────────────

    def test_synthetic_flag_from_syntheticData(self):
        report = _minimal_report(syntheticData=True)
        scan = posture_report_to_scan(report)
        assert scan.is_simulated is True

    def test_synthetic_flag_from_meta(self):
        report = _minimal_report()
        report["_meta"] = {"synthetic": True}
        scan = posture_report_to_scan(report)
        assert scan.is_simulated is True

    def test_synthetic_flag_from_is_simulated(self):
        report = _minimal_report(is_simulated=True)
        scan = posture_report_to_scan(report)
        assert scan.is_simulated is True

    def test_not_simulated_by_default(self):
        scan = posture_report_to_scan(_minimal_report())
        assert scan.is_simulated is False

    def test_simulated_propagated_to_all_findings(self):
        report = _minimal_report(
            syntheticData=True,
            skipped=[{"check": "TLS", "reason": "Locked", "tier": 1}],
        )
        scan = posture_report_to_scan(report)
        for finding in scan.findings:
            assert finding.is_simulated is True

    # ── Error handling ────────────────────────────────────────────────────────

    def test_none_raises(self):
        with pytest.raises(AdapterError):
            posture_report_to_scan(None)  # type: ignore[arg-type]

    def test_string_raises(self):
        with pytest.raises(AdapterError):
            posture_report_to_scan("not a dict")  # type: ignore[arg-type]

    def test_ok_false_raises(self):
        with pytest.raises(AdapterError, match="ok=false"):
            posture_report_to_scan({"ok": False, "error": "URL rejected"})

    def test_checks_not_list_raises(self):
        with pytest.raises(AdapterError):
            posture_report_to_scan(_minimal_report(checks="not a list"))

    def test_malformed_check_entries_skipped(self):
        # Non-dict entries in checks list should be silently skipped
        report = _minimal_report(checks=[_minimal_check(), "bad", None, 42])
        scan = posture_report_to_scan(report)
        # The one valid check should produce 1 finding
        assert len([f for f in scan.findings if not f.rule_id.startswith("WSI-SKIPPED")]) == 1

    def test_missing_hostname_uses_unknown(self):
        report = _minimal_report()
        report.pop("hostname", None)
        scan = posture_report_to_scan(report)
        assert "unknown" in scan.target_label or "example.com" in scan.target_label


# ─── Model extension tests ───────────────────────────────────────────────────

class TestModelExtensions:
    def test_finding_id_auto_populated(self):
        import uuid
        f = Finding(
            module="test", rule_id="R1", title="T", description="D",
            risk_category=RiskCategory.LOW,
        )
        uuid.UUID(f.finding_id)  # Must not raise

    def test_finding_id_unique_per_instance(self):
        f1 = Finding(module="m", rule_id="r", title="t", description="d", risk_category=RiskCategory.LOW)
        f2 = Finding(module="m", rule_id="r", title="t", description="d", risk_category=RiskCategory.LOW)
        assert f1.finding_id != f2.finding_id

    def test_finding_input_type_default(self):
        f = Finding(module="m", rule_id="r", title="t", description="d", risk_category=RiskCategory.LOW)
        assert f.input_type == "file"

    def test_finding_to_dict_includes_finding_id(self):
        f = Finding(module="m", rule_id="r", title="t", description="d", risk_category=RiskCategory.LOW)
        d = f.to_dict()
        assert "finding_id" in d
        assert d["finding_id"] == f.finding_id

    def test_finding_to_dict_includes_input_type(self):
        f = Finding(module="m", rule_id="r", title="t", description="d",
                    risk_category=RiskCategory.LOW, input_type="website")
        d = f.to_dict()
        assert d["input_type"] == "website"

    def test_evidence_is_observed_fact_default(self):
        e = Evidence(label="L", value="V")
        assert e.is_observed_fact is True

    def test_evidence_is_observed_fact_false(self):
        e = Evidence(label="L", value="V", is_observed_fact=False)
        assert e.is_observed_fact is False

    def test_scan_duration_seconds_in_to_dict(self):
        s = Scan(module="m", target_label="t", duration_seconds=4.7)
        d = s.to_dict()
        assert d["duration_seconds"] == pytest.approx(4.7)

    def test_scan_duration_seconds_none_in_to_dict(self):
        s = Scan(module="m", target_label="t")
        d = s.to_dict()
        assert d["duration_seconds"] is None


# ─── Database extension tests ────────────────────────────────────────────────

@pytest.fixture()
def tmp_db(tmp_path):
    """Provide a temporary isolated database for each test."""
    db_file = tmp_path / "test_stage1.db"
    with patch("config.DB_PATH", db_file):
        import database
        import importlib
        # Re-import with the patched path in scope
        importlib.reload(database)
        yield database, db_file
    # Cleanup is automatic via tmp_path


class TestSettingsTable:
    def test_set_and_get_string(self, tmp_db):
        db, _ = tmp_db
        db.set_setting("my_key", "hello")
        assert db.get_setting("my_key") == "hello"

    def test_set_and_get_int(self, tmp_db):
        db, _ = tmp_db
        db.set_setting("retention_days", 90)
        assert db.get_setting("retention_days") == 90

    def test_set_and_get_dict(self, tmp_db):
        db, _ = tmp_db
        db.set_setting("feature_flags", {"dark_mode": True, "beta": False})
        result = db.get_setting("feature_flags")
        assert result == {"dark_mode": True, "beta": False}

    def test_overwrite(self, tmp_db):
        db, _ = tmp_db
        db.set_setting("x", "first")
        db.set_setting("x", "second")
        assert db.get_setting("x") == "second"

    def test_default_on_missing_key(self, tmp_db):
        db, _ = tmp_db
        assert db.get_setting("nonexistent", default="fallback") == "fallback"

    def test_default_is_none_when_not_specified(self, tmp_db):
        db, _ = tmp_db
        assert db.get_setting("missing") is None


class TestDeleteScan:
    def _make_scan(self) -> Scan:
        return Scan(
            module="Test Module",
            target_label="https://example.com",
            risk_category=RiskCategory.LOW,
            score=5.0,
            findings=[
                Finding(
                    module="Test Module",
                    rule_id="R1",
                    title="Test finding",
                    description="desc",
                    risk_category=RiskCategory.LOW,
                )
            ],
        )

    def test_delete_removes_scan_and_findings(self, tmp_db):
        db, _ = tmp_db
        scan = self._make_scan()
        scan_id = db.add_scan_with_findings(scan)

        assert db.delete_scan(scan_id) is True
        # Scan should be gone
        assert db.get_recent_scans() == []
        # Findings should be gone
        assert db.get_findings_for_scan(scan_id) == []

    def test_delete_nonexistent_returns_false(self, tmp_db):
        db, _ = tmp_db
        assert db.delete_scan(99999) is False

    def test_delete_one_leaves_others(self, tmp_db):
        db, _ = tmp_db
        id1 = db.add_scan_with_findings(self._make_scan())
        id2 = db.add_scan_with_findings(self._make_scan())

        db.delete_scan(id1)
        remaining = db.get_recent_scans()
        assert len(remaining) == 1
        assert remaining[0]["scan_id"] == id2


class TestDeleteScansOlderThan:
    def _make_old_scan(self, db, days_ago: int, module: str = "M") -> int:
        scan = Scan(
            module=module,
            target_label="https://old.example.com",
            scanned_at=datetime.utcnow() - timedelta(days=days_ago),
        )
        return db.add_scan_with_findings(scan)

    def test_deletes_old_scans(self, tmp_db):
        db, _ = tmp_db
        self._make_old_scan(db, days_ago=100)
        self._make_old_scan(db, days_ago=200)
        count = db.delete_scans_older_than(days=90)
        assert count == 2
        assert db.get_recent_scans() == []

    def test_keeps_recent_scans(self, tmp_db):
        db, _ = tmp_db
        self._make_old_scan(db, days_ago=10)
        count = db.delete_scans_older_than(days=90)
        assert count == 0
        assert len(db.get_recent_scans()) == 1

    def test_mixed_old_and_recent(self, tmp_db):
        db, _ = tmp_db
        self._make_old_scan(db, days_ago=200)  # should be deleted
        self._make_old_scan(db, days_ago=5)    # should be kept
        count = db.delete_scans_older_than(days=90)
        assert count == 1
        assert len(db.get_recent_scans()) == 1

    def test_module_filter_deletes_only_target_module(self, tmp_db):
        db, _ = tmp_db
        self._make_old_scan(db, days_ago=200, module="Alpha")
        self._make_old_scan(db, days_ago=200, module="Beta")
        count = db.delete_scans_older_than(days=90, module="Alpha")
        assert count == 1
        remaining = db.get_recent_scans()
        assert len(remaining) == 1
        assert remaining[0]["module"] == "Beta"

    def test_negative_days_raises(self, tmp_db):
        db, _ = tmp_db
        with pytest.raises(ValueError):
            db.delete_scans_older_than(days=-1)

    def test_zero_days_deletes_everything(self, tmp_db):
        db, _ = tmp_db
        self._make_old_scan(db, days_ago=1)
        # 0 days = everything older than right now
        count = db.delete_scans_older_than(days=0)
        assert count >= 1


class TestFindingIdAndInputTypeRoundTrip:
    def test_finding_id_persisted_and_retrieved(self, tmp_db):
        db, _ = tmp_db
        finding = Finding(
            module="WSI",
            rule_id="WSI-CHECK-TLS",
            title="TLS check",
            description="TLS is valid",
            risk_category=RiskCategory.INFORMATIONAL,
            input_type="website",
        )
        scan = Scan(module="WSI", target_label="https://example.com", findings=[finding])
        scan_id = db.add_scan_with_findings(scan)

        rows = db.get_findings_for_scan(scan_id)
        assert len(rows) == 1
        assert rows[0]["finding_id"] == finding.finding_id
        assert rows[0]["input_type"] == "website"

    def test_input_type_file_default_persisted(self, tmp_db):
        db, _ = tmp_db
        finding = Finding(
            module="DG",
            rule_id="FILE-R1",
            title="T",
            description="D",
            risk_category=RiskCategory.LOW,
        )
        scan = Scan(module="DG", target_label="test.exe", findings=[finding])
        scan_id = db.add_scan_with_findings(scan)
        rows = db.get_findings_for_scan(scan_id)
        assert rows[0]["input_type"] == "file"


class TestInitDbIdempotent:
    def test_calling_init_db_twice_does_not_raise(self, tmp_db):
        db, _ = tmp_db
        db.init_db()
        db.init_db()  # Second call must be safe


# ─── End-to-end adapter + database integration ───────────────────────────────

class TestAdapterDatabaseIntegration:
    """
    End-to-end test: convert a posture report → Scan, persist to DB, read back.
    """

    def _make_report(self) -> dict:
        return {
            "ok":              True,
            "reportTimestamp": "2024-06-01T14:00:00.000Z",
            "hostname":        "test.example.com",
            "targetUrl":       "https://test.example.com",
            "authorized":      True,
            "checks": [
                {
                    "id":         "header-strict-transport-security",
                    "tier":       1,
                    "name":       "HTTP header: Strict-Transport-Security",
                    "severity":   "Info",
                    "confidence": "High",
                    "issue":      "HSTS present with max-age=31536000",
                    "evidence":   "max-age=31536000; includeSubDomains",
                    "timestamp":  "2024-06-01T14:00:01.000Z",
                },
                {
                    "id":         "header-content-security-policy",
                    "tier":       1,
                    "name":       "HTTP header: Content-Security-Policy",
                    "severity":   "High",
                    "confidence": "High",
                    "issue":      "CSP contains 'unsafe-inline'",
                    "remediation": "Remove 'unsafe-inline' from CSP.",
                    "timestamp":  "2024-06-01T14:00:01.000Z",
                },
            ],
            "skipped": [
                {
                    "check":  "robots.txt",
                    "reason": "Timeout",
                    "tier":   1,
                }
            ],
        }

    def test_full_round_trip(self, tmp_db):
        db, _ = tmp_db
        report = self._make_report()
        scan = posture_report_to_scan(report)

        # Persist
        scan_id = db.add_scan_with_findings(scan)

        # Read back scan
        scans = db.get_recent_scans()
        assert len(scans) == 1
        assert scans[0]["module"] == "Website Security Inspector"
        assert scans[0]["target_label"] == "https://test.example.com"
        assert scans[0]["risk_category"] == "High"  # CSP finding is High

        # Read back findings
        findings = db.get_findings_for_scan(scan_id)
        assert len(findings) == 3  # 2 checks + 1 skipped
        input_types = {f["input_type"] for f in findings}
        assert input_types == {"website"}

    def test_synthetic_scan_flagged_in_db(self, tmp_db):
        db, _ = tmp_db
        report = self._make_report()
        report["syntheticData"] = True
        scan = posture_report_to_scan(report)
        scan_id = db.add_scan_with_findings(scan)
        scans = db.get_recent_scans()
        assert scans[0]["is_simulated"] == 1
