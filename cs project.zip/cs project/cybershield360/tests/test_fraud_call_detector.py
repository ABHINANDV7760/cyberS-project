"""
tests/test_fraud_call_detector.py – Unit tests for modules/fraud_call_detector.py

Coverage
--------
  Core analysis:
    - Each of the 8 rules fires on a transcript containing matching text
    - Each rule does NOT fire on neutral text
    - Empty transcript → empty findings, no crash
    - Whitespace-only transcript → empty findings
    - Very long transcript is truncated (no crash, was_truncated=True)
    - Multiple rules fire simultaneously on complex transcript

  Snippets and privacy:
    - Matched snippets are short (≤ 2×SNIPPET_WINDOW + match length)
    - Full transcript is not reproduced in any finding's evidence
    - HTML special characters in transcript are escaped in evidence values

  URL extraction:
    - http/https URLs extracted and normalised (lower-case, deduplicated)
    - www. domain patterns extracted
    - No URLs in text → empty list

  AnalysisResult:
    - disclaimer is always present and non-empty
    - safety_actions list is non-empty
    - is_simulated flag propagated to all findings
    - input_type is "transcript" on all findings

  No-audio guarantee:
    - Module has no audio-reading or audio-processing code path

  Risk engine integration:
    - All CALL-* rule IDs present in RULE_DEFINITIONS
    - compute_score() works on call-detector findings (no KeyError)
    - High-risk transcript scores Critical or High (≥50 points)

  Demo fixture:
    - demo_call_transcript.json parses cleanly
    - Running analysis on demo produces findings for ≥4 distinct rules
    - Demo is marked synthetic in fixture
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from modules.fraud_call_detector import (
    CALL_RULE_DEFINITIONS,
    MAX_TRANSCRIPT_CHARS,
    AnalysisResult,
    analyse_transcript,
    extract_urls,
)
from engine.risk_engine import RULE_DEFINITIONS, compute_score
from models import RiskCategory


# ─── Helper transcripts (minimal, one rule at a time) ────────────────────────

_TRIGGERS: dict[str, str] = {
    "CALL-OTP-REQUEST": (
        "Please read out the OTP we just sent you so we can verify your identity."
    ),
    "CALL-URGENT-PAYMENT": (
        "You must pay now or your account will be suspended. This is your final notice."
    ),
    "CALL-IMPERSONATION": (
        "I'm calling from Microsoft technical support team about your computer."
    ),
    "CALL-THREAT-COERCION": (
        "A warrant for your arrest has been issued. You will be arrested if you don't comply."
    ),
    "CALL-PRIZE-LOTTERY": (
        "Congratulations! You've won the lottery — claim your prize money today."
    ),
    "CALL-REMOTE-ACCESS": (
        "Please install AnyDesk on your computer so we can check your account remotely."
    ),
    "CALL-SUSPICIOUS-URL": (
        "Please go to this link: https://secure-bank-verify.com/login to confirm."
    ),
    "CALL-UNUSUAL-PAYMENT": (
        "You'll need to buy four iTunes gift cards worth £100 each to secure your account."
    ),
}

_NEUTRAL = (
    "Thank you for calling customer services. How can I help you today? "
    "Your account balance is available in the mobile app. Have a nice day."
)


# ─── Each rule fires ──────────────────────────────────────────────────────────

class TestEachRuleFires:
    @pytest.mark.parametrize("rule_id,transcript", list(_TRIGGERS.items()))
    def test_rule_fires(self, rule_id: str, transcript: str):
        result = analyse_transcript(transcript)
        triggered = {f.rule_id for f in result.findings}
        assert rule_id in triggered, (
            f"Expected rule {rule_id!r} to fire on: {transcript!r}\n"
            f"Triggered rules: {triggered}"
        )

    @pytest.mark.parametrize("rule_id", list(_TRIGGERS.keys()))
    def test_rule_does_not_fire_on_neutral(self, rule_id: str):
        result = analyse_transcript(_NEUTRAL)
        triggered = {f.rule_id for f in result.findings}
        assert rule_id not in triggered, (
            f"Rule {rule_id!r} fired on neutral text (false positive)"
        )


# ─── Empty / invalid input ────────────────────────────────────────────────────

class TestEmptyInput:
    def test_empty_string(self):
        result = analyse_transcript("")
        assert result.findings == []
        assert result.extracted_urls == []
        assert result.input_length == 0

    def test_whitespace_only(self):
        result = analyse_transcript("   \n\t  ")
        assert result.findings == []

    def test_none_style_empty_does_not_raise(self):
        # Callers should pass a string; if they pass a falsy value it's handled
        result = analyse_transcript("")
        assert isinstance(result, AnalysisResult)


# ─── Truncation ───────────────────────────────────────────────────────────────

class TestTruncation:
    def test_long_transcript_truncated(self):
        long_text = "a " * (MAX_TRANSCRIPT_CHARS + 500)
        result = analyse_transcript(long_text)
        assert result.was_truncated is True
        assert result.input_length == MAX_TRANSCRIPT_CHARS

    def test_short_transcript_not_truncated(self):
        result = analyse_transcript("Hello, how are you?")
        assert result.was_truncated is False


# ─── Snippets and privacy ─────────────────────────────────────────────────────

class TestSnippetsAndPrivacy:
    def test_snippet_length_is_bounded(self):
        from modules.fraud_call_detector import SNIPPET_WINDOW
        result = analyse_transcript(_TRIGGERS["CALL-OTP-REQUEST"])
        for finding in result.findings:
            for ev in finding.evidence:
                if ev.label.startswith("Matched phrase"):
                    # Snippet must be shorter than 2 × window + some match + markers
                    assert len(ev.value) < 2 * SNIPPET_WINDOW + 100, (
                        f"Snippet too long: {len(ev.value)} chars"
                    )

    def test_full_transcript_not_in_evidence(self):
        # Build a transcript long enough that a full copy would be detectable
        long_trigger = (
            "Please read out the OTP now. " * 20
            + "Normal text that should not appear. " * 30
        )
        result = analyse_transcript(long_trigger)
        full_marker = "Normal text that should not appear"
        for finding in result.findings:
            for ev in finding.evidence:
                if ev.label.startswith("Matched phrase"):
                    assert full_marker not in ev.value, (
                        "Full transcript content found in evidence snippet"
                    )

    def test_html_special_chars_escaped_in_evidence(self):
        # Inject HTML into the transcript — must be escaped in evidence
        inject = 'Read the OTP: <script>alert("xss")</script>'
        result = analyse_transcript(inject)
        for finding in result.findings:
            for ev in finding.evidence:
                assert "<script>" not in ev.value, (
                    "Unescaped <script> found in evidence value"
                )
                assert "<script>" not in (ev.raw or ""), (
                    "Unescaped <script> found in evidence raw"
                )


# ─── URL extraction ───────────────────────────────────────────────────────────

class TestUrlExtraction:
    def test_https_url_extracted(self):
        urls = extract_urls("Visit https://example.com/page for details.")
        assert any("example.com" in u for u in urls)

    def test_www_url_extracted(self):
        urls = extract_urls("Go to www.scam-site.co.uk/verify now.")
        assert any("scam-site.co.uk" in u for u in urls)

    def test_urls_deduplicated(self):
        text = "Go to https://x.com and https://x.com and https://x.com"
        urls = extract_urls(text)
        assert len(urls) == 1

    def test_urls_normalised_lowercase(self):
        urls = extract_urls("Visit HTTPS://EXAMPLE.COM/page")
        assert all(u == u.lower() for u in urls)

    def test_no_urls_returns_empty_list(self):
        urls = extract_urls("There are no links in this message at all.")
        assert urls == []

    def test_multiple_distinct_urls(self):
        text = "See https://a.com and https://b.com for info."
        urls = extract_urls(text)
        assert len(urls) == 2


# ─── AnalysisResult structure ─────────────────────────────────────────────────

class TestAnalysisResult:
    def test_disclaimer_always_present(self):
        result = analyse_transcript(_TRIGGERS["CALL-OTP-REQUEST"])
        assert result.disclaimer
        assert "assessment" in result.disclaimer.lower() or "not proof" in result.disclaimer.lower()

    def test_safety_actions_present(self):
        result = analyse_transcript(_TRIGGERS["CALL-OTP-REQUEST"])
        assert len(result.safety_actions) >= 3

    def test_is_simulated_propagated(self):
        result = analyse_transcript(_TRIGGERS["CALL-OTP-REQUEST"], is_simulated=True)
        for f in result.findings:
            assert f.is_simulated is True

    def test_not_simulated_by_default(self):
        result = analyse_transcript(_TRIGGERS["CALL-OTP-REQUEST"])
        for f in result.findings:
            assert f.is_simulated is False

    def test_input_type_is_transcript(self):
        result = analyse_transcript(_TRIGGERS["CALL-OTP-REQUEST"])
        for f in result.findings:
            assert f.input_type == "transcript"

    def test_finding_module_name_is_correct(self):
        from config import MODULE_FRAUD_CALL_DETECTOR
        result = analyse_transcript(_TRIGGERS["CALL-OTP-REQUEST"])
        for f in result.findings:
            assert f.module == MODULE_FRAUD_CALL_DETECTOR


# ─── No-audio guarantee ───────────────────────────────────────────────────────

class TestNoAudioPath:
    """
    The module must contain NO audio-processing code.
    These tests check the module source does not import audio libraries.
    """
    def test_no_audio_import_in_module(self):
        source = Path(__file__).parent.parent / "modules" / "fraud_call_detector.py"
        text = source.read_text(encoding="utf-8")
        forbidden = ["pyaudio", "soundfile", "librosa", "wave.open", "speech_recognition",
                     "whisper", "pydub", "audioop"]
        for lib in forbidden:
            assert lib not in text, (
                f"Audio library {lib!r} found in fraud_call_detector.py — "
                "audio processing is not permitted in this module"
            )

    def test_no_audio_claim_in_analysis_result(self):
        # analyse_transcript must not mention audio in its output for text input
        result = analyse_transcript("Please share your OTP now.")
        for f in result.findings:
            for ev in f.evidence:
                assert "audio" not in ev.label.lower()
                assert "audio" not in ev.value.lower()


# ─── Risk engine integration ──────────────────────────────────────────────────

class TestRiskEngineIntegration:
    def test_all_call_rule_ids_in_rule_definitions(self):
        for rule_id in CALL_RULE_DEFINITIONS:
            assert rule_id in RULE_DEFINITIONS, (
                f"Call rule {rule_id!r} is not registered in engine/risk_engine.py"
            )

    def test_compute_score_on_call_findings(self):
        result = analyse_transcript(_TRIGGERS["CALL-OTP-REQUEST"])
        # Must not raise KeyError or any exception
        score_result = compute_score(result.findings)
        assert score_result.score >= 0

    def test_high_risk_transcript_scores_high_or_critical(self):
        # Combine several high-severity triggers
        combined = " ".join([
            _TRIGGERS["CALL-OTP-REQUEST"],
            _TRIGGERS["CALL-URGENT-PAYMENT"],
            _TRIGGERS["CALL-REMOTE-ACCESS"],
            _TRIGGERS["CALL-UNUSUAL-PAYMENT"],
        ])
        result = analyse_transcript(combined)
        score_result = compute_score(result.findings)
        assert score_result.score >= 50, (
            f"Expected score ≥ 50 for high-risk transcript, got {score_result.score}"
        )
        assert score_result.category in (RiskCategory.HIGH, RiskCategory.CRITICAL)

    def test_neutral_transcript_has_no_findings(self):
        result = analyse_transcript(_NEUTRAL)
        assert result.findings == []
        score_result = compute_score(result.findings)
        assert score_result.category == RiskCategory.UNKNOWN

    def test_all_call_rules_have_matching_weights(self):
        for rule_id, call_rule in CALL_RULE_DEFINITIONS.items():
            engine_rule = RULE_DEFINITIONS.get(rule_id)
            assert engine_rule is not None
            assert engine_rule.base_weight == call_rule.base_weight, (
                f"Rule {rule_id}: weight mismatch "
                f"(call module={call_rule.base_weight}, "
                f"engine={engine_rule.base_weight})"
            )


# ─── Multiple rules fire simultaneously ───────────────────────────────────────

class TestMultipleRules:
    def test_two_rules_fire_together(self):
        text = _TRIGGERS["CALL-OTP-REQUEST"] + " " + _TRIGGERS["CALL-IMPERSONATION"]
        result = analyse_transcript(text)
        triggered = {f.rule_id for f in result.findings}
        assert "CALL-OTP-REQUEST" in triggered
        assert "CALL-IMPERSONATION" in triggered

    def test_all_eight_rules_fire_on_combined_transcript(self):
        combined = " ".join(_TRIGGERS.values())
        result = analyse_transcript(combined)
        triggered = {f.rule_id for f in result.findings}
        assert triggered == set(_TRIGGERS.keys()), (
            f"Missing rules: {set(_TRIGGERS.keys()) - triggered}"
        )


# ─── Demo fixture ─────────────────────────────────────────────────────────────

class TestDemoFixture:
    @pytest.fixture(autouse=True)
    def _load_fixture(self):
        fixture_path = Path(__file__).parent.parent / "data" / "demo_call_transcript.json"
        self.fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
        self.transcript = self.fixture["transcript"]

    def test_fixture_parses_cleanly(self):
        assert isinstance(self.transcript, str)
        assert len(self.transcript) > 100

    def test_fixture_is_marked_synthetic(self):
        assert self.fixture["_meta"]["synthetic"] is True

    def test_demo_produces_findings_for_multiple_rules(self):
        result = analyse_transcript(self.transcript, is_simulated=True)
        triggered = {f.rule_id for f in result.findings}
        assert len(triggered) >= 4, (
            f"Expected ≥4 rules to trigger on demo transcript, got {triggered}"
        )

    def test_demo_all_findings_marked_simulated(self):
        result = analyse_transcript(self.transcript, is_simulated=True)
        for f in result.findings:
            assert f.is_simulated is True

    def test_demo_extracts_urls(self):
        result = analyse_transcript(self.transcript)
        # The demo transcript contains a URL
        assert len(result.extracted_urls) >= 1
