"""
config.py – Application-wide configuration for CyberShield 360.

All secrets are read from environment variables ONLY. They are never
hard-coded, logged, or displayed in the UI.
"""
from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Project layout
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
SAMPLES_DIR = BASE_DIR / "samples"
DB_PATH = BASE_DIR / "cybershield360.db"

# ---------------------------------------------------------------------------
# Optional API keys (read from environment; None if not set)
# ---------------------------------------------------------------------------

VIRUSTOTAL_API_KEY: str | None = os.environ.get("VIRUSTOTAL_API_KEY")
URLHAUS_API_KEY: str | None = os.environ.get("URLHAUS_API_KEY")
GOOGLE_SAFE_BROWSING_API_KEY: str | None = os.environ.get("GOOGLE_SAFE_BROWSING_API_KEY")

# ---------------------------------------------------------------------------
# safe_fetch tuning
# ---------------------------------------------------------------------------

SAFE_FETCH_CONNECT_TIMEOUT: float = 3.0   # seconds
SAFE_FETCH_READ_TIMEOUT: float = 5.0      # seconds
SAFE_FETCH_WALL_CLOCK_BUDGET: float = 8.0 # total seconds per URL chain
SAFE_FETCH_MAX_HOPS: int = 5
SAFE_FETCH_ALLOWED_PORTS: set[int] = {80, 443, 8080, 8443}
SAFE_FETCH_MAX_URL_LENGTH: int = 2048
SAFE_FETCH_MAX_BODY_BYTES: int = 65536    # 64 KB cap on any accidental body read
SAFE_FETCH_USER_AGENT: str = "CyberShield360-SafeFetch/1.0 (security-inspection-tool)"
SAFE_FETCH_MAX_RESPONSE_HEADERS: int = 100
SAFE_FETCH_RATE_LIMIT_PER_MINUTE: int = 20  # per session

# ---------------------------------------------------------------------------
# File analysis tuning
# ---------------------------------------------------------------------------

FILE_MAX_SIZE_BYTES: int = 200 * 1024 * 1024   # 200 MB per-file cap
FILE_EMPTY_THRESHOLD_BYTES: int = 0            # 0 bytes → empty/truncated
FILE_CHUNK_SIZE: int = 1024 * 1024              # 1 MB read chunk
FILE_ENTROPY_WINDOW: int = 1024 * 1024          # bytes analysed for entropy
FILE_ENTROPY_THRESHOLD: float = 7.2             # bits/byte; above → flag
FOLDER_MAX_FILES: int = 5000
FOLDER_MAX_DEPTH: int = 20

# ---------------------------------------------------------------------------
# Application metadata
# ---------------------------------------------------------------------------

APP_NAME = "CyberShield 360"
APP_VERSION = "1.0.0"
MODULE_DOWNLOAD_GUARD    = "Download Guard"
MODULE_WEBSITE_INSPECTOR = "Website Security Inspector"
MODULE_FRAUD_CALL_DETECTOR = "Fraud Call Detector"
MODULE_EMAIL_BREACH      = "Email Breach Detective"

# ---------------------------------------------------------------------------
# Optional transcription provider (audio → text)
# Set TRANSCRIPTION_PROVIDER=openai-whisper and OPENAI_API_KEY to enable.
# When unset the audio upload tab is hidden and text-only mode is active.
# ---------------------------------------------------------------------------

TRANSCRIPTION_PROVIDER: str | None = os.environ.get("TRANSCRIPTION_PROVIDER")
OPENAI_API_KEY: str | None         = os.environ.get("OPENAI_API_KEY")

# Permitted audio MIME types (only used when transcription is configured)
AUDIO_ALLOWED_TYPES: list[str] = ["audio/wav", "audio/mpeg", "audio/mp4",
                                   "audio/ogg", "audio/webm", "audio/x-m4a"]
# Max audio file size (10 MB)
AUDIO_MAX_BYTES: int = 10 * 1024 * 1024

# ---------------------------------------------------------------------------
# Retention defaults (days; 0 = keep forever)
# ---------------------------------------------------------------------------

RETENTION_DEFAULT_DAYS: int = 90   # Delete scans older than 90 days
