"""
adapters/ – Converts output from external modules into the shared
CyberShield 360 Finding/Scan model so that all results can be stored,
compared, and displayed through a single data model.

Currently available adapters:
  - website_inspector  : converts Module 4 (Node.js) posture reports
"""
