"""
adapters/website_inspector.py
──────────────────────────────
Converts a Website Security Inspector (Module 4, Node.js) posture-check
JSON report into CyberShield 360's shared Finding / Scan model so it can be
stored in SQLite alongside Download Guard results.

Why an adapter layer?
---------------------
Module 4 is a Node.js service that returns its own JSON schema (posture
report with "checks", "skipped", "dnsRecords", etc.).  Rather than changing
that service, we translate its output at ingestion time, keeping the Node.js
codebase standalone while still benefiting from shared storage and the
Investigation & Evidence Center (future).

Mapping rules
─────────────
  Node.js "severity"  →  RiskCategory
  ─────────────────────────────────────
  "Critical"          →  CRITICAL
  "High"              →  HIGH
  "Medium"            →  MEDIUM
  "Low"               →  LOW
  "Info" / anything   →  INFORMATIONAL

  Each "check" entry becomes one Finding.
  Each "skipped" entry becomes one Finding with rule_id "WSI-SKIPPED-<check>"
  and category INFORMATIONAL (it records what was not checked, not a risk).

  "syntheticData" or "_meta.synthetic" in the report → is_simulated = True.

Public API
──────────
  posture_report_to_scan(report: dict) -> Scan
      Main entry point. Raises AdapterError on irrecoverable problems.

  AdapterError(Exception)
      Raised when the input is so malformed we cannot produce a Scan.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from models import Evidence, Finding, RiskCategory, Scan

# ── Module name (shown in the UI and stored in the DB) ───────────────────────
MODULE_NAME = "Website Security Inspector"

# ── Rule-ID prefix for all check findings ────────────────────────────────────
_CHECK_PREFIX  = "WSI-CHECK"
_SKIPPED_PREFIX = "WSI-SKIPPED"

# ── Node severity string → RiskCategory ─────────────────────────────────────
_SEVERITY_MAP: Dict[str, RiskCategory] = {
    "critical": RiskCategory.CRITICAL,
    "high":     RiskCategory.HIGH,
    "medium":   RiskCategory.MEDIUM,
    "low":      RiskCategory.LOW,
    "info":     RiskCategory.INFORMATIONAL,
}

# ── Score weights used when rolling up a scan-level score ────────────────────
_SCORE_WEIGHTS: Dict[RiskCategory, float] = {
    RiskCategory.CRITICAL:      100.0,
    RiskCategory.HIGH:           50.0,
    RiskCategory.MEDIUM:         20.0,
    RiskCategory.LOW:             5.0,
    RiskCategory.INFORMATIONAL:   0.0,
    RiskCategory.UNKNOWN:         0.0,
    RiskCategory.BLOCKED:         0.0,
}


# ---------------------------------------------------------------------------
# Public exception
# ---------------------------------------------------------------------------

class AdapterError(Exception):
    """Raised when the posture report is too malformed to adapt."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _map_severity(severity: Any) -> RiskCategory:
    """Map a Node.js severity string to a RiskCategory."""
    if not isinstance(severity, str):
        return RiskCategory.UNKNOWN
    return _SEVERITY_MAP.get(severity.lower(), RiskCategory.INFORMATIONAL)


def _safe_str(value: Any, max_len: int = 2048) -> str:
    """Convert *value* to a string and truncate it safely."""
    if value is None:
        return ""
    return str(value)[:max_len]


def _rule_id_from_check_id(check_id: Any) -> str:
    """
    Turn a Node.js check id (e.g. 'header-x-frame-options') into a
    canonical rule_id string (e.g. 'WSI-CHECK-HEADER-X-FRAME-OPTIONS').
    """
    raw = _safe_str(check_id, 80).upper()
    # Keep only alphanumeric and hyphens
    sanitised = re.sub(r"[^A-Z0-9\-]", "-", raw)
    return f"{_CHECK_PREFIX}-{sanitised}"


def _evidence_from_check(check: dict) -> List[Evidence]:
    """Build a list of Evidence items from a single check dict."""
    items: List[Evidence] = []

    raw_evidence = check.get("evidence")
    if raw_evidence is not None:
        items.append(Evidence(
            label="Evidence",
            value=_safe_str(raw_evidence),
            raw=_safe_str(raw_evidence),
            is_observed_fact=True,
        ))

    remediation = check.get("remediation")
    if remediation:
        items.append(Evidence(
            label="Suggested remediation",
            value=_safe_str(remediation),
            is_observed_fact=False,  # Remediation is an interpretation/suggestion
        ))

    tier = check.get("tier")
    if tier is not None:
        items.append(Evidence(
            label="Check tier",
            value=f"Tier {tier}",
            is_observed_fact=True,
        ))

    timestamp = check.get("timestamp")
    if timestamp:
        items.append(Evidence(
            label="Check timestamp (UTC)",
            value=_safe_str(timestamp),
            is_observed_fact=True,
        ))

    return items


def _check_to_finding(check: dict, is_simulated: bool) -> Finding:
    """Convert a single check dict to a Finding."""
    severity     = check.get("severity", "Info")
    risk_cat     = _map_severity(severity)
    check_id     = check.get("id", "unknown")
    name         = check.get("name", check_id)
    issue        = check.get("issue", "")
    confidence   = check.get("confidence", "Medium")
    remediation  = check.get("remediation") or ""
    ts_str       = check.get("timestamp")

    # Parse timestamp; fall back to now
    triggered_at = _parse_timestamp(ts_str)

    # Confidence note: combine the node confidence level with a note
    confidence_note = (
        f"Confidence: {confidence}. "
        "Based on a single point-in-time passive or active check."
    )

    return Finding(
        module=MODULE_NAME,
        rule_id=_rule_id_from_check_id(check_id),
        title=_safe_str(name),
        description=_safe_str(issue),
        risk_category=risk_cat,
        confidence_note=confidence_note,
        remediation=_safe_str(remediation),
        source="Website Security Inspector (Module 4)",
        is_simulated=is_simulated,
        evidence=_evidence_from_check(check),
        triggered_at=triggered_at,
        input_type="website",
    )


def _skipped_to_finding(skipped: dict, is_simulated: bool) -> Finding:
    """
    Convert a 'skipped' entry to a Finding (risk = INFORMATIONAL).

    Skipped checks are recorded so the report is complete — the absence of
    a check result is itself useful information (e.g. "locked pending auth").
    """
    check_name = skipped.get("check", "unknown")
    reason     = skipped.get("reason", "No reason given")
    tier       = skipped.get("tier", "?")

    evidence = [
        Evidence(label="Reason skipped", value=_safe_str(reason), is_observed_fact=True),
        Evidence(label="Check tier",     value=f"Tier {tier}",    is_observed_fact=True),
    ]

    # Sanitise check name into a rule_id slug
    slug = re.sub(r"[^A-Z0-9]", "-", check_name.upper())[:50]

    return Finding(
        module=MODULE_NAME,
        rule_id=f"{_SKIPPED_PREFIX}-{slug}",
        title=f"Check skipped: {_safe_str(check_name)}",
        description=_safe_str(reason),
        risk_category=RiskCategory.INFORMATIONAL,
        confidence_note="This finding records a check that was not performed.",
        remediation="",
        source="Website Security Inspector (Module 4)",
        is_simulated=is_simulated,
        evidence=evidence,
        triggered_at=datetime.utcnow(),
        input_type="website",
    )


def _parse_timestamp(ts: Any) -> datetime:
    """
    Parse an ISO-8601 timestamp string from the Node.js report.
    Falls back to utcnow() on any parse failure.
    """
    if not ts:
        return datetime.utcnow()
    try:
        # Python 3.11+ fromisoformat handles 'Z'; earlier versions do not.
        s = str(ts).replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        # Strip tz info so we're always storing naive UTC datetimes
        return dt.replace(tzinfo=None)
    except (ValueError, TypeError):
        return datetime.utcnow()


def _compute_scan_score(findings: List[Finding]) -> float:
    """Sum the weight of each finding's risk category for the scan score."""
    return sum(_SCORE_WEIGHTS.get(f.risk_category, 0.0) for f in findings)


def _compute_scan_risk(findings: List[Finding]) -> RiskCategory:
    """Return the highest RiskCategory present in *findings*."""
    order = {
        RiskCategory.CRITICAL:      5,
        RiskCategory.HIGH:          4,
        RiskCategory.MEDIUM:        3,
        RiskCategory.LOW:           2,
        RiskCategory.INFORMATIONAL: 1,
        RiskCategory.UNKNOWN:       0,
        RiskCategory.BLOCKED:       0,
    }
    if not findings:
        return RiskCategory.UNKNOWN
    return max(findings, key=lambda f: order.get(f.risk_category, 0)).risk_category


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def posture_report_to_scan(report: dict) -> Scan:
    """
    Convert a Website Security Inspector posture-check JSON report (as
    returned by the Node.js /api/posture endpoint) into a CyberShield 360
    Scan with embedded Findings.

    Parameters
    ----------
    report : dict
        The parsed JSON object from the Node.js service.

    Returns
    -------
    Scan
        A fully populated Scan (scan_id is None until persisted to the DB).

    Raises
    ------
    AdapterError
        If the report is None, not a dict, or missing required top-level keys.
    """
    # ── Basic validation ──────────────────────────────────────────────────────
    if not isinstance(report, dict):
        raise AdapterError(f"Expected a dict, got {type(report).__name__}")

    if not report.get("ok"):
        error_msg = report.get("error", "Unknown error from posture check")
        raise AdapterError(f"Posture check returned ok=false: {error_msg}")

    # ── Detect synthetic / demo data ─────────────────────────────────────────
    is_simulated: bool = bool(
        report.get("syntheticData")                               # reputation layer
        or (report.get("_meta") or {}).get("synthetic")          # fixture-level flag
        or report.get("is_simulated")                            # explicit flag
    )

    # ── Extract identifying fields ────────────────────────────────────────────
    hostname: str    = _safe_str(report.get("hostname", "unknown"), 253)
    target_url: str  = _safe_str(report.get("targetUrl", hostname), 2048)
    report_ts: str   = report.get("reportTimestamp", "")
    scan_time        = _parse_timestamp(report_ts)

    # Strip any query string from the target URL (never persist query strings)
    target_label = target_url.split("?")[0]

    # ── Convert checks → Findings ─────────────────────────────────────────────
    findings: List[Finding] = []

    raw_checks = report.get("checks") or []
    if not isinstance(raw_checks, list):
        raise AdapterError("'checks' field is not a list")

    for check in raw_checks:
        if not isinstance(check, dict):
            continue  # Skip malformed entries
        findings.append(_check_to_finding(check, is_simulated))

    # ── Convert skipped entries → Findings ───────────────────────────────────
    raw_skipped = report.get("skipped") or []
    if not isinstance(raw_skipped, list):
        raw_skipped = []

    for skipped in raw_skipped:
        if not isinstance(skipped, dict):
            continue
        findings.append(_skipped_to_finding(skipped, is_simulated))

    # ── Compute roll-up score and category ────────────────────────────────────
    # Only score non-skipped findings
    scored_findings = [f for f in findings if not f.rule_id.startswith(_SKIPPED_PREFIX)]
    score           = _compute_scan_score(scored_findings)
    risk_category   = _compute_scan_risk(scored_findings)

    return Scan(
        module=MODULE_NAME,
        target_label=target_label,
        target_hash=None,           # URLs do not have content hashes
        target_type="website",
        risk_category=risk_category,
        score=score,
        is_simulated=is_simulated,
        findings=findings,
        scan_id=None,               # Will be set by add_scan_with_findings()
        scanned_at=scan_time,
        duration_seconds=None,      # Not available from the posture report
    )
