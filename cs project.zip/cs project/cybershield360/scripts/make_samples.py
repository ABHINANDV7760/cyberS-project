#!/usr/bin/env python3
"""
scripts/make_samples.py – Generate inert SYNTHETIC sample files for CyberShield 360.

ALL files written here are purely harmless bytes. None of them are real
malware, real executables, or real documents. They are clearly labeled
SYNTHETIC and serve only as demonstration fixtures for the Download Guard UI.

Run from the cybershield360/ directory:
    python scripts/make_samples.py

Or from the repo root:
    python cybershield360/scripts/make_samples.py

Files created in cybershield360/samples/:
  harmless-sample.txt         – plain text, no special bytes
  invoice.pdf.exe             – text file with double extension (not an executable)
  photo.zip                   – file with PNG magic bytes but .zip extension
  report.pdf                  – file containing only "MZ" + filler text (NOT a real PE)
  macro-demo.docm             – empty-ish DOCX-alike with .docm extension
  archive-demo.zip            – real minimal ZIP with only a text README inside
"""
from __future__ import annotations

import struct
import zipfile
from pathlib import Path

SAMPLES_DIR = Path(__file__).parent.parent / "samples"


def _write(filename: str, data: bytes) -> None:
    out = SAMPLES_DIR / filename
    out.write_bytes(data)
    size = len(data)
    print(f"  wrote {filename!r:40s}  ({size:>8,} bytes)")


def make_harmless_txt() -> None:
    """Plain UTF-8 text — no special bytes, clean."""
    content = (
        "CyberShield 360 — SYNTHETIC sample file\n"
        "========================================\n"
        "This file is a harmless plain-text fixture used for demonstration\n"
        "purposes only. It contains no malicious content.\n"
        "\n"
        "SHA-256 of this file is deterministic and can be used to verify\n"
        "that the chunked hashing implementation is correct.\n"
    )
    _write("harmless-sample.txt", content.encode("utf-8"))


def make_double_extension() -> None:
    """
    invoice.pdf.exe — text bytes only, SYNTHETIC label.
    Double extension (.pdf.exe) demonstrates FILE-DOUBLE-EXT rule.
    The bytes are pure plain text; this file cannot execute.
    """
    content = (
        "[SYNTHETIC SAMPLE — NOT AN EXECUTABLE]\n"
        "This file has a double extension (invoice.pdf.exe) for demonstration.\n"
        "Its content is plain text only. It cannot be executed.\n"
        "CyberShield 360 should flag FILE-DOUBLE-EXT for this file.\n"
    )
    _write("invoice.pdf.exe", content.encode("utf-8"))


def make_extension_mismatch_png_as_zip() -> None:
    """
    photo.zip — has PNG magic bytes but .zip extension.
    Demonstrates FILE-TYPE-MISMATCH rule. Not a real image.
    """
    # PNG magic: \x89 P N G \r \n \x1a \n
    png_magic = b"\x89PNG\r\n\x1a\n"
    filler = (
        b"\n[SYNTHETIC SAMPLE - NOT A REAL IMAGE OR ARCHIVE]\n"
        b"This file has PNG magic bytes but a .zip extension.\n"
        b"It is not a valid PNG or ZIP. CyberShield 360 should\n"
        b"flag FILE-TYPE-MISMATCH for this file.\n"
    )
    _write("photo.zip", png_magic + filler)


def make_mz_filler_pdf() -> None:
    """
    report.pdf — starts with 'MZ' (Windows PE magic) plus plain text filler.
    NOT a real executable. Demonstrates FILE-EXEC-DISGUISED rule.
    The file is entirely harmless; it cannot be loaded as a PE binary.
    """
    # Real PE files have a valid DOS/PE header structure; this is just 2 bytes + text.
    mz = b"MZ"
    filler = (
        b"\n[SYNTHETIC SAMPLE - NOT A REAL EXECUTABLE]\n"
        b"This file begins with 'MZ' (Windows PE magic) followed by plain\n"
        b"filler text. It has a .pdf extension.\n"
        b"CyberShield 360 should flag FILE-EXEC-DISGUISED for this file.\n"
        b"This file CANNOT be executed; it is not a valid PE binary.\n"
    )
    _write("report.pdf", mz + filler)


def make_macro_demo() -> None:
    """
    macro-demo.docm — .docm extension (macro-capable Office format).
    Content is plain text only; no actual macros or Office XML.
    Demonstrates FILE-MACRO-CAPABLE rule.
    """
    content = (
        "[SYNTHETIC SAMPLE — NOT A REAL OFFICE DOCUMENT]\n"
        "This file has the .docm extension (macro-capable Word format).\n"
        "Its content is plain text only. It contains no macros, no Office XML,\n"
        "and no executable content of any kind.\n"
        "CyberShield 360 should flag FILE-MACRO-CAPABLE for this file.\n"
    )
    _write("macro-demo.docm", content.encode("utf-8"))


def make_archive_demo() -> None:
    """
    archive-demo.zip — a minimal real ZIP containing only a text README.
    Demonstrates FILE-ARCHIVE-UNINSPECTED rule.
    """
    import io

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(
            "README.txt",
            (
                "[SYNTHETIC SAMPLE]\n"
                "This ZIP archive is a demonstration fixture for CyberShield 360.\n"
                "It contains only this plain-text README.\n"
                "CyberShield 360 should flag FILE-ARCHIVE-UNINSPECTED for this file.\n"
            ),
        )
    _write("archive-demo.zip", buf.getvalue())


def main() -> None:
    SAMPLES_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Writing synthetic sample files to: {SAMPLES_DIR.resolve()}\n")
    make_harmless_txt()
    make_double_extension()
    make_extension_mismatch_png_as_zip()
    make_mz_filler_pdf()
    make_macro_demo()
    make_archive_demo()
    print(f"\nDone. {len(list(SAMPLES_DIR.iterdir()))} sample files in {SAMPLES_DIR.resolve()}")


if __name__ == "__main__":
    main()
