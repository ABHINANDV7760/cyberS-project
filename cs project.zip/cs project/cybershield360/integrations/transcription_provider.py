"""
integrations/transcription_provider.py – Audio → text transcription adapter.

Architecture
------------
TranscriptionProvider (abstract base)
    └── OpenAIWhisperProvider   (OpenAI Whisper API)
    (future: AssemblyAI, Deepgram, local Whisper, etc.)

Usage
-----
Call `get_transcription_provider()` to get the configured provider, or None
if no transcription provider is configured. When None, the UI hides the audio
tab and shows a clear "text-only" message.

Safety constraints
------------------
* Audio bytes are sent only to the configured provider — never logged or
  stored server-side by this app.
* The transcribed text is returned and then discarded after analysis; it is
  never persisted (only matched-phrase snippets are stored).
* The provider is ONLY called when the user explicitly uploads a file AND
  confirms the send action.
* Never claims the transcription identifies the caller by voice or number.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from config import OPENAI_API_KEY, TRANSCRIPTION_PROVIDER


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class TranscriptionResult:
    text: str           # The transcribed text
    provider: str       # Name of provider used
    language: str = ""  # Detected language (if available)
    is_simulated: bool = False


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class TranscriptionProvider(ABC):
    name: str = "Unknown"

    @abstractmethod
    def transcribe(self, audio_bytes: bytes, filename: str) -> TranscriptionResult:
        """
        Transcribe audio_bytes and return a TranscriptionResult.
        Raises RuntimeError on failure.
        audio_bytes must not exceed AUDIO_MAX_BYTES.
        """

    def is_configured(self) -> bool:
        return False


# ---------------------------------------------------------------------------
# OpenAI Whisper provider
# ---------------------------------------------------------------------------

class OpenAIWhisperProvider(TranscriptionProvider):
    """
    Sends audio to the OpenAI Whisper API (/v1/audio/transcriptions).
    Requires OPENAI_API_KEY environment variable.

    What is sent: only the audio file bytes and its filename.
    Nothing else (no transcript, no metadata) is sent to OpenAI.
    """
    name = "OpenAI Whisper"

    def is_configured(self) -> bool:
        return bool(OPENAI_API_KEY)

    def transcribe(self, audio_bytes: bytes, filename: str) -> TranscriptionResult:
        if not OPENAI_API_KEY:
            raise RuntimeError(
                "OpenAI API key is not configured. "
                "Set the OPENAI_API_KEY environment variable."
            )
        try:
            import requests
        except ImportError:
            raise RuntimeError("The 'requests' library is required for transcription.")

        resp = requests.post(
            "https://api.openai.com/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
            files={"file": (filename, audio_bytes)},
            data={"model": "whisper-1"},
            timeout=60,
        )
        if resp.status_code == 401:
            raise RuntimeError("Transcription failed: invalid API key (401).")
        if resp.status_code == 429:
            raise RuntimeError("Transcription failed: rate limited (429). Try again later.")
        if not resp.ok:
            raise RuntimeError(
                f"Transcription failed: HTTP {resp.status_code} — {resp.text[:200]}"
            )
        data = resp.json()
        text = data.get("text", "").strip()
        if not text:
            raise RuntimeError("Transcription returned empty text.")
        return TranscriptionResult(
            text=text,
            provider=self.name,
            language=data.get("language", ""),
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def get_transcription_provider() -> TranscriptionProvider | None:
    """
    Return the configured transcription provider, or None if not configured.
    Returns None when TRANSCRIPTION_PROVIDER env var is not set.
    """
    if not TRANSCRIPTION_PROVIDER:
        return None
    if TRANSCRIPTION_PROVIDER.lower() in ("openai-whisper", "openai", "whisper"):
        provider = OpenAIWhisperProvider()
        return provider if provider.is_configured() else None
    # Unknown provider name — return None rather than crash
    return None
