"""
integrations/reputation_provider.py – Threat-intel reputation adapters.

Architecture
------------
ReputationProvider (abstract base)
    ├── NoApiProvider        (serves SYNTHETIC fixtures; no network call)
    ├── URLhausProvider      (URLhaus lookup API)
    ├── VirusTotalProvider   (VirusTotal URL report v3)
    └── GoogleSafeBrowsingProvider  (Google Safe Browsing Lookup API v4)

Keys are read from environment variables via config.py only. They are NEVER
hardcoded, logged, or displayed in the UI.

Before any network call the UI must show:
  "Only this URL is sent to <provider>. No file content is ever sent."
  and require an explicit user confirmation.

Rate-limit, auth-error, and server-error responses are handled gracefully
(no crash, friendly message returned in ReputationResult.detail).
"""
from __future__ import annotations

import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse, urlunparse

import requests

from config import (
    GOOGLE_SAFE_BROWSING_API_KEY,
    SAFE_FETCH_CONNECT_TIMEOUT,
    SAFE_FETCH_READ_TIMEOUT,
    SAFE_FETCH_USER_AGENT,
    URLHAUS_API_KEY,
    VIRUSTOTAL_API_KEY,
)
from utils.logging_utils import safe_event


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

REPUTATION_STATUSES = frozenset(
    {
        "malicious_reported",
        "no_data",
        "error",
        "rate_limited",
        "not_checked",
    }
)


@dataclass
class ReputationResult:
    status: str                     # one of REPUTATION_STATUSES
    detail: str                     # human-readable explanation
    source: str                     # provider name
    checked_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_simulated: bool = False

    def __post_init__(self) -> None:
        if self.status not in REPUTATION_STATUSES:
            raise ValueError(f"Unknown reputation status: {self.status!r}")

    @property
    def display_detail(self) -> str:
        """
        Return the detail string, with the mandatory wording for no_data.
        """
        if self.status == "no_data":
            return "No reputation data. This does NOT mean the URL is safe."
        return self.detail


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class ReputationProvider(ABC):
    name: str = "Unknown"

    @abstractmethod
    def lookup(self, url: str) -> ReputationResult:
        """
        Check the reputation of ``url``.

        Implementations MUST:
        - Never log or display the API key.
        - Handle timeouts, 401, 403, 429, and 5xx gracefully.
        - Return a ReputationResult with an appropriate status.
        - Never send file content.
        """
        ...

    def is_configured(self) -> bool:
        """Return True if the provider has a usable API key."""
        return True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _strip_query(url: str) -> str:
    """Remove query string and fragment (for logging only)."""
    try:
        p = urlparse(url)
        return urlunparse((p.scheme, p.netloc, p.path, "", "", ""))
    except Exception:
        return url


def _safe_post(
    endpoint: str,
    headers: dict,
    data: Optional[dict] = None,
    json_body: Optional[dict] = None,
    timeout: tuple = (SAFE_FETCH_CONNECT_TIMEOUT, SAFE_FETCH_READ_TIMEOUT),
) -> requests.Response:
    """Make a POST to a trusted reputation API endpoint (not user-controlled)."""
    return requests.post(
        endpoint,
        headers=headers,
        data=data,
        json=json_body,
        timeout=timeout,
        verify=True,
    )


def _safe_get(
    endpoint: str,
    headers: dict,
    params: Optional[dict] = None,
    timeout: tuple = (SAFE_FETCH_CONNECT_TIMEOUT, SAFE_FETCH_READ_TIMEOUT),
) -> requests.Response:
    return requests.get(
        endpoint,
        headers=headers,
        params=params,
        timeout=timeout,
        verify=True,
    )


def _handle_http_error(resp: requests.Response, provider_name: str) -> ReputationResult:
    if resp.status_code == 401:
        return ReputationResult(
            status="error",
            detail=f"{provider_name}: Authentication failed. Check your API key.",
            source=provider_name,
        )
    if resp.status_code == 403:
        return ReputationResult(
            status="error",
            detail=f"{provider_name}: Access denied (403). Quota or key permissions issue.",
            source=provider_name,
        )
    if resp.status_code == 429:
        return ReputationResult(
            status="rate_limited",
            detail=f"{provider_name}: Rate limit exceeded. Try again later.",
            source=provider_name,
        )
    if resp.status_code >= 500:
        return ReputationResult(
            status="error",
            detail=f"{provider_name}: Server error ({resp.status_code}). Try again later.",
            source=provider_name,
        )
    return ReputationResult(
        status="error",
        detail=f"{provider_name}: Unexpected response ({resp.status_code}).",
        source=provider_name,
    )


# ---------------------------------------------------------------------------
# No-API provider (SYNTHETIC only)
# ---------------------------------------------------------------------------

# Fixture data keyed by URL (no query string). Every result is labeled SYNTHETIC.
_SYNTHETIC_DB: dict[str, ReputationResult] = {}


def _build_synthetic_db() -> None:
    """Populate the synthetic fixture database. Called once at module load."""
    entries = [
        (
            "https://demo.example.test/clean.pdf",
            ReputationResult(
                status="no_data",
                detail="No reputation data. This does NOT mean the URL is safe.",
                source="NoApiProvider (SYNTHETIC)",
                is_simulated=True,
            ),
        ),
        (
            "https://demo.example.test/known-bad.exe",
            ReputationResult(
                status="malicious_reported",
                detail=(
                    "[SYNTHETIC] This URL has been reported as distributing malware "
                    "by multiple sources in the demonstration dataset."
                ),
                source="NoApiProvider (SYNTHETIC)",
                is_simulated=True,
            ),
        ),
        (
            "https://demo.example.test/redirect-chain",
            ReputationResult(
                status="no_data",
                detail="No reputation data. This does NOT mean the URL is safe.",
                source="NoApiProvider (SYNTHETIC)",
                is_simulated=True,
            ),
        ),
        (
            "http://192.168.0.1/admin",
            ReputationResult(
                status="not_checked",
                detail=(
                    "[SYNTHETIC] This URL resolves to a private/internal address. "
                    "The request was blocked by SSRF protections; no reputation lookup performed."
                ),
                source="NoApiProvider (SYNTHETIC)",
                is_simulated=True,
            ),
        ),
    ]
    for url, result in entries:
        _SYNTHETIC_DB[url] = result


_build_synthetic_db()


class NoApiProvider(ReputationProvider):
    """
    Serves SYNTHETIC demonstration results. Makes no network calls.
    All results are labeled is_simulated=True and marked SYNTHETIC in detail.
    """

    name = "No-API Demo Provider"

    def lookup(self, url: str) -> ReputationResult:
        stripped = _strip_query(url)
        result = _SYNTHETIC_DB.get(stripped)
        if result is None:
            result = ReputationResult(
                status="no_data",
                detail="No reputation data. This does NOT mean the URL is safe.",
                source="NoApiProvider (SYNTHETIC)",
                is_simulated=True,
            )
        safe_event("reputation.no_api_lookup", extra={"status": result.status})
        return result

    def is_configured(self) -> bool:
        return True


# ---------------------------------------------------------------------------
# URLhaus provider
# ---------------------------------------------------------------------------

class URLhausProvider(ReputationProvider):
    """
    Queries the URLhaus URL lookup API.
    API key via URLHAUS_API_KEY env var (anonymous lookups also supported).
    Docs: https://urlhaus-api.abuse.ch/
    """

    name = "URLhaus"
    _ENDPOINT = "https://urlhaus-api.abuse.ch/v1/url/"

    def is_configured(self) -> bool:
        # URLhaus supports anonymous lookups; always available
        return True

    def lookup(self, url: str) -> ReputationResult:
        headers = {"User-Agent": SAFE_FETCH_USER_AGENT}
        if URLHAUS_API_KEY:
            headers["Auth-Key"] = URLHAUS_API_KEY

        try:
            resp = _safe_post(
                self._ENDPOINT,
                headers=headers,
                data={"url": url},
            )
        except requests.exceptions.Timeout:
            return ReputationResult(
                status="error",
                detail="URLhaus: Request timed out.",
                source=self.name,
            )
        except requests.exceptions.RequestException as exc:
            return ReputationResult(
                status="error",
                detail=f"URLhaus: Network error — {type(exc).__name__}.",
                source=self.name,
            )

        if resp.status_code != 200:
            return _handle_http_error(resp, self.name)

        try:
            data = resp.json()
        except Exception:
            return ReputationResult(
                status="error",
                detail="URLhaus: Could not parse response.",
                source=self.name,
            )

        query_status = data.get("query_status", "")
        if query_status == "no_results":
            return ReputationResult(
                status="no_data",
                detail="No reputation data. This does NOT mean the URL is safe.",
                source=self.name,
            )
        if query_status in ("is_available", "blacklisted", "online", "offline"):
            url_status = data.get("url_status", "")
            tags = ", ".join(data.get("tags") or [])
            threat = data.get("threat", "")
            detail = f"URLhaus status: {url_status}."
            if threat:
                detail += f" Threat: {threat}."
            if tags:
                detail += f" Tags: {tags}."
            is_malicious = url_status in ("online", "blacklisted") or bool(threat)
            return ReputationResult(
                status="malicious_reported" if is_malicious else "no_data",
                detail=detail,
                source=self.name,
            )

        return ReputationResult(
            status="no_data",
            detail="No reputation data. This does NOT mean the URL is safe.",
            source=self.name,
        )


# ---------------------------------------------------------------------------
# VirusTotal provider
# ---------------------------------------------------------------------------

import base64 as _base64


class VirusTotalProvider(ReputationProvider):
    """
    Queries the VirusTotal URL report endpoint (v3 API).
    Requires VIRUSTOTAL_API_KEY env var.
    Docs: https://developers.virustotal.com/reference/url-info
    """

    name = "VirusTotal"
    _ENDPOINT = "https://www.virustotal.com/api/v3/urls/{url_id}"

    def is_configured(self) -> bool:
        return bool(VIRUSTOTAL_API_KEY)

    def lookup(self, url: str) -> ReputationResult:
        if not VIRUSTOTAL_API_KEY:
            return ReputationResult(
                status="not_checked",
                detail="VirusTotal API key not configured.",
                source=self.name,
            )

        # VT URL ID = base64url of the URL, no padding
        url_id = _base64.urlsafe_b64encode(url.encode()).rstrip(b"=").decode()
        endpoint = self._ENDPOINT.format(url_id=url_id)
        headers = {
            "x-apikey": VIRUSTOTAL_API_KEY,
            "User-Agent": SAFE_FETCH_USER_AGENT,
        }

        try:
            resp = _safe_get(endpoint, headers=headers)
        except requests.exceptions.Timeout:
            return ReputationResult(
                status="error",
                detail="VirusTotal: Request timed out.",
                source=self.name,
            )
        except requests.exceptions.RequestException as exc:
            return ReputationResult(
                status="error",
                detail=f"VirusTotal: Network error — {type(exc).__name__}.",
                source=self.name,
            )

        if resp.status_code == 404:
            return ReputationResult(
                status="no_data",
                detail="No reputation data. This does NOT mean the URL is safe.",
                source=self.name,
            )
        if resp.status_code != 200:
            return _handle_http_error(resp, self.name)

        try:
            data = resp.json()
        except Exception:
            return ReputationResult(
                status="error",
                detail="VirusTotal: Could not parse response.",
                source=self.name,
            )

        stats = (
            data.get("data", {})
            .get("attributes", {})
            .get("last_analysis_stats", {})
        )
        malicious = stats.get("malicious", 0)
        suspicious = stats.get("suspicious", 0)
        total = sum(stats.values()) if stats else 0

        if malicious > 0 or suspicious > 0:
            return ReputationResult(
                status="malicious_reported",
                detail=(
                    f"VirusTotal: {malicious} engine(s) flagged as malicious, "
                    f"{suspicious} as suspicious (out of {total} engines)."
                ),
                source=self.name,
            )
        if total > 0:
            return ReputationResult(
                status="no_data",
                detail="No reputation data. This does NOT mean the URL is safe.",
                source=self.name,
            )
        return ReputationResult(
            status="no_data",
            detail="No reputation data. This does NOT mean the URL is safe.",
            source=self.name,
        )


# ---------------------------------------------------------------------------
# Google Safe Browsing provider
# ---------------------------------------------------------------------------

class GoogleSafeBrowsingProvider(ReputationProvider):
    """
    Queries the Google Safe Browsing Lookup API v4.
    Requires GOOGLE_SAFE_BROWSING_API_KEY env var.
    Docs: https://developers.google.com/safe-browsing/v4/lookup-api
    """

    name = "Google Safe Browsing"
    _ENDPOINT = "https://safebrowsing.googleapis.com/v4/threatMatches:find"

    def is_configured(self) -> bool:
        return bool(GOOGLE_SAFE_BROWSING_API_KEY)

    def lookup(self, url: str) -> ReputationResult:
        if not GOOGLE_SAFE_BROWSING_API_KEY:
            return ReputationResult(
                status="not_checked",
                detail="Google Safe Browsing API key not configured.",
                source=self.name,
            )

        payload = {
            "client": {"clientId": "cybershield360", "clientVersion": "1.0.0"},
            "threatInfo": {
                "threatTypes": [
                    "MALWARE",
                    "SOCIAL_ENGINEERING",
                    "UNWANTED_SOFTWARE",
                    "POTENTIALLY_HARMFUL_APPLICATION",
                ],
                "platformTypes": ["ANY_PLATFORM"],
                "threatEntryTypes": ["URL"],
                "threatEntries": [{"url": url}],
            },
        }

        try:
            resp = _safe_post(
                self._ENDPOINT,
                headers={"User-Agent": SAFE_FETCH_USER_AGENT},
                params={"key": GOOGLE_SAFE_BROWSING_API_KEY},
                json_body=payload,
            )
        except requests.exceptions.Timeout:
            return ReputationResult(
                status="error",
                detail="Google Safe Browsing: Request timed out.",
                source=self.name,
            )
        except requests.exceptions.RequestException as exc:
            return ReputationResult(
                status="error",
                detail=f"Google Safe Browsing: Network error — {type(exc).__name__}.",
                source=self.name,
            )

        if resp.status_code != 200:
            return _handle_http_error(resp, self.name)

        try:
            data = resp.json()
        except Exception:
            return ReputationResult(
                status="error",
                detail="Google Safe Browsing: Could not parse response.",
                source=self.name,
            )

        matches = data.get("matches", [])
        if matches:
            threat_types = list({m.get("threatType", "") for m in matches})
            return ReputationResult(
                status="malicious_reported",
                detail=(
                    f"Google Safe Browsing flagged this URL. "
                    f"Threat types: {', '.join(threat_types)}."
                ),
                source=self.name,
            )

        return ReputationResult(
            status="no_data",
            detail="No reputation data. This does NOT mean the URL is safe.",
            source=self.name,
        )


# ---------------------------------------------------------------------------
# Provider registry
# ---------------------------------------------------------------------------

def get_available_providers() -> list[ReputationProvider]:
    """Return all providers that have a valid configuration."""
    candidates = [
        NoApiProvider(),
        URLhausProvider(),
        VirusTotalProvider(),
        GoogleSafeBrowsingProvider(),
    ]
    return [p for p in candidates if p.is_configured()]


def get_provider_by_name(name: str) -> Optional[ReputationProvider]:
    """Retrieve a provider instance by its .name attribute."""
    for p in get_available_providers():
        if p.name == name:
            return p
    return None
