"""
engine/risk_engine.py – Transparent risk-scoring engine for CyberShield 360.

Design principles
-----------------
* Every rule has a documented ID, description, base weight, and minimum
  category floor. These are defined in RULE_DEFINITIONS below and are the
  single source of truth (referenced in the UI "How this score was
  calculated" panel and in the README).
* Score = sum of triggered rule weights; mapped to a category via
  SCORE_THRESHOLDS.
* Hard overrides take priority over the computed category (see OVERRIDES).
* The engine NEVER outputs "safe" or "clean" unqualified. The lowest
  category text is always: "No issues detected by these checks.
  This does not guarantee the file or URL is safe."
* "Unknown" is returned when no rules triggered AND there is insufficient
  evidence to score (e.g. completely empty analysis).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from models import Finding, RiskCategory


# ---------------------------------------------------------------------------
# Rule definitions
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RuleDefinition:
    rule_id: str
    title: str
    description: str
    base_weight: float
    # If triggered, the category cannot be LOWER than this floor.
    min_category: RiskCategory = RiskCategory.INFORMATIONAL


# All rule IDs are declared here. New rules must be added here first.
RULE_DEFINITIONS: Dict[str, RuleDefinition] = {
    r.rule_id: r
    for r in [
        # --- File rules ---
        RuleDefinition(
            rule_id="FILE-EXEC-DISGUISED",
            title="Executable disguised as document/image",
            description=(
                "The file has an executable signature (PE/ELF/Mach-O/script) "
                "but uses a document, image, or plain-text extension. "
                "This is a common malware delivery technique."
            ),
            base_weight=80.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="FILE-DOUBLE-EXT",
            title="Double or deceptive file extension",
            description=(
                "The file name contains multiple extensions (e.g. report.pdf.exe) "
                "or trailing dots/spaces designed to hide the true extension."
            ),
            base_weight=60.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="FILE-RTLO",
            title="Right-to-left override or bidirectional control character in name",
            description=(
                "The file name contains U+202E (RIGHT-TO-LEFT OVERRIDE) or another "
                "bidirectional/invisible control character. This can make 'exe.fdp' "
                "appear as 'pdf.exe' in file explorers."
            ),
            base_weight=90.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="FILE-RISKY-EXT",
            title="High-risk file extension",
            description=(
                "The file extension belongs to a category frequently abused for "
                "malicious code execution: .exe .scr .bat .cmd .ps1 .vbs .js .jse "
                ".wsf .hta .msi .lnk .jar .iso .img .dll .com .reg"
            ),
            base_weight=40.0,
            min_category=RiskCategory.MEDIUM,
        ),
        RuleDefinition(
            rule_id="FILE-MACRO-CAPABLE",
            title="Macro-capable document format",
            description=(
                "The file uses a format that can execute embedded macros "
                "(.docm, .xlsm, .pptm) or is a legacy OLE2 Office document. "
                "Macros are a common malware vector."
            ),
            base_weight=30.0,
            min_category=RiskCategory.MEDIUM,
        ),
        RuleDefinition(
            rule_id="FILE-ARCHIVE-UNINSPECTED",
            title="Archive — contents not inspected",
            description=(
                "This file is an archive (ZIP, RAR, 7z, etc.). Its contents "
                "were NOT inspected or extracted. Malicious content inside "
                "the archive cannot be ruled out."
            ),
            base_weight=15.0,
            min_category=RiskCategory.LOW,
        ),
        RuleDefinition(
            rule_id="FILE-TYPE-MISMATCH",
            title="File extension does not match detected signature",
            description=(
                "The file extension does not match the file's actual content "
                "as determined by magic-byte detection."
            ),
            base_weight=25.0,
            min_category=RiskCategory.LOW,
        ),
        RuleDefinition(
            rule_id="FILE-HIGH-ENTROPY",
            title="High byte-entropy (possibly packed, compressed, or encrypted)",
            description=(
                "The first 1 MB of the file has unusually high Shannon entropy "
                "(> 7.2 bits/byte). This is consistent with packed, compressed, "
                "or encrypted content — but also with normal compressed files. "
                "Low weight; consider in combination with other signals."
            ),
            base_weight=10.0,
            min_category=RiskCategory.INFORMATIONAL,
        ),
        RuleDefinition(
            rule_id="FILE-EMPTY-OR-TRUNCATED",
            title="Empty or implausibly short file",
            description=(
                "The file is zero bytes or too short to be a valid instance "
                "of its declared or detected type."
            ),
            base_weight=20.0,
            min_category=RiskCategory.LOW,
        ),
        RuleDefinition(
            rule_id="FILE-CONSISTENT",
            title="Extension and signature consistent",
            description=(
                "The file extension and the detected magic-byte signature agree. "
                "This is informational only — a consistent signature does not "
                "guarantee the file is safe."
            ),
            base_weight=0.0,
            min_category=RiskCategory.INFORMATIONAL,
        ),
        # --- URL rules ---
        RuleDefinition(
            rule_id="URL-BAD-SCHEME",
            title="Non-HTTP(S) or dangerous URL scheme",
            description="The URL uses a scheme other than http or https.",
            base_weight=100.0,
            min_category=RiskCategory.CRITICAL,
        ),
        RuleDefinition(
            rule_id="URL-CREDENTIALS",
            title="Credentials embedded in URL",
            description="The URL contains a username or password (user:pass@host).",
            base_weight=70.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="URL-SSRF-BLOCKED",
            title="SSRF: URL resolves to a non-public/internal address",
            description=(
                "The URL resolves to a loopback, private, link-local, CGNAT, "
                "multicast, or otherwise non-globally-routable address. "
                "The request was blocked."
            ),
            base_weight=100.0,
            min_category=RiskCategory.BLOCKED,
        ),
        RuleDefinition(
            rule_id="URL-REDIRECT-HTTPS-DOWNGRADE",
            title="Redirect chain downgrades from HTTPS to HTTP",
            description=(
                "At least one hop in the redirect chain goes from HTTPS to HTTP, "
                "exposing subsequent communication to interception."
            ),
            base_weight=35.0,
            min_category=RiskCategory.MEDIUM,
        ),
        RuleDefinition(
            rule_id="URL-REDIRECT-CROSS-DOMAIN",
            title="Redirect crosses to a different domain",
            description=(
                "The redirect chain passes through one or more different domains, "
                "which may indicate cloaking or traffic-direction systems."
            ),
            base_weight=20.0,
            min_category=RiskCategory.LOW,
        ),
        RuleDefinition(
            rule_id="URL-REDIRECT-IP-LITERAL",
            title="Redirect to an IP-literal address",
            description=(
                "A redirect in the chain points to a raw IP address rather than "
                "a hostname."
            ),
            base_weight=30.0,
            min_category=RiskCategory.MEDIUM,
        ),
        RuleDefinition(
            rule_id="URL-CONTENT-TYPE-MISMATCH",
            title="Content-Type or filename mismatch",
            description=(
                "The Content-Type header, the URL path extension, and/or the "
                "Content-Disposition filename disagree about the file type."
            ),
            base_weight=25.0,
            min_category=RiskCategory.LOW,
        ),
        RuleDefinition(
            rule_id="URL-IP-LITERAL-HOST",
            title="URL host is an IP address",
            description=(
                "The URL uses a raw IP address as the host rather than a hostname."
            ),
            base_weight=15.0,
            min_category=RiskCategory.LOW,
        ),
        RuleDefinition(
            rule_id="URL-LONG",
            title="Unusually long URL",
            description="The URL exceeds 1,024 characters, which is unusual for legitimate services.",
            base_weight=5.0,
            min_category=RiskCategory.INFORMATIONAL,
        ),
        RuleDefinition(
            rule_id="URL-UNUSUAL-TLD",
            title="Unusual top-level domain",
            description="The URL uses a top-level domain not commonly associated with legitimate services.",
            base_weight=5.0,
            min_category=RiskCategory.INFORMATIONAL,
        ),
        RuleDefinition(
            rule_id="URL-MANY-SUBDOMAINS",
            title="Hostname has many subdomains",
            description="The hostname has an unusually large number of subdomain labels.",
            base_weight=5.0,
            min_category=RiskCategory.INFORMATIONAL,
        ),
        # --- Reputation rules ---
        RuleDefinition(
            rule_id="REP-MALICIOUS-REPORTED",
            title="URL reported as malicious by reputation provider",
            description=(
                "A threat intelligence provider has flagged this URL as malicious. "
                "Note: this reflects what the database already knows and cannot "
                "inspect the current file content."
            ),
            base_weight=100.0,
            min_category=RiskCategory.CRITICAL,
        ),
        # --- Call-detector rules ---
        # These mirror the CallRuleDefinition entries in modules/fraud_call_detector.py.
        # Weights here are used for the shared score engine; the call module may apply
        # its own category floor directly but uses these for the shared report.
        RuleDefinition(
            rule_id="CALL-OTP-REQUEST",
            title="OTP / PIN / password / credential request",
            description="Transcript requests a one-time password, PIN, security code, or banking credential.",
            base_weight=80.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="CALL-URGENT-PAYMENT",
            title="Urgent payment pressure",
            description="Transcript contains artificial urgency to make an immediate payment.",
            base_weight=60.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="CALL-IMPERSONATION",
            title="Bank, government, or tech-support impersonation",
            description="Transcript claims affiliation with a bank, government body, or tech support.",
            base_weight=50.0,
            min_category=RiskCategory.MEDIUM,
        ),
        RuleDefinition(
            rule_id="CALL-THREAT-COERCION",
            title="Threats or coercion",
            description="Transcript contains explicit threats of arrest, legal action, or asset seizure.",
            base_weight=70.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="CALL-PRIZE-LOTTERY",
            title="Prize, lottery, or unexpected-windfall claim",
            description="Transcript claims the target has won a prize or unexpected sum.",
            base_weight=55.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="CALL-REMOTE-ACCESS",
            title="Remote access software request",
            description="Transcript requests installation of AnyDesk, TeamViewer, or similar.",
            base_weight=85.0,
            min_category=RiskCategory.HIGH,
        ),
        RuleDefinition(
            rule_id="CALL-SUSPICIOUS-URL",
            title="Suspicious URL in transcript",
            description="A URL was found in the transcript.",
            base_weight=30.0,
            min_category=RiskCategory.MEDIUM,
        ),
        RuleDefinition(
            rule_id="CALL-UNUSUAL-PAYMENT",
            title="Unusual payment instruction",
            description="Transcript requests payment via gift card, crypto, or unusual wire transfer.",
            base_weight=75.0,
            min_category=RiskCategory.HIGH,
        ),
    ]
}


# ---------------------------------------------------------------------------
# Score → Category thresholds (documented in README)
#
# Score is the sum of triggered rule base_weights.
# ┌─────────────────┬───────────────────┐
# │ Score range     │ Category          │
# ├─────────────────┼───────────────────┤
# │ 0               │ Informational     │
# │ 1 – 19          │ Low               │
# │ 20 – 49         │ Medium            │
# │ 50 – 79         │ High              │
# │ 80+             │ Critical          │
# └─────────────────┴───────────────────┘
# ---------------------------------------------------------------------------

SCORE_THRESHOLDS: List[Tuple[float, RiskCategory]] = [
    (80.0, RiskCategory.CRITICAL),
    (50.0, RiskCategory.HIGH),
    (20.0, RiskCategory.MEDIUM),
    (1.0,  RiskCategory.LOW),
    (0.0,  RiskCategory.INFORMATIONAL),
]


def score_to_category(score: float) -> RiskCategory:
    """Map a numeric score to a RiskCategory using SCORE_THRESHOLDS."""
    for threshold, category in SCORE_THRESHOLDS:
        if score >= threshold:
            return category
    return RiskCategory.INFORMATIONAL


# ---------------------------------------------------------------------------
# Override definitions (take priority over computed category)
# ---------------------------------------------------------------------------

def _apply_overrides(
    computed: RiskCategory,
    findings: List[Finding],
) -> Tuple[RiskCategory, Optional[str]]:
    """
    Apply hard overrides and return (final_category, override_note_or_None).

    Override rules (in priority order):
    1. SSRF-blocked URL → BLOCKED (not a scored risk)
    2. REP-MALICIOUS-REPORTED → CRITICAL
    3. FILE-EXEC-DISGUISED → at least HIGH
    4. min_category from each triggered rule's RuleDefinition
    """
    override_note: Optional[str] = None
    final = computed

    triggered_ids = {f.rule_id for f in findings}

    # Override 1: SSRF blocked
    if "URL-SSRF-BLOCKED" in triggered_ids:
        return RiskCategory.BLOCKED, "SSRF block: request not sent"

    # Override 2: reputation malicious
    if "REP-MALICIOUS-REPORTED" in triggered_ids:
        final = RiskCategory.CRITICAL
        override_note = "Override: reputation provider reported malicious"

    # Override 3: exec disguised → at least HIGH
    if "FILE-EXEC-DISGUISED" in triggered_ids:
        if RISK_ORDER.get(final, -1) < RISK_ORDER.get(RiskCategory.HIGH, -1):
            final = RiskCategory.HIGH
            override_note = (override_note or "") + " | Override: FILE-EXEC-DISGUISED floor=HIGH"

    # Apply per-rule min_category floors
    for finding in findings:
        rule_def = RULE_DEFINITIONS.get(finding.rule_id)
        if rule_def is None:
            continue
        floor = rule_def.min_category
        floor_order = RISK_ORDER.get(floor, -1)
        final_order = RISK_ORDER.get(final, -1)
        if floor_order > final_order:
            final = floor
            override_note = (
                (override_note or "") +
                f" | Rule {finding.rule_id} enforces floor={floor.value}"
            )

    return final, override_note.strip(" |") if override_note else None


# Import RISK_ORDER here to avoid circular import (models.py → engine)
from models import RISK_ORDER  # noqa: E402


# ---------------------------------------------------------------------------
# Main scoring function
# ---------------------------------------------------------------------------

@dataclass
class ScoreResult:
    score: float
    category: RiskCategory
    override_note: Optional[str]
    breakdown: List[dict]  # [{rule_id, title, weight, evidence_summary}]
    no_issues_text: str = (
        "No issues detected by these checks. "
        "This does not guarantee the file or URL is safe."
    )


def compute_score(findings: List[Finding]) -> ScoreResult:
    """
    Compute the final risk score and category from a list of Findings.

    Parameters
    ----------
    findings:
        All Finding objects produced by the analysis. May be empty.

    Returns
    -------
    ScoreResult with:
      - score: numeric sum of triggered rule weights
      - category: final RiskCategory after overrides
      - override_note: human-readable note if an override was applied
      - breakdown: list of dicts suitable for the UI table
    """
    if not findings:
        return ScoreResult(
            score=0.0,
            category=RiskCategory.UNKNOWN,
            override_note=None,
            breakdown=[],
        )

    score = 0.0
    breakdown: List[dict] = []

    for finding in findings:
        rule_def = RULE_DEFINITIONS.get(finding.rule_id)
        weight = rule_def.base_weight if rule_def else 0.0
        score += weight
        breakdown.append({
            "rule_id": finding.rule_id,
            "title": finding.title,
            "weight": weight,
            "evidence_summary": "; ".join(
                f"{e.label}: {e.value}" for e in finding.evidence
            ),
            "override_applied": "",
        })

    computed = score_to_category(score)
    final_category, override_note = _apply_overrides(computed, findings)

    # Annotate the breakdown with override info
    if override_note:
        for entry in breakdown:
            if entry["rule_id"] in (
                "URL-SSRF-BLOCKED", "REP-MALICIOUS-REPORTED", "FILE-EXEC-DISGUISED"
            ):
                entry["override_applied"] = override_note

    return ScoreResult(
        score=score,
        category=final_category,
        override_note=override_note,
        breakdown=breakdown,
    )
