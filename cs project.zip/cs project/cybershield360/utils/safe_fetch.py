"""
utils/safe_fetch.py – SSRF-safe HTTP layer for CyberShield 360.

This module is the ONLY entry point for any outbound HTTP/HTTPS request made
by the application. It enforces strict SSRF protections and must never be
bypassed.

Key safety properties
---------------------
* Only http:// and https:// schemes are accepted.
* All resolved IP addresses (A and AAAA) are checked against the private/
  reserved address space. If ANY resolved address is non-public the request
  is blocked.
* DNS rebinding is defeated by pinning the validated IP at connection time and
  sending the original Host header for SNI/certificate validation.
* Redirects are followed manually (max 5 hops); every hop is fully validated.
* Only HEAD (or a zero-body GET with Range: bytes=0-0) is sent. The response
  body is never downloaded; if any body bytes are accidentally received they
  are capped at 64 KB and discarded.
* Timeouts: 3 s connect, 5 s read, 8 s total wall-clock.
* Cookies, auth headers, and environment proxies are disabled.
* A simple in-memory rate limit (N checks/minute per Python process).
"""
from __future__ import annotations

import ipaddress
import socket
import time
import threading
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse, urlunparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from config import (
    SAFE_FETCH_ALLOWED_PORTS,
    SAFE_FETCH_CONNECT_TIMEOUT,
    SAFE_FETCH_MAX_BODY_BYTES,
    SAFE_FETCH_MAX_HOPS,
    SAFE_FETCH_MAX_RESPONSE_HEADERS,
    SAFE_FETCH_MAX_URL_LENGTH,
    SAFE_FETCH_RATE_LIMIT_PER_MINUTE,
    SAFE_FETCH_READ_TIMEOUT,
    SAFE_FETCH_USER_AGENT,
    SAFE_FETCH_WALL_CLOCK_BUDGET,
)
from utils.logging_utils import safe_event


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

@dataclass
class HopInfo:
    url: str            # defanged representation stored; raw used internally
    status_code: Optional[int]
    location: Optional[str]
    cross_domain: bool = False
    https_downgrade: bool = False
    ip_literal_redirect: bool = False
    blocked: bool = False
    block_reason: str = ""


@dataclass
class FetchResult:
    success: bool
    blocked: bool = False
    block_reason: str = ""
    final_url: str = ""
    status_code: Optional[int] = None
    content_type: Optional[str] = None
    content_length: Optional[int] = None
    content_disposition: Optional[str] = None
    redirect_chain: List[HopInfo] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    error: Optional[str] = None
    resolved_ip: Optional[str] = None
    # Headers as a plain dict (header names lowercased)
    headers: Dict[str, str] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Rate limiter (per process, per minute)
# ---------------------------------------------------------------------------

class _RateLimiter:
    def __init__(self, max_per_minute: int) -> None:
        self._max = max_per_minute
        self._lock = threading.Lock()
        self._calls: List[float] = []
        self._inflight = threading.Semaphore(1)  # one in-flight at a time

    def acquire(self) -> Tuple[bool, str]:
        """Return (allowed, reason). Thread-safe."""
        with self._lock:
            now = time.monotonic()
            cutoff = now - 60.0
            self._calls = [t for t in self._calls if t > cutoff]
            if len(self._calls) >= self._max:
                return False, f"Rate limit exceeded ({self._max} checks/minute)"
            self._calls.append(now)
            return True, ""


_rate_limiter = _RateLimiter(SAFE_FETCH_RATE_LIMIT_PER_MINUTE)


# ---------------------------------------------------------------------------
# IP classification helpers
# ---------------------------------------------------------------------------

def _is_globally_routable(addr_str: str) -> Tuple[bool, str]:
    """
    Return (is_routable, reason).

    Rejects any address that is NOT globally routable:
      - loopback (127.0.0.0/8, ::1)
      - RFC1918 (10/8, 172.16/12, 192.168/16)
      - link-local (169.254.0.0/16, fe80::/10) — includes AWS metadata 169.254.169.254
      - CGNAT (100.64.0.0/10)
      - multicast (224.0.0.0/4, ff00::/8)
      - unspecified (0.0.0.0, ::)
      - reserved / documentation ranges
      - IPv6 ULA (fc00::/7)
      - IPv4-mapped IPv6 that encodes a non-public IPv4 (::ffff:x.x.x.x)
      - 6to4 (2002::/16) embedding a non-public IPv4
      - NAT64 (64:ff9b::/96) embedding a non-public IPv4
    """
    try:
        addr = ipaddress.ip_address(addr_str)
    except ValueError:
        return False, f"Cannot parse IP address: {addr_str!r}"

    # Unwrap IPv4-mapped IPv6 (::ffff:x.x.x.x)
    if isinstance(addr, ipaddress.IPv6Address):
        mapped = addr.ipv4_mapped
        if mapped is not None:
            ok, reason = _is_globally_routable(str(mapped))
            if not ok:
                return False, f"IPv4-mapped IPv6 encodes non-public IPv4: {reason}"
            # The embedded IPv4 is public — accept this address; skip further IPv6 checks
            # (Python's is_private on ::ffff:public_ip can return True incorrectly on 3.11+)
            return True, ""

        # 6to4: 2002:xxyy:zzww:: → embedded IPv4 is xx.yy.zz.ww
        if addr in ipaddress.ip_network("2002::/16"):
            packed = addr.packed
            embedded_ipv4 = ipaddress.IPv4Address(packed[2:6])
            ok, reason = _is_globally_routable(str(embedded_ipv4))
            if not ok:
                return False, f"6to4 address embeds non-public IPv4: {reason}"

        # NAT64: 64:ff9b::/96
        if addr in ipaddress.ip_network("64:ff9b::/96"):
            packed = addr.packed
            embedded_ipv4 = ipaddress.IPv4Address(packed[12:16])
            ok, reason = _is_globally_routable(str(embedded_ipv4))
            if not ok:
                return False, f"NAT64 address embeds non-public IPv4: {reason}"

        # IPv6 ULA fc00::/7
        if addr in ipaddress.ip_network("fc00::/7"):
            return False, "IPv6 ULA address (fc00::/7) – not globally routable"

    checks: List[Tuple[object, str]] = [
        (addr.is_loopback, "loopback address"),
        (addr.is_link_local, "link-local address"),
        (addr.is_multicast, "multicast address"),
        (addr.is_unspecified, "unspecified address (0.0.0.0 / ::)"),
        (addr.is_reserved, "reserved address range"),
    ]
    for condition, reason in checks:
        if condition:
            return False, reason

    # Private (RFC1918 etc.)
    if addr.is_private:
        return False, "private/RFC1918 address"

    # CGNAT 100.64.0.0/10
    if isinstance(addr, ipaddress.IPv4Address):
        if addr in ipaddress.ip_network("100.64.0.0/10"):
            return False, "CGNAT address (100.64.0.0/10)"

    return True, ""


def _resolve_and_validate(hostname: str) -> Tuple[Optional[str], str]:
    """
    Resolve hostname → validate ALL returned addresses.
    Returns (first_public_ip, "") on success, or (None, block_reason).
    """
    try:
        results = socket.getaddrinfo(hostname, None)
    except socket.gaierror as exc:
        return None, f"DNS resolution failed: {exc}"

    first_public: Optional[str] = None
    for family, _type, _proto, _canonname, sockaddr in results:
        ip_str = sockaddr[0]
        routable, reason = _is_globally_routable(ip_str)
        if not routable:
            return None, f"Resolved IP {ip_str!r} is non-public: {reason}"
        if first_public is None:
            first_public = ip_str

    if first_public is None:
        return None, "No addresses returned by DNS"

    return first_public, ""


# ---------------------------------------------------------------------------
# URL validation
# ---------------------------------------------------------------------------

def _parse_and_validate_url(raw_url: str) -> Tuple[Optional[str], List[str], List[str]]:
    """
    Validate and normalise a URL.

    Returns (normalised_url_or_None, errors, warnings).
    Errors = blocking problems. Warnings = informational signals.
    """
    errors: List[str] = []
    warnings: List[str] = []

    if len(raw_url) > SAFE_FETCH_MAX_URL_LENGTH:
        errors.append(f"URL length {len(raw_url)} exceeds maximum {SAFE_FETCH_MAX_URL_LENGTH}")
        return None, errors, warnings

    try:
        parsed = urlparse(raw_url)
    except Exception as exc:
        errors.append(f"URL parse error: {exc}")
        return None, errors, warnings

    # Scheme check
    if parsed.scheme not in ("http", "https"):
        errors.append(
            f"Scheme {parsed.scheme!r} is not allowed. Only 'http' and 'https' are permitted."
        )
        return None, errors, warnings

    # Embedded credentials
    if parsed.username or parsed.password:
        errors.append("URLs with embedded credentials (user:pass@) are not allowed.")
        return None, errors, warnings

    # Hostname
    hostname = parsed.hostname
    if not hostname:
        errors.append("URL has no hostname.")
        return None, errors, warnings

    # IDN → punycode
    try:
        hostname_encoded = hostname.encode("idna").decode("ascii")
    except (UnicodeError, UnicodeDecodeError):
        hostname_encoded = hostname

    if hostname_encoded != hostname:
        warnings.append(f"IDN hostname normalised to punycode: {hostname_encoded!r}")

    # IP literal host
    try:
        addr = ipaddress.ip_address(hostname_encoded)
        routable, reason = _is_globally_routable(str(addr))
        if not routable:
            errors.append(f"IP-literal host {hostname_encoded!r} is non-public: {reason}")
            return None, errors, warnings
        warnings.append(f"Host is an IP literal address: {hostname_encoded!r}")
    except ValueError:
        pass  # Not an IP literal, continue

    # Port
    port = parsed.port
    if port is not None and port not in SAFE_FETCH_ALLOWED_PORTS:
        errors.append(
            f"Port {port} is not in the allowed set {sorted(SAFE_FETCH_ALLOWED_PORTS)}."
        )
        return None, errors, warnings

    # Informational signals (warnings only)
    subdomain_count = hostname_encoded.count(".")
    if subdomain_count > 4:
        warnings.append(f"Hostname has many labels ({subdomain_count} dots): {hostname_encoded!r}")

    known_tlds = {
        "com", "org", "net", "edu", "gov", "mil", "int",
        "io", "co", "uk", "de", "fr", "jp", "au", "ca",
    }
    tld = hostname_encoded.rsplit(".", 1)[-1].lower() if "." in hostname_encoded else ""
    if tld and tld not in known_tlds:
        warnings.append(f"Unusual TLD: .{tld!r}")

    if "@" in parsed.path:
        warnings.append("URL path contains '@' which may be used for deception.")

    # Reconstruct normalised URL with encoded hostname
    netloc = hostname_encoded
    if port is not None:
        netloc = f"{netloc}:{port}"
    normalised = urlunparse((
        parsed.scheme,
        netloc,
        parsed.path,
        parsed.params,
        parsed.query,
        parsed.fragment,
    ))

    return normalised, errors, warnings


def defang_url(url: str) -> str:
    """Return an inert defanged representation: hxxps://example[.]com/path"""
    defanged = url.replace("http://", "hxxp://").replace("https://", "hxxps://")
    # Replace dots in the hostname only (up to the first /)
    parts = defanged.split("/", 3)
    if len(parts) >= 3:
        host_part = parts[2]
        parts[2] = host_part.replace(".", "[.]")
        return "/".join(parts)
    return defanged.replace(".", "[.]")


def strip_query_string(url: str) -> str:
    """Remove query string and fragment from a URL (for safe storage)."""
    try:
        p = urlparse(url)
        return urlunparse((p.scheme, p.netloc, p.path, p.params, "", ""))
    except Exception:
        return url


# ---------------------------------------------------------------------------
# Pinned-IP HTTP adapter (defeats DNS rebinding)
# ---------------------------------------------------------------------------

class _PinnedIPAdapter(HTTPAdapter):
    """
    An HTTPAdapter that resolves the hostname once (to a validated IP) and
    then connects directly to that IP, passing the original hostname in the
    Host header and using it for TLS SNI / certificate verification.

    This prevents DNS rebinding: the hostname is never re-resolved at
    connection time.
    """

    def __init__(self, pinned_ip: str, **kwargs):  # type: ignore[no-untyped-def]
        self._pinned_ip = pinned_ip
        super().__init__(**kwargs)

    def send(self, request, **kwargs):  # type: ignore[override]
        # Replace the hostname in the URL with the pinned IP
        parsed = urlparse(request.url)
        host = parsed.hostname or ""
        port = parsed.port

        # Build netloc with pinned IP
        if ":" in self._pinned_ip:  # IPv6
            ip_netloc = f"[{self._pinned_ip}]"
        else:
            ip_netloc = self._pinned_ip
        if port:
            ip_netloc = f"{ip_netloc}:{port}"

        pinned_url = urlunparse((
            parsed.scheme,
            ip_netloc,
            parsed.path,
            parsed.params,
            parsed.query,
            parsed.fragment,
        ))
        request.url = pinned_url

        # Ensure the Host header still carries the original hostname
        if port and port not in (80, 443):
            request.headers["Host"] = f"{host}:{port}"
        else:
            request.headers["Host"] = host

        return super().send(request, **kwargs)


# ---------------------------------------------------------------------------
# Core fetch logic
# ---------------------------------------------------------------------------

def _make_session(pinned_ip: str, hostname: str) -> requests.Session:
    session = requests.Session()
    session.trust_env = False           # ignore env proxies
    session.max_redirects = 0           # manual redirect handling
    session.cookies.clear()
    # No retry – we handle everything manually
    adapter = _PinnedIPAdapter(pinned_ip, max_retries=Retry(total=0))
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def _send_request(
    session: requests.Session,
    url: str,
    hostname: str,
) -> Tuple[Optional[requests.Response], Optional[str]]:
    """
    Send HEAD; fall back to range-GET if HEAD is refused.
    Returns (response_or_None, error_str_or_None).
    Never downloads the body.
    """
    timeout = (SAFE_FETCH_CONNECT_TIMEOUT, SAFE_FETCH_READ_TIMEOUT)
    headers = {
        "User-Agent": SAFE_FETCH_USER_AGENT,
        "Accept": "*/*",
        "Connection": "close",
    }
    try:
        resp = session.head(
            url,
            allow_redirects=False,
            timeout=timeout,
            headers=headers,
            verify=True,
            stream=True,
        )
        if resp.status_code in (405, 501):
            resp.close()
            # Fall back to range-GET
            headers["Range"] = "bytes=0-0"
            resp = session.get(
                url,
                allow_redirects=False,
                timeout=timeout,
                headers=headers,
                verify=True,
                stream=True,
            )
        # Consume and discard any body bytes (cap at MAX_BODY_BYTES)
        try:
            resp.raw.read(SAFE_FETCH_MAX_BODY_BYTES)
        except Exception:
            pass
        finally:
            resp.close()
        return resp, None
    except requests.exceptions.SSLError as exc:
        return None, f"TLS/SSL error: {exc}"
    except requests.exceptions.ConnectTimeout:
        return None, "Connection timed out"
    except requests.exceptions.ReadTimeout:
        return None, "Read timed out"
    except requests.exceptions.ConnectionError as exc:
        return None, f"Connection error: {exc}"
    except Exception as exc:
        return None, f"Request error: {exc}"


def fetch_url_metadata(raw_url: str) -> FetchResult:
    """
    The single safe entry point for all outbound HTTP/HTTPS calls.

    Validates the URL, resolves DNS with SSRF checks, pins the IP,
    follows redirects manually (max 5 hops), and returns metadata only.
    The target file body is NEVER downloaded.

    Parameters
    ----------
    raw_url:
        The URL to inspect.

    Returns
    -------
    FetchResult with success/block status, headers, redirect chain, etc.
    """
    # Rate limit
    allowed, rate_reason = _rate_limiter.acquire()
    if not allowed:
        return FetchResult(
            success=False,
            blocked=True,
            block_reason=rate_reason,
            error=rate_reason,
        )

    result = FetchResult(success=False)

    # Validate and normalise the initial URL
    normalised_url, errors, warnings = _parse_and_validate_url(raw_url)
    result.warnings.extend(warnings)
    if errors:
        result.blocked = True
        result.block_reason = "; ".join(errors)
        result.error = result.block_reason
        return result

    assert normalised_url is not None

    wall_start = time.monotonic()
    current_url = normalised_url
    previous_scheme: Optional[str] = None
    previous_host: Optional[str] = None

    for hop_index in range(SAFE_FETCH_MAX_HOPS + 1):
        # Wall-clock budget check
        elapsed = time.monotonic() - wall_start
        if elapsed >= SAFE_FETCH_WALL_CLOCK_BUDGET:
            result.blocked = True
            result.block_reason = f"Wall-clock budget of {SAFE_FETCH_WALL_CLOCK_BUDGET}s exceeded"
            result.error = result.block_reason
            return result

        if hop_index > SAFE_FETCH_MAX_HOPS:
            result.blocked = True
            result.block_reason = f"Redirect chain exceeds maximum of {SAFE_FETCH_MAX_HOPS} hops"
            result.error = result.block_reason
            return result

        # Validate this hop's URL
        hop_url_normalised, hop_errors, hop_warnings = _parse_and_validate_url(current_url)
        result.warnings.extend(hop_warnings)
        if hop_errors:
            hop = HopInfo(
                url=defang_url(current_url),
                status_code=None,
                location=None,
                blocked=True,
                block_reason="; ".join(hop_errors),
            )
            result.redirect_chain.append(hop)
            result.blocked = True
            result.block_reason = f"Hop {hop_index + 1} blocked: {'; '.join(hop_errors)}"
            result.error = result.block_reason
            return result

        assert hop_url_normalised is not None
        parsed_hop = urlparse(hop_url_normalised)
        hop_hostname = parsed_hop.hostname or ""
        hop_scheme = parsed_hop.scheme

        # Cross-domain detection
        cross_domain = (
            previous_host is not None and
            hop_hostname.lstrip("www.") != (previous_host or "").lstrip("www.")
        )

        # HTTPS → HTTP downgrade detection
        https_downgrade = previous_scheme == "https" and hop_scheme == "http"
        if https_downgrade:
            result.warnings.append(
                f"Hop {hop_index + 1}: HTTPS → HTTP downgrade detected"
            )

        # IP literal redirect
        ip_literal_redirect = False
        try:
            ipaddress.ip_address(hop_hostname)
            ip_literal_redirect = True
            result.warnings.append(
                f"Hop {hop_index + 1}: redirect target is an IP literal ({hop_hostname!r})"
            )
        except ValueError:
            pass

        # DNS resolution + SSRF check
        try:
            # Check if it's already an IP literal (validated above)
            addr_obj = ipaddress.ip_address(hop_hostname)
            routable, reason = _is_globally_routable(str(addr_obj))
            if not routable:
                hop = HopInfo(
                    url=defang_url(hop_url_normalised),
                    status_code=None,
                    location=None,
                    blocked=True,
                    block_reason=f"IP-literal host is non-public: {reason}",
                    ip_literal_redirect=True,
                )
                result.redirect_chain.append(hop)
                result.blocked = True
                result.block_reason = hop.block_reason
                result.error = hop.block_reason
                return result
            pinned_ip = str(addr_obj)
        except ValueError:
            # Normal hostname: resolve and validate
            pinned_ip, dns_error = _resolve_and_validate(hop_hostname)
            if pinned_ip is None:
                hop = HopInfo(
                    url=defang_url(hop_url_normalised),
                    status_code=None,
                    location=None,
                    blocked=True,
                    block_reason=dns_error,
                )
                result.redirect_chain.append(hop)
                result.blocked = True
                result.block_reason = f"Hop {hop_index + 1} DNS/SSRF block: {dns_error}"
                result.error = result.block_reason
                return result

        result.resolved_ip = pinned_ip

        # Build a session pinned to the validated IP
        session = _make_session(pinned_ip, hop_hostname)

        # Send the request
        resp, req_error = _send_request(session, hop_url_normalised, hop_hostname)
        if req_error:
            hop = HopInfo(
                url=defang_url(hop_url_normalised),
                status_code=None,
                location=None,
                cross_domain=cross_domain,
                https_downgrade=https_downgrade,
                ip_literal_redirect=ip_literal_redirect,
                blocked=False,
                block_reason="",
            )
            result.redirect_chain.append(hop)
            result.error = req_error
            return result

        assert resp is not None

        # Validate header count
        if len(resp.headers) > SAFE_FETCH_MAX_RESPONSE_HEADERS:
            result.warnings.append(
                f"Response has unusually many headers ({len(resp.headers)}); "
                "truncating to first {SAFE_FETCH_MAX_RESPONSE_HEADERS}"
            )

        location = resp.headers.get("Location")
        hop_info = HopInfo(
            url=defang_url(hop_url_normalised),
            status_code=resp.status_code,
            location=defang_url(location) if location else None,
            cross_domain=cross_domain,
            https_downgrade=https_downgrade,
            ip_literal_redirect=ip_literal_redirect,
        )
        result.redirect_chain.append(hop_info)

        previous_scheme = hop_scheme
        previous_host = hop_hostname

        # Is this a redirect?
        if resp.status_code in (301, 302, 303, 307, 308) and location:
            # Resolve relative redirect
            if location.startswith("/"):
                location = f"{hop_scheme}://{parsed_hop.netloc}{location}"
            elif not location.startswith("http"):
                # Relative path
                path_base = parsed_hop.path.rsplit("/", 1)[0] if "/" in parsed_hop.path else ""
                location = f"{hop_scheme}://{parsed_hop.netloc}{path_base}/{location}"
            current_url = location
            continue

        # Final response
        headers_dict = {k.lower(): v for k, v in list(resp.headers.items())[:SAFE_FETCH_MAX_RESPONSE_HEADERS]}
        result.success = True
        result.final_url = defang_url(hop_url_normalised)
        result.status_code = resp.status_code
        result.content_type = resp.headers.get("Content-Type")
        result.content_length = _safe_int(resp.headers.get("Content-Length"))
        result.content_disposition = resp.headers.get("Content-Disposition")
        result.headers = headers_dict

        safe_event(
            "safe_fetch.complete",
            extra={
                "hops": len(result.redirect_chain),
                "status": result.status_code,
                "blocked": result.blocked,
            },
        )
        return result

    # Exhausted hop budget (shouldn't reach here due to check above)
    result.blocked = True
    result.block_reason = "Redirect loop detected"
    result.error = result.block_reason
    return result


def _safe_int(value: Optional[str]) -> Optional[int]:
    if value is None:
        return None
    try:
        return int(value)
    except (ValueError, TypeError):
        return None
