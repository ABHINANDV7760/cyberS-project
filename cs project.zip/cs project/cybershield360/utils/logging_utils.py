"""
utils/logging_utils.py – Safe structured logging for CyberShield 360.

Provides safe_event() which redacts secrets and never logs full URLs, file
contents, or API keys.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional

logger = logging.getLogger("cybershield360")

# ---------------------------------------------------------------------------
# Redaction patterns
# ---------------------------------------------------------------------------

_SECRET_KEYS = re.compile(
    r"(api[_-]?key|secret|password|token|auth|credential)", re.IGNORECASE
)
_URL_QUERY = re.compile(r"\?.*$")
_CREDENTIALS_IN_URL = re.compile(r"(https?://)([^@]+@)")


def _redact_value(key: str, value: Any) -> Any:
    """Return '[REDACTED]' if key looks like a secret."""
    if isinstance(key, str) and _SECRET_KEYS.search(key):
        return "[REDACTED]"
    if isinstance(value, str):
        # Strip query strings from URLs
        value = _URL_QUERY.sub("", value)
        # Strip credentials from URLs
        value = _CREDENTIALS_IN_URL.sub(r"\1[REDACTED]@", value)
    return value


def safe_event(
    event: str,
    level: int = logging.INFO,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Log a structured event with automatic redaction of secrets.

    Parameters
    ----------
    event:
        Short human-readable description of what happened.
    level:
        logging level constant (default INFO).
    extra:
        Optional dict of key/value pairs to include. Secret keys are
        replaced with '[REDACTED]'. URL values have query strings stripped.
    """
    safe_extra: Dict[str, Any] = {}
    if extra:
        for k, v in extra.items():
            safe_extra[k] = _redact_value(k, v)

    msg = event
    if safe_extra:
        pairs = ", ".join(f"{k}={v!r}" for k, v in safe_extra.items())
        msg = f"{event} | {pairs}"

    logger.log(level, msg)


def configure_logging(debug: bool = False) -> None:
    """Set up basic logging configuration. Call once at startup."""
    logging.basicConfig(
        level=logging.DEBUG if debug else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
