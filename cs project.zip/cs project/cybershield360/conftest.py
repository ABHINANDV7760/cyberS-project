"""
conftest.py – pytest configuration for CyberShield 360 tests.
"""
import sys
from pathlib import Path

# Ensure the cybershield360/ directory is on sys.path
sys.path.insert(0, str(Path(__file__).parent))
