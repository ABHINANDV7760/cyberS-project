"""
app.py – CyberShield 360 Streamlit application entry point.

Run with:
    cd cybershield360
    streamlit run app.py

Modules:
  • Download Guard  (fully implemented — this file)
"""
from __future__ import annotations

import io
import json
import os
import sys
import threading
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse

import pandas as pd
import plotly.express as px
import streamlit as st

# Ensure the cybershield360/ directory is on sys.path so relative imports work
_HERE = Path(__file__).parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from config import (
    APP_NAME,
    APP_VERSION,
    AUDIO_MAX_BYTES,
    DATA_DIR,
    MODULE_DOWNLOAD_GUARD,
    MODULE_FRAUD_CALL_DETECTOR,
    SAMPLES_DIR,
)
from database import add_scan_with_findings
from engine.risk_engine import RULE_DEFINITIONS, SCORE_THRESHOLDS, compute_score
from integrations.reputation_provider import (
    NoApiProvider,
    ReputationResult,
    get_available_providers,
    get_provider_by_name,
)
from models import Evidence, Finding, RiskCategory, Scan, risk_label
from modules.download_guard import (
    FileRecord,
    analyze_file,
    analyze_url,
    detect_type,
    sha256_file,
    sha256_stream,
    walk_folder,
)
from modules.fraud_call_detector import (
    CALL_RULE_DEFINITIONS,
    AnalysisResult,
    analyse_transcript,
)
from utils.logging_utils import configure_logging, safe_event
from utils.safe_fetch import defang_url, fetch_url_metadata, strip_query_string

configure_logging(debug=False)

# ---------------------------------------------------------------------------
# Page configuration
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title=f"{APP_NAME} — Download Guard",
    page_icon="🛡️",
    layout="wide",
)


# ---------------------------------------------------------------------------
# Theme injection (visual restyle — no logic changes)
# ---------------------------------------------------------------------------

_THEME_CSS = """
<style>
/* ═══════════════════════════════════════════════════════════════════════════
   CyberShield 360 — Streamlit theme
   Blue-Black Cyber Security (Anton + Raleway, dark teal palette)
   Injected once at startup; overrides Streamlit defaults only.
   All security logic, disclaimers, and wording are untouched.
   ═══════════════════════════════════════════════════════════════════════════ */

@import url('https://fonts.googleapis.com/css2?family=Anton&family=Montserrat:wght@600;700&family=Raleway:wght@400;500;600&display=swap');

/* ─── Tokens ────────────────────────────────────────────────────────────── */
:root {
  --bg-deep:    #001a20;
  --bg-base:    #082631;
  --bg-panel:   #0e2c34;
  --bg-card:    #040612;
  --accent-1:   #44d7e9;
  --accent-2:   #32b0c7;
  --accent-3:   #2a8393;
  --accent-glow: rgba(68,215,233,0.22);
  --text-head:  #ffffff;
  --text-body:  #cfe9ee;
  --text-muted: #7aaebb;
  --border:     rgba(68,215,233,0.25);
  --border-mid: rgba(68,215,233,0.45);
  /* Risk colors — distinct from cyan, never used as "safe" */
  --risk-info:     #5b7fa6;
  --risk-low:      #d4a017;
  --risk-medium:   #e07820;
  --risk-high:     #d63c3c;
  --risk-critical: #9b1c42;
  --risk-blocked:  #9b1c42;
  --risk-unknown:  #5b7fa6;
  --font-head: 'Anton', 'Impact', sans-serif;
  --font-body: 'Raleway', system-ui, sans-serif;
  --font-label:'Montserrat', 'Inter', system-ui, sans-serif;
  --font-mono: 'SFMono-Regular', Consolas, monospace;
  --radius: 6px; --radius-lg: 10px;
}

/* ─── App background + circuit texture ──────────────────────────────────── */
.stApp {
  background: var(--bg-deep) !important;
  background-image:
    radial-gradient(ellipse 80% 50% at 50% -10%, rgba(68,215,233,0.07) 0%, transparent 70%),
    repeating-linear-gradient(0deg,   transparent, transparent 39px, rgba(68,215,233,0.035) 40px),
    repeating-linear-gradient(90deg,  transparent, transparent 39px, rgba(68,215,233,0.035) 40px) !important;
  background-attachment: fixed !important;
  color: var(--text-body) !important;
  font-family: var(--font-body) !important;
}

/* ─── Sidebar ────────────────────────────────────────────────────────────── */
[data-testid="stSidebar"] {
  background: var(--bg-card) !important;
  border-right: 1px solid var(--border-mid) !important;
}
[data-testid="stSidebar"] * { color: var(--text-body) !important; font-family: var(--font-body) !important; }
[data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3 {
  font-family: var(--font-head) !important;
  letter-spacing: 0.08em !important;
  text-transform: uppercase !important;
  color: var(--text-head) !important;
}

/* ─── Top bar / toolbar strip ────────────────────────────────────────────── */
[data-testid="stHeader"] {
  background: var(--bg-card) !important;
  border-bottom: 1px solid var(--border-mid) !important;
}

/* ─── Page title ─────────────────────────────────────────────────────────── */
h1 {
  font-family: var(--font-head) !important;
  font-size: clamp(1.5rem, 3.5vw, 2.2rem) !important;
  letter-spacing: 0.08em !important;
  text-transform: uppercase !important;
  color: var(--text-head) !important;
  background: linear-gradient(135deg, var(--accent-1) 0%, var(--accent-3) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
h2, h3 {
  font-family: var(--font-head) !important;
  letter-spacing: 0.06em !important;
  text-transform: uppercase !important;
  color: var(--text-head) !important;
}
h2 { font-size: 1.15rem !important; }
h3 { font-size: 1rem !important; }

/* ─── Body text & captions ───────────────────────────────────────────────── */
p, li, span, label, .stMarkdown {
  color: var(--text-body) !important;
  font-family: var(--font-body) !important;
}
.stCaption, small, caption { color: var(--text-muted) !important; font-size: 0.82rem !important; }

/* ─── Buttons ────────────────────────────────────────────────────────────── */
.stButton > button {
  background: linear-gradient(90deg, var(--accent-1), var(--accent-3)) !important;
  color: #001a20 !important;
  border: none !important;
  border-radius: var(--radius) !important;
  font-family: var(--font-label) !important;
  font-weight: 700 !important;
  letter-spacing: 0.04em !important;
  transition: box-shadow 0.2s, background 0.2s !important;
}
.stButton > button:hover {
  background: linear-gradient(90deg, var(--accent-2), var(--accent-3)) !important;
  box-shadow: 0 0 14px var(--accent-glow) !important;
}
.stButton > button:focus-visible {
  outline: 2px solid var(--accent-1) !important;
  outline-offset: 3px !important;
}
/* Secondary buttons (outline style via kind="secondary") */
.stButton > button[kind="secondary"] {
  background: transparent !important;
  color: var(--text-body) !important;
  border: 1px solid var(--border-mid) !important;
}
.stButton > button[kind="secondary"]:hover {
  background: rgba(68,215,233,0.06) !important;
  border-color: var(--accent-1) !important;
  color: var(--accent-1) !important;
  box-shadow: none !important;
}

/* ─── Text inputs & selects ──────────────────────────────────────────────── */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea,
.stSelectbox > div > div,
.stMultiSelect > div > div {
  background: var(--bg-panel) !important;
  border: 1px solid var(--border) !important;
  border-radius: var(--radius) !important;
  color: var(--text-body) !important;
  font-family: var(--font-body) !important;
}
.stTextInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus {
  border-color: var(--accent-1) !important;
  box-shadow: 0 0 10px var(--accent-glow) !important;
  outline: none !important;
}
.stTextInput label, .stTextArea label, .stSelectbox label,
.stMultiSelect label, .stRadio label, .stCheckbox label {
  font-family: var(--font-label) !important;
  font-weight: 700 !important;
  font-size: 0.85rem !important;
  letter-spacing: 0.04em !important;
  color: var(--text-head) !important;
}

/* ─── Tabs ───────────────────────────────────────────────────────────────── */
.stTabs [data-baseweb="tab-list"] {
  background: var(--bg-card) !important;
  border-bottom: 2px solid var(--border) !important;
  gap: 0 !important;
}
.stTabs [data-baseweb="tab"] {
  font-family: var(--font-label) !important;
  font-weight: 600 !important;
  letter-spacing: 0.04em !important;
  color: var(--text-muted) !important;
  background: transparent !important;
  border-bottom: 2px solid transparent !important;
  border-radius: 0 !important;
  padding: 0.8rem 1.3rem !important;
  transition: color 0.15s !important;
}
.stTabs [aria-selected="true"] {
  color: var(--accent-1) !important;
  border-bottom: 2px solid var(--accent-1) !important;
  background: rgba(68,215,233,0.04) !important;
}
.stTabs [data-baseweb="tab-highlight"] { background: var(--accent-1) !important; }
.stTabs [data-baseweb="tab-panel"] { background: transparent !important; padding: 1.5rem 0 !important; }

/* ─── Metrics ────────────────────────────────────────────────────────────── */
[data-testid="stMetricValue"] {
  font-family: var(--font-head) !important;
  color: var(--accent-1) !important;
  letter-spacing: 0.05em !important;
}
[data-testid="stMetricLabel"] {
  font-family: var(--font-label) !important;
  color: var(--text-muted) !important;
  font-size: 0.78rem !important;
  text-transform: uppercase !important;
  letter-spacing: 0.05em !important;
}

/* ─── Expanders ──────────────────────────────────────────────────────────── */
.streamlit-expanderHeader {
  background: var(--bg-panel) !important;
  border: 1px solid var(--border) !important;
  border-radius: var(--radius-lg) !important;
  font-family: var(--font-label) !important;
  font-weight: 700 !important;
  color: var(--text-head) !important;
  letter-spacing: 0.04em !important;
}
.streamlit-expanderHeader:hover { background: rgba(68,215,233,0.05) !important; }
.streamlit-expanderContent {
  background: var(--bg-panel) !important;
  border: 1px solid var(--border) !important;
  border-top: none !important;
  border-radius: 0 0 var(--radius-lg) var(--radius-lg) !important;
}

/* ─── Info / warning / error / success boxes ─────────────────────────────── */
/* These carry safety-critical wording — must stay prominently visible */
[data-testid="stAlert"] {
  border-radius: var(--radius) !important;
  font-family: var(--font-body) !important;
  font-size: 0.9rem !important;
}
/* info */
[data-testid="stAlert"][kind="info"], .stAlert.info {
  background: rgba(68,215,233,0.08) !important;
  border-left: 4px solid var(--accent-3) !important;
  color: var(--text-body) !important;
}
/* warning */
[data-testid="stAlert"][kind="warning"], .stAlert.warning {
  background: rgba(212,160,23,0.12) !important;
  border-left: 4px solid #d4a017 !important;
  color: var(--text-body) !important;
}
/* error */
[data-testid="stAlert"][kind="error"], .stAlert.error {
  background: rgba(214,60,60,0.12) !important;
  border-left: 4px solid var(--risk-high) !important;
  color: var(--text-body) !important;
}
/* success */
[data-testid="stAlert"][kind="success"], .stAlert.success {
  background: rgba(42,131,147,0.12) !important;
  border-left: 4px solid var(--accent-3) !important;
  color: var(--text-body) !important;
}

/* ─── DataFrame / tables ─────────────────────────────────────────────────── */
[data-testid="stDataFrame"] {
  background: var(--bg-panel) !important;
  border: 1px solid var(--border) !important;
  border-radius: var(--radius) !important;
}
.dataframe thead th {
  background: linear-gradient(90deg, var(--accent-2), var(--accent-3)) !important;
  color: #001a20 !important;
  font-family: var(--font-label) !important;
  font-weight: 700 !important;
  letter-spacing: 0.04em !important;
  border-bottom: 2px solid var(--border) !important;
}
.dataframe tbody tr:nth-child(even) td { background: rgba(68,215,233,0.025) !important; }
.dataframe tbody tr:hover td { background: rgba(68,215,233,0.05) !important; }
.dataframe td, .dataframe th { color: var(--text-body) !important; border-color: var(--border) !important; }

/* ─── Progress bar ───────────────────────────────────────────────────────── */
[data-testid="stProgress"] > div {
  background: var(--bg-card) !important;
  border-radius: 99px !important;
}
[data-testid="stProgress"] > div > div {
  background: linear-gradient(90deg, var(--accent-1), var(--accent-3)) !important;
}

/* ─── Code blocks ────────────────────────────────────────────────────────── */
code, pre, .stCode {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  border-radius: var(--radius) !important;
  color: var(--accent-1) !important;
  font-family: var(--font-mono) !important;
}

/* ─── Dividers ───────────────────────────────────────────────────────────── */
hr { border-color: var(--border) !important; }

/* ─── File uploader ──────────────────────────────────────────────────────── */
[data-testid="stFileUploader"] {
  background: var(--bg-panel) !important;
  border: 2px dashed var(--border-mid) !important;
  border-radius: var(--radius-lg) !important;
}
[data-testid="stFileUploader"] label { color: var(--text-head) !important; font-weight: 700 !important; }
[data-testid="stFileUploader"]:hover { border-color: var(--accent-1) !important; }

/* ─── Radio buttons / checkboxes ─────────────────────────────────────────── */
[data-testid="stRadio"] [data-testid="stMarkdownContainer"] p,
[data-testid="stCheckbox"] span {
  color: var(--text-body) !important;
}

/* ─── Spinner ────────────────────────────────────────────────────────────── */
[data-testid="stSpinner"] > div { border-top-color: var(--accent-1) !important; }

/* ─── Download button ────────────────────────────────────────────────────── */
.stDownloadButton > button {
  background: transparent !important;
  color: var(--accent-1) !important;
  border: 1px solid var(--border-mid) !important;
  font-family: var(--font-label) !important;
  font-weight: 700 !important;
}
.stDownloadButton > button:hover { background: rgba(68,215,233,0.06) !important; }

/* ─── Plotly chart container ─────────────────────────────────────────────── */
[data-testid="stPlotlyChart"] { background: transparent !important; }

/* ─── Tooltip / help icons ───────────────────────────────────────────────── */
[data-testid="stTooltipIcon"] svg { fill: var(--text-muted) !important; }

/* ─── Reduced motion ─────────────────────────────────────────────────────── */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
</style>
"""


def _inject_theme() -> None:
    """Inject the dark-teal Cyber Security theme CSS. Called once at app startup."""
    st.markdown(_THEME_CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Risk token map (design tokens: distinct from accent, never "safe"-colored)
_RISK_TOKENS: dict[RiskCategory, dict] = {
    RiskCategory.INFORMATIONAL: {"hex": "#5b7fa6", "label_cls": "risk-info",     "icon": "ℹ️"},
    RiskCategory.LOW:           {"hex": "#d4a017", "label_cls": "risk-low",      "icon": "🟡"},
    RiskCategory.MEDIUM:        {"hex": "#e07820", "label_cls": "risk-medium",   "icon": "🟠"},
    RiskCategory.HIGH:          {"hex": "#d63c3c", "label_cls": "risk-high",     "icon": "🔴"},
    RiskCategory.CRITICAL:      {"hex": "#9b1c42", "label_cls": "risk-critical", "icon": "🚨"},
    RiskCategory.UNKNOWN:       {"hex": "#5b7fa6", "label_cls": "risk-unknown",  "icon": "❓"},
    RiskCategory.BLOCKED:       {"hex": "#9b1c42", "label_cls": "risk-blocked",  "icon": "🚫"},
}


def _risk_color(category: RiskCategory) -> str:
    return _RISK_TOKENS.get(category, {}).get("hex", "#5b7fa6")


def _show_risk_badge(category: RiskCategory) -> None:
    tok   = _RISK_TOKENS.get(category, _RISK_TOKENS[RiskCategory.UNKNOWN])
    label = risk_label(category)
    color = tok["hex"]
    # Pill badge: always icon + text + color (never color alone)
    st.markdown(
        f'<span style="'
        f'display:inline-flex;align-items:center;gap:0.4rem;'
        f'padding:0.35rem 1rem;border-radius:99px;'
        f'border:1px solid {color};'
        f'background:color-mix(in srgb,{color} 15%,transparent);'
        f'font-family:Montserrat,Inter,sans-serif;font-size:0.85rem;'
        f'font-weight:700;letter-spacing:0.05em;text-transform:uppercase;'
        f'color:{color}">'
        f'{label}'
        f'</span>',
        unsafe_allow_html=True,
    )


def _show_findings(findings: List[Finding]) -> None:
    """Render the list of triggered findings."""
    if not findings:
        st.info(
            "No issues detected by these checks. "
            "This does not guarantee the file or URL is safe."
        )
        return

    for f in findings:
        color = _risk_color(f.risk_category)
        # Card header styled with left-border color matching risk level
        expanded = f.risk_category in (RiskCategory.HIGH, RiskCategory.CRITICAL, RiskCategory.BLOCKED)
        with st.expander(
            f"{risk_label(f.risk_category)} — {f.title}  [{f.rule_id}]",
            expanded=expanded,
        ):
            # Styled card body
            st.markdown(
                f'<div style="border-left:4px solid {color};'
                f'padding:0.6rem 0.8rem;'
                f'background:rgba(0,0,0,0.15);border-radius:0 6px 6px 0;'
                f'margin-bottom:0.5rem">'
                f'<span style="font-family:Raleway,sans-serif;color:#cfe9ee;font-size:0.9rem">'
                f'{f.description}</span></div>',
                unsafe_allow_html=True,
            )
            if f.evidence:
                ev_rows = [{"Field": e.label, "Value": e.value} for e in f.evidence]
                st.table(pd.DataFrame(ev_rows))
            if f.confidence_note:
                st.caption(f"⚠️ Confidence note: {f.confidence_note}")
            if f.remediation:
                st.info(f"**Recommended action:** {f.remediation}")
            if f.is_simulated:
                st.warning("⚠️ SYNTHETIC result — demonstration data only.")


def _show_score_breakdown(score_result) -> None:
    """Render the transparent score-breakdown panel."""
    with st.expander("📊 HOW THIS SCORE WAS CALCULATED", expanded=False):
        st.markdown(
            "**Score** = sum of triggered rule weights. "
            "Thresholds: Informational=0, Low≥1, Medium≥20, High≥50, Critical≥80. "
            "This score is not a probability or accuracy measure."
        )
        if score_result.breakdown:
            df = pd.DataFrame(score_result.breakdown)
            df = df.rename(columns={
                "rule_id": "Rule ID",
                "title": "Rule Title",
                "weight": "Weight",
                "evidence_summary": "Evidence",
                "override_applied": "Override",
            })
            st.dataframe(df, use_container_width=True, hide_index=True)
        st.metric("Total score", f"{score_result.score:.1f}")
        if score_result.override_note:
            st.warning(f"Override applied: {score_result.override_note}")


def _show_recommended_actions(category: RiskCategory) -> None:
    actions = {
        RiskCategory.INFORMATIONAL: [
            "No action required, but stay vigilant.",
            "Compare the file hash with the publisher's officially published hash.",
        ],
        RiskCategory.LOW: [
            "Verify the file source with the publisher through an official channel.",
            "Compare the SHA-256 hash with the publisher's published hash.",
            "Scan with up-to-date endpoint protection before use.",
        ],
        RiskCategory.MEDIUM: [
            "Do not open this file or visit this URL without further verification.",
            "Contact the sender through a separate trusted channel to confirm.",
            "Scan with up-to-date endpoint protection or a sandbox environment.",
            "Ask your IT/security team if you are unsure.",
        ],
        RiskCategory.HIGH: [
            "**Do not open this file or visit this URL.**",
            "Report to your IT/security team immediately.",
            "Compare the SHA-256 hash with the publisher's published hash.",
            "Submit to a sandbox for behavioural analysis.",
            "If you want to delete the file, do so yourself — this app never deletes anything.",
        ],
        RiskCategory.CRITICAL: [
            "**Do not open this file or visit this URL under any circumstances.**",
            "Isolate the file and report to your security team immediately.",
            "Do not forward or share the file.",
            "If you want to delete the file, do so yourself — this app never deletes anything.",
        ],
        RiskCategory.BLOCKED: [
            "The URL was blocked by safety protections. Do not attempt to visit it.",
            "Report to your security team if this URL arrived unexpectedly.",
        ],
        RiskCategory.UNKNOWN: [
            "Insufficient evidence to score. Exercise caution.",
            "Verify with the publisher through an official channel.",
        ],
    }
    items = actions.get(category, [])
    if items:
        st.subheader("📋 RECOMMENDED NEXT ACTIONS")
        # Render as hex-numbered list using styled HTML (icon + text, not color alone)
        items_html = "".join(
            f'<li style="display:flex;align-items:flex-start;gap:0.7rem;margin-bottom:0.5rem">'
            f'<span style="display:inline-flex;align-items:center;justify-content:center;'
            f'clip-path:polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%);'
            f'width:1.8rem;height:1.8rem;background:linear-gradient(135deg,#44d7e9,#2a8393);'
            f'color:#001a20;font-family:Montserrat,sans-serif;font-weight:700;font-size:0.72rem;'
            f'flex-shrink:0;margin-top:0.1rem">{i + 1}</span>'
            f'<span style="font-family:Raleway,sans-serif;color:#cfe9ee;padding-top:0.15rem">{item}</span>'
            f'</li>'
            for i, item in enumerate(items)
        )
        st.markdown(
            f'<ul style="list-style:none;padding:0;margin:0.5rem 0 1rem 0">{items_html}</ul>',
            unsafe_allow_html=True,
        )


def _load_demo_urls() -> List[dict]:
    demo_path = DATA_DIR / "demo_download_urls.json"
    try:
        with open(str(demo_path), "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return []


def _persist_scan(
    target_label: str,
    target_hash: Optional[str],
    target_type: Optional[str],
    findings: List[Finding],
    is_simulated: bool,
) -> None:
    """Persist scan + findings to the database. Runs silently; never crashes the UI."""
    try:
        from engine.risk_engine import compute_score
        score_result = compute_score(findings)
        scan = Scan(
            module=MODULE_DOWNLOAD_GUARD,
            target_label=target_label,
            target_hash=target_hash,
            target_type=target_type,
            risk_category=score_result.category,
            score=score_result.score,
            is_simulated=is_simulated,
            findings=findings,
        )
        add_scan_with_findings(scan)
    except Exception as exc:
        safe_event("app.persist_scan_error", extra={"error": str(exc)})


# ---------------------------------------------------------------------------
# Page: Download Guard
# ---------------------------------------------------------------------------

def page_download_guard() -> None:
    st.title("🛡️ Download Guard")
    st.caption(
        "Inspect files and URLs before you open them. "
        "This tool is **read-only** and never deletes, moves, executes, "
        "or modifies any file."
    )

    # No-API mode banner
    has_real_api = any(
        p.name not in ("No-API Demo Provider",) and p.is_configured()
        for p in get_available_providers()
    )
    if not has_real_api:
        st.info(
            "**No-API mode:** local analysis + synthetic demonstration data. "
            "Set `VIRUSTOTAL_API_KEY`, `URLHAUS_API_KEY`, or "
            "`GOOGLE_SAFE_BROWSING_API_KEY` environment variables to enable "
            "real reputation lookups."
        )

    tab_url, tab_file, tab_folder, tab_sample = st.tabs(
        ["🔗 Paste URL", "📄 Single File", "📁 Scan Folder", "🧪 Sample Inspector"]
    )

    # ------------------------------------------------------------------
    # Tab 1: URL
    # ------------------------------------------------------------------
    with tab_url:
        _tab_url()

    # ------------------------------------------------------------------
    # Tab 2: Single file upload
    # ------------------------------------------------------------------
    with tab_file:
        _tab_single_file()

    # ------------------------------------------------------------------
    # Tab 3: Folder scan
    # ------------------------------------------------------------------
    with tab_folder:
        _tab_folder()

    # ------------------------------------------------------------------
    # Tab 4: Sample inspector
    # ------------------------------------------------------------------
    with tab_sample:
        _tab_sample()


# ---------------------------------------------------------------------------
# Tab implementations
# ---------------------------------------------------------------------------

def _tab_url() -> None:
    st.subheader("Inspect a download URL")

    st.info(
        "⚠️ **A reputation lookup is not a malware scan.** "
        "It only reports what a database already knows about this URL. "
        "It cannot inspect the file's contents."
    )

    raw_url = st.text_input(
        "Download URL",
        placeholder="https://example.com/file.pdf",
        max_chars=2048,
        key="url_input",
    )

    col1, col2 = st.columns([2, 1])
    run_analysis = col1.button("🔍 Analyse URL", key="btn_analyse_url", type="primary")

    # Demo mode
    demo_urls = _load_demo_urls()
    demo_labels = [d["label"] for d in demo_urls]
    demo_choice = col2.selectbox(
        "Or try a demo entry",
        ["— select —"] + demo_labels,
        key="demo_url_select",
    )

    url_to_analyse: Optional[str] = None
    is_demo = False

    if demo_choice != "— select —":
        demo_entry = next(d for d in demo_urls if d["label"] == demo_choice)
        url_to_analyse = demo_entry["url"]
        is_demo = True
        st.caption(
            f"**Demo:** {demo_entry['description']} — "
            f"*{demo_entry['notes']}*"
        )
    elif run_analysis and raw_url.strip():
        url_to_analyse = raw_url.strip()

    if url_to_analyse and (run_analysis or demo_choice != "— select —"):
        with st.spinner("Analysing URL…"):
            _run_url_analysis(url_to_analyse, is_demo)


def _run_url_analysis(url: str, is_demo: bool) -> None:
    from utils.safe_fetch import FetchResult

    # Defanged display (never render as a link)
    st.markdown("**URL (defanged):**")
    st.code(defang_url(url), language=None)

    # SSRF / validation check runs locally always
    if is_demo:
        # For demo entries that expect a block (SSRF / bad scheme), run local validation
        fetch_result = _demo_fetch_result(url)
    else:
        fetch_result = fetch_url_metadata(url)

    findings = analyze_url(url, fetch_result, is_simulated=is_demo)

    if fetch_result.blocked:
        st.error(f"🚫 **Blocked:** {fetch_result.block_reason}")
    else:
        # Show response metadata
        with st.expander("📡 Response metadata", expanded=True):
            col1, col2 = st.columns(2)
            col1.metric("HTTP Status", str(fetch_result.status_code or "—"))
            col2.metric("Hops in redirect chain", str(len(fetch_result.redirect_chain)))
            if fetch_result.content_type:
                st.text(f"Content-Type: {fetch_result.content_type}")
            if fetch_result.content_length is not None:
                st.text(f"Content-Length: {fetch_result.content_length:,} bytes")
            if fetch_result.content_disposition:
                st.text(f"Content-Disposition: {fetch_result.content_disposition}")
            if fetch_result.redirect_chain:
                st.subheader("Redirect chain")
                for i, hop in enumerate(fetch_result.redirect_chain, 1):
                    flags = []
                    if hop.cross_domain:
                        flags.append("cross-domain")
                    if hop.https_downgrade:
                        flags.append("HTTPS→HTTP downgrade")
                    if hop.ip_literal_redirect:
                        flags.append("IP-literal")
                    flag_str = f" ⚠️ [{', '.join(flags)}]" if flags else ""
                    st.text(f"  Hop {i}: {hop.url} (status {hop.status_code}){flag_str}")

    # Reputation
    _show_reputation_section(url, is_demo, findings)

    # Score
    score_result = compute_score(findings)
    st.subheader("Risk assessment")
    _show_risk_badge(score_result.category)
    st.write("")
    _show_findings(findings)
    _show_score_breakdown(score_result)
    _show_recommended_actions(score_result.category)

    if fetch_result.warnings:
        with st.expander("ℹ️ Informational signals"):
            for w in fetch_result.warnings:
                st.caption(f"• {w}")

    # Persist
    _persist_scan(
        target_label=strip_query_string(url),
        target_hash=None,
        target_type=None,
        findings=findings,
        is_simulated=is_demo,
    )


def _demo_fetch_result(url: str):
    """
    For demo entries, run real local validation (scheme, SSRF) but
    return a synthetic FetchResult for entries that should succeed.
    """
    from utils.safe_fetch import FetchResult, _parse_and_validate_url, _resolve_and_validate
    import ipaddress
    from urllib.parse import urlparse

    parsed = urlparse(url)
    val_url, errors, warnings = _parse_and_validate_url(url)
    if errors:
        result = FetchResult(
            success=False,
            blocked=True,
            block_reason="; ".join(errors),
            error="; ".join(errors),
        )
        result.warnings.extend(warnings)
        return result

    hostname = parsed.hostname or ""
    try:
        addr = ipaddress.ip_address(hostname)
        from utils.safe_fetch import _is_globally_routable
        routable, reason = _is_globally_routable(str(addr))
        if not routable:
            result = FetchResult(
                success=False,
                blocked=True,
                block_reason=f"IP-literal host is non-public: {reason}",
                error=f"IP-literal host is non-public: {reason}",
            )
            result.warnings.extend(warnings)
            return result
    except ValueError:
        pass

    # For .example.test domains, no DNS resolution — return synthetic success
    result = FetchResult(
        success=True,
        blocked=False,
        final_url=defang_url(url),
        status_code=200,
        content_type="application/octet-stream",
    )
    result.warnings.extend(warnings)
    return result


def _show_reputation_section(
    url: str,
    is_demo: bool,
    findings: List[Finding],
) -> None:
    st.subheader("🔎 Reputation lookup (optional)")
    st.caption(
        "A reputation lookup is not a malware scan. "
        "It only reports what a database already knows. "
        "It cannot inspect the file's contents."
    )

    providers = get_available_providers()
    provider_names = [p.name for p in providers]

    chosen_name = st.selectbox(
        "Provider",
        provider_names,
        key=f"rep_provider_{url[:30]}",
    )
    chosen_provider = get_provider_by_name(chosen_name)

    if chosen_provider is None:
        st.warning("Provider not available.")
        return

    is_no_api = isinstance(chosen_provider, NoApiProvider)
    if not is_no_api:
        st.info(
            f"Only this URL will be sent to **{chosen_name}**. "
            "No file content is ever sent."
        )
        send_confirmed = st.checkbox(
            f"I confirm: send this URL to {chosen_name}",
            key=f"rep_confirm_{url[:30]}",
        )
    else:
        send_confirmed = True  # No-API needs no confirmation; no network call

    if st.button("Check reputation", key=f"rep_check_{url[:30]}"):
        if not is_no_api and not send_confirmed:
            st.warning("Please confirm before sending the URL to the provider.")
            return

        with st.spinner(f"Querying {chosen_name}…"):
            try:
                rep_result = chosen_provider.lookup(url)
            except Exception as exc:
                st.error(f"Reputation lookup error: {exc}")
                return

        if rep_result.is_simulated:
            st.warning("⚠️ SYNTHETIC reputation result — demonstration data only.")

        status_icons = {
            "malicious_reported": "🔴",
            "no_data": "⚪",
            "error": "⚠️",
            "rate_limited": "⏳",
            "not_checked": "—",
        }
        icon = status_icons.get(rep_result.status, "❓")
        st.markdown(f"**Status:** {icon} `{rep_result.status}`")
        st.write(rep_result.display_detail)
        st.caption(f"Source: {rep_result.source} | Checked at: {rep_result.checked_at.isoformat()}")

        # Inject REP-MALICIOUS-REPORTED finding if needed
        if rep_result.status == "malicious_reported":
            rep_finding = Finding(
                module=MODULE_DOWNLOAD_GUARD,
                rule_id="REP-MALICIOUS-REPORTED",
                title=RULE_DEFINITIONS["REP-MALICIOUS-REPORTED"].title,
                description=rep_result.display_detail,
                risk_category=RiskCategory.CRITICAL,
                source=rep_result.source,
                is_simulated=rep_result.is_simulated,
                evidence=[Evidence("Provider", rep_result.source)],
            )
            findings.append(rep_finding)
            st.error("⚠️ Reputation provider flagged this URL as malicious.")


# ---------------------------------------------------------------------------
# Tab 2: Single file
# ---------------------------------------------------------------------------

def _tab_single_file() -> None:
    st.subheader("Analyse an individual file")
    st.caption(
        "Upload a file to inspect its bytes in memory. "
        "The file is **never written to disk** by this app."
    )

    uploaded = st.file_uploader(
        "Choose a file",
        key="single_file_uploader",
        accept_multiple_files=False,
        help="Analysed in memory only. Not saved to disk.",
    )

    if uploaded is not None:
        with st.spinner("Analysing…"):
            _run_file_analysis(uploaded.name, uploaded.read(), is_simulated=False)


def _run_file_analysis(
    filename: str,
    file_bytes: bytes,
    is_simulated: bool = False,
    source: str = "uploaded file",
) -> None:
    st.subheader(f"Results for: `{filename}`")

    file_hash = sha256_file(file_bytes)
    detected = detect_type(file_bytes[:256])
    file_size = len(file_bytes)

    col1, col2, col3 = st.columns(3)
    col1.metric("File size", f"{file_size:,} bytes")
    col2.metric("Detected type", detected.name if detected else "Unknown")
    col3.metric("Type group", detected.group if detected else "unknown")

    st.markdown("**SHA-256:**")
    st.code(file_hash, language=None)

    findings = analyze_file(filename, file_bytes, source=source, is_simulated=is_simulated)
    score_result = compute_score(findings)

    st.subheader("Risk assessment")
    _show_risk_badge(score_result.category)
    st.write("")
    _show_findings(findings)
    _show_score_breakdown(score_result)
    _show_recommended_actions(score_result.category)

    _persist_scan(
        target_label=filename,
        target_hash=file_hash,
        target_type=detected.name if detected else None,
        findings=findings,
        is_simulated=is_simulated,
    )


# ---------------------------------------------------------------------------
# Tab 3: Folder scan
# ---------------------------------------------------------------------------

def _tab_folder() -> None:
    st.subheader("Scan a folder (read-only, recursive)")

    st.info(
        "📌 **Path scan only works when this app runs on your own machine.** "
        "For cloud/hosted deployments, use the multi-file uploader below."
    )

    scan_mode = st.radio(
        "Input method",
        ["Local path (own machine only)", "Multi-file upload (cloud-friendly)"],
        key="folder_scan_mode",
        horizontal=True,
    )

    if scan_mode == "Local path (own machine only)":
        _folder_scan_by_path()
    else:
        _folder_scan_by_upload()


def _folder_scan_by_path() -> None:
    folder_path_str = st.text_input(
        "Directory path",
        placeholder="/home/user/downloads",
        key="folder_path_input",
    )

    if not folder_path_str.strip():
        return

    folder_path = Path(folder_path_str.strip()).resolve()

    if not folder_path.exists():
        st.error(f"Path does not exist: `{folder_path}`")
        return
    if not folder_path.is_dir():
        st.error(f"Path is not a directory: `{folder_path}`")
        return

    if st.button("🔍 Start folder scan", key="btn_folder_scan", type="primary"):
        _run_folder_scan(folder_path)


def _run_folder_scan(root: Path) -> None:
    """Walk root, display per-file results, then show summary."""
    st.info(f"Scanning: `{root}` (read-only; no files will be modified)")

    cancel_state = {"cancelled": False}

    def cancel_flag() -> bool:
        return cancel_state["cancelled"]

    progress_bar = st.progress(0, text="Starting scan…")
    cancel_btn = st.button("⛔ Cancel scan", key="btn_cancel_folder_scan")
    if cancel_btn:
        cancel_state["cancelled"] = True

    records: List[FileRecord] = []
    count = 0

    def on_progress(processed: int, _total: int) -> None:
        nonlocal count
        count = processed
        progress_bar.progress(
            min(count / max(count + 1, 1), 1.0),
            text=f"Scanning… {count} files processed",
        )

    for record in walk_folder(root, progress_callback=on_progress, cancel_flag=cancel_flag):
        records.append(record)
        if cancel_state["cancelled"]:
            st.warning("Scan cancelled by user.")
            break

    progress_bar.progress(1.0, text=f"Done — {len(records)} files processed")
    _display_folder_results(records, root)


def _display_folder_results(records: List[FileRecord], root: Path) -> None:
    if not records:
        st.info("No files found.")
        return

    st.subheader(f"Folder scan results — {len(records)} files")

    # Build DataFrame
    rows = []
    for r in records:
        rows.append({
            "Path (relative)": r.rel_path,
            "Size (bytes)": r.size_bytes,
            "Detected Type": r.detected_type or "",
            "SHA-256": r.sha256 or "",
            "Risk Category": r.risk_category or "",
            "Triggered Rules": ", ".join(r.triggered_rules),
            "Skipped Reason": r.skipped_reason or "",
        })

    df = pd.DataFrame(rows)

    # Filter controls
    col1, col2 = st.columns(2)
    risk_filter = col1.multiselect(
        "Filter by risk category",
        options=list(df["Risk Category"].unique()),
        default=list(df["Risk Category"].unique()),
        key="folder_risk_filter",
    )
    rule_filter = col2.text_input(
        "Filter by rule ID (substring)",
        key="folder_rule_filter",
    )

    filtered = df[df["Risk Category"].isin(risk_filter)]
    if rule_filter:
        filtered = filtered[
            filtered["Triggered Rules"].str.contains(rule_filter, case=False, na=False)
        ]

    st.dataframe(filtered, use_container_width=True, hide_index=True)

    # Chart
    risk_counts = df["Risk Category"].value_counts().reset_index()
    risk_counts.columns = ["Risk Category", "Count"]
    if not risk_counts.empty:
        fig = px.bar(
            risk_counts,
            x="Risk Category",
            y="Count",
            title="Files by risk category",
            color="Risk Category",
            color_discrete_map={
                "Informational": "#6c757d",
                "Low": "#28a745",
                "Medium": "#ffc107",
                "High": "#fd7e14",
                "Critical": "#dc3545",
                "Unknown": "#adb5bd",
                "Blocked": "#dc3545",
            },
        )
        st.plotly_chart(fig, use_container_width=True)

    # Export
    col_csv, col_json = st.columns(2)
    col_csv.download_button(
        "⬇️ Export CSV (report only)",
        data=df.to_csv(index=False).encode("utf-8"),
        file_name="download_guard_report.csv",
        mime="text/csv",
    )
    col_json.download_button(
        "⬇️ Export JSON (report only)",
        data=df.to_json(orient="records", indent=2).encode("utf-8"),
        file_name="download_guard_report.json",
        mime="application/json",
    )

    # Skipped files
    skipped = df[df["Skipped Reason"] != ""]
    if not skipped.empty:
        with st.expander(f"⚠️ {len(skipped)} skipped / error items"):
            st.dataframe(
                skipped[["Path (relative)", "Skipped Reason"]],
                use_container_width=True,
                hide_index=True,
            )


def _folder_scan_by_upload() -> None:
    uploaded_files = st.file_uploader(
        "Upload multiple files",
        accept_multiple_files=True,
        key="folder_upload",
        help="Files are analysed in memory only. Not saved to disk.",
    )

    if not uploaded_files:
        return

    st.info(f"{len(uploaded_files)} file(s) uploaded. Running analysis…")
    records: List[FileRecord] = []

    progress = st.progress(0, text="Analysing…")
    for i, uf in enumerate(uploaded_files):
        fbytes = uf.read()
        findings = analyze_file(uf.name, fbytes)
        from engine.risk_engine import compute_score
        sr = compute_score(findings)
        detected = detect_type(fbytes[:256])
        records.append(
            FileRecord(
                rel_path=uf.name,
                size_bytes=len(fbytes),
                detected_type=detected.name if detected else "Unknown",
                sha256=sha256_file(fbytes),
                risk_category=sr.category.value,
                triggered_rules=[f.rule_id for f in findings],
                findings=findings,
            )
        )
        progress.progress((i + 1) / len(uploaded_files), text=f"Analysed {i + 1}/{len(uploaded_files)}")

    _display_folder_results(records, Path("."))


# ---------------------------------------------------------------------------
# Tab 4: Sample Inspector
# ---------------------------------------------------------------------------

def _tab_sample() -> None:
    st.subheader("🧪 Bundled sample inspector")
    st.caption(
        "These are SYNTHETIC inert fixtures created by `scripts/make_samples.py`. "
        "None of them are real malware. They exist to demonstrate the detection rules."
    )

    if not SAMPLES_DIR.exists():
        st.warning(
            "Samples directory not found. "
            "Run `python scripts/make_samples.py` first."
        )
        return

    sample_files = sorted(SAMPLES_DIR.iterdir())
    sample_names = [f.name for f in sample_files if f.is_file()]

    if not sample_names:
        st.info("No sample files found.")
        return

    chosen = st.selectbox("Select a sample file", sample_names, key="sample_select")
    if chosen and st.button("🔍 Inspect sample", key="btn_inspect_sample", type="primary"):
        sample_path = SAMPLES_DIR / chosen
        try:
            file_bytes = sample_path.read_bytes()
        except OSError as exc:
            st.error(f"Could not read sample: {exc}")
            return

        st.warning(
            f"⚠️ **SYNTHETIC** — This is a demonstration fixture, not real malware. "
            f"It was generated by `scripts/make_samples.py` and contains only harmless bytes."
        )
        _run_file_analysis(
            filename=chosen,
            file_bytes=file_bytes,
            is_simulated=True,
            source="bundled sample",
        )


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

def _sidebar() -> None:
    with st.sidebar:
        # Shield SVG logo in sidebar
        st.markdown(
            '<div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.5rem">'
            '<svg width="32" height="32" viewBox="0 0 38 38" fill="none">'
            '<path d="M19 2L4 8v12c0 8.3 6.4 16 15 18 8.6-2 15-9.7 15-18V8L19 2z"'
            ' fill="url(#sb-grad)"/>'
            '<path d="M13 19l4 4 8-8" stroke="#001a20" stroke-width="2.5"'
            ' stroke-linecap="round" stroke-linejoin="round"/>'
            '<defs><linearGradient id="sb-grad" x1="4" y1="2" x2="34" y2="36">'
            '<stop stop-color="#44d7e9"/><stop offset="1" stop-color="#2a8393"/>'
            '</linearGradient></defs></svg>'
            f'<span style="font-family:Anton,Impact,sans-serif;font-size:0.95rem;'
            f'letter-spacing:0.1em;color:#ffffff">{APP_NAME}</span>'
            '</div>',
            unsafe_allow_html=True,
        )
        st.caption(f"v{APP_VERSION}")
        st.divider()
        st.subheader("Navigation")
        # Radio widget to switch between modules; updates session_state
        page_choice = st.radio(
            "Go to module",
            options=["Download Guard", "Fraud Call Detector"],
            index=0 if st.session_state.get("active_page", "Download Guard") == "Download Guard" else 1,
            key="nav_radio",
            label_visibility="collapsed",
        )
        st.session_state["active_page"] = page_choice

        st.divider()
        st.subheader("About")
        st.caption(
            "CyberShield 360 is a defensive inspection tool. "
            "It is **read-only** and never modifies, executes, or downloads any file."
        )
        # Limitations notice — always visible, prominently rendered
        st.info(
            "**Limitations:** Rules are pattern-based heuristics. False positives "
            "are possible. Transcripts capture words, not intent. Reputation lookups "
            "are not malware scans. This tool cannot prove fraud, safety, or account "
            "compromise."
        )



# ---------------------------------------------------------------------------
# Page: Fraud Call Detector (Module 01)
# ---------------------------------------------------------------------------

def page_fraud_call_detector() -> None:
    """Streamlit page for the Fraud Call Detector."""

    # ── Persistent disclaimer — always at the top, never hidden ─────────────
    st.error(
        "⚠️ **This tool analyses text for patterns only. "
        "It is NOT proof of fraud.** False positives are possible. "
        "This tool never identifies a caller by voice or phone number. "
        "It never accesses call logs, contacts, or phone hardware. "
        "Full transcripts are NOT retained — only short matched-phrase snippets "
        "and rule IDs are stored.",
        icon=None,
    )

    # ── Audio notice ──────────────────────────────────────────────────────────
    st.info(
        "🔇 **Audio transcription is not available in this configuration.** "
        "Paste a text transcript below. "
        "If a transcription provider is configured in future, an upload option "
        "will appear here.",
    )

    tab_paste, tab_demo = st.tabs(["📝 Paste Transcript", "🧪 Demo (SYNTHETIC)"])

    # ── Tab 1: Paste transcript ───────────────────────────────────────────────
    with tab_paste:
        st.subheader("Paste a call transcript")
        st.caption(
            "Paste a verbatim transcript of the call below. "
            "The app analyses the text locally — no content is sent externally. "
            "Only short matched-phrase snippets are stored, not the full transcript."
        )

        transcript_input = st.text_area(
            "Call transcript",
            height=250,
            max_chars=50_000,
            placeholder=(
                "Example:\n"
                "Caller: Hello, I'm calling from your bank's fraud prevention team...\n"
                "Target: Oh, what's happened?\n"
                "Caller: We've detected suspicious activity. Please read me the OTP..."
            ),
            key="call_transcript_input",
        )

        if st.button("🔍 Analyse transcript", key="btn_analyse_transcript", type="primary"):
            if not transcript_input.strip():
                st.warning("Please paste a transcript before analysing.")
            else:
                with st.spinner("Analysing…"):
                    _run_call_analysis(transcript_input, is_simulated=False)

    # ── Tab 2: Synthetic demo ─────────────────────────────────────────────────
    with tab_demo:
        st.warning(
            "⚠️ **SYNTHETIC demonstration data.** "
            "This is a fictional scam-call transcript for demonstration only. "
            "No real call, person, or organisation is represented."
        )
        demo_path = DATA_DIR / "demo_call_transcript.json"
        try:
            import json as _json
            demo_data = _json.loads(demo_path.read_text(encoding="utf-8"))
            demo_transcript = demo_data["transcript"]
        except Exception as exc:
            st.error(f"Could not load demo transcript: {exc}")
            return

        st.subheader(demo_data.get("label", "Demo transcript"))
        st.caption(demo_data.get("description", ""))

        with st.expander("View raw transcript", expanded=False):
            st.text(demo_transcript[:2000] + ("…" if len(demo_transcript) > 2000 else ""))

        if st.button("🔍 Run demo analysis", key="btn_demo_analysis", type="primary"):
            with st.spinner("Analysing demo transcript…"):
                _run_call_analysis(demo_transcript, is_simulated=True)


def _run_call_analysis(transcript: str, is_simulated: bool) -> None:
    """Run analysis and render results."""
    from modules.fraud_call_detector import analyse_transcript as _analyse
    result = _analyse(transcript, is_simulated=is_simulated)

    # ── Truncation notice ─────────────────────────────────────────────────────
    if result.was_truncated:
        st.warning(
            f"⚠️ Transcript was truncated to {result.input_length:,} characters "
            f"for analysis."
        )

    # ── Score ─────────────────────────────────────────────────────────────────
    score_result = compute_score(result.findings)
    st.subheader("Risk assessment")

    if not result.findings:
        st.success(
            "No indicators detected. "
            "This does NOT mean the call is safe — some scam tactics may not be "
            "captured by text patterns alone."
        )
    else:
        _show_risk_badge(score_result.category)
        st.write("")

        # Simulated banner
        if is_simulated:
            st.warning("⚠️ SYNTHETIC — demonstration data only. Not a real call.")

        # ── Findings ──────────────────────────────────────────────────────────
        st.subheader(f"🔎 Indicators found: {len(result.findings)}")
        _show_call_findings(result.findings)
        _show_score_breakdown(score_result)

    # ── Extracted URLs ────────────────────────────────────────────────────────
    if result.extracted_urls:
        st.subheader("🔗 URLs found in transcript")
        st.caption(
            "These URLs were extracted from the transcript as potential indicators. "
            "Do NOT open them without first checking in Download Guard."
        )
        for url in result.extracted_urls:
            col1, col2 = st.columns([4, 1])
            col1.code(url, language=None)
            col2.caption("↑ copy only — do not click")

    # ── Safety actions ────────────────────────────────────────────────────────
    st.subheader("🛡️ SAFETY ACTIONS")
    for i, action in enumerate(result.safety_actions, 1):
        st.markdown(
            f'<div style="display:flex;align-items:flex-start;gap:0.7rem;'
            f'margin-bottom:0.5rem">'
            f'<span style="display:inline-flex;align-items:center;justify-content:center;'
            f'clip-path:polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%);'
            f'width:1.8rem;height:1.8rem;background:linear-gradient(135deg,#44d7e9,#2a8393);'
            f'color:#001a20;font-family:Montserrat,sans-serif;font-weight:700;font-size:0.72rem;'
            f'flex-shrink:0;margin-top:0.1rem">{i}</span>'
            f'<span style="font-family:Raleway,sans-serif;color:#cfe9ee;padding-top:0.15rem">'
            f'{action}</span></div>',
            unsafe_allow_html=True,
        )

    # ── Mandatory disclaimer ──────────────────────────────────────────────────
    st.divider()
    st.warning(f"⚠️ {result.disclaimer}")

    # ── Persist (matched snippets + rule IDs only; never full transcript) ─────
    if result.findings:
        try:
            scan = Scan(
                module=MODULE_FRAUD_CALL_DETECTOR,
                target_label="[call transcript]",  # never store transcript content
                target_hash=None,
                target_type="transcript",
                risk_category=score_result.category,
                score=score_result.score,
                is_simulated=is_simulated,
                findings=result.findings,
            )
            add_scan_with_findings(scan)
        except Exception as exc:
            safe_event("app.persist_call_scan_error", extra={"error": str(exc)})


def _show_call_findings(findings: List[Finding]) -> None:
    """Render call-detector findings with phrase highlights."""
    for f in findings:
        color = _risk_color(f.risk_category)
        rule_def = CALL_RULE_DEFINITIONS.get(f.rule_id)
        expanded = f.risk_category in (RiskCategory.HIGH, RiskCategory.CRITICAL)

        with st.expander(
            f"{risk_label(f.risk_category)} — {f.title}  [{f.rule_id}]",
            expanded=expanded,
        ):
            st.markdown(
                f'<div style="border-left:4px solid {color};'
                f'padding:0.6rem 0.8rem;'
                f'background:rgba(0,0,0,0.15);border-radius:0 6px 6px 0;'
                f'margin-bottom:0.5rem">'
                f'<span style="font-family:Raleway,sans-serif;color:#cfe9ee;font-size:0.9rem">'
                f'{f.description}</span></div>',
                unsafe_allow_html=True,
            )

            # Show matched phrase snippets (already HTML-escaped in the module)
            phrase_items = [e for e in f.evidence if e.label.startswith("Matched phrase")]
            if phrase_items:
                st.caption("**Matched phrases (context snippets):**")
                for ev in phrase_items:
                    # Display with highlighting markers → / (already escaped)
                    display_val = ev.value.replace("&gt;&gt;&gt;", "▶").replace("&lt;&lt;&lt;", "◀")
                    st.code(display_val, language=None)

            # Show explanation evidence items
            expl_items = [e for e in f.evidence if e.label == "Explanation"]
            for ev in expl_items:
                st.info(f"💡 {ev.value}")

            if f.confidence_note:
                st.caption(f"⚠️ Confidence: {f.confidence_note}")

            if rule_def:
                with st.expander("ℹ️ Rule details", expanded=False):
                    st.caption(
                        f"**Rule ID:** `{f.rule_id}` | "
                        f"**Weight:** {rule_def.base_weight} | "
                        f"**Minimum category:** {rule_def.min_category.value}"
                    )

            if f.is_simulated:
                st.warning("⚠️ SYNTHETIC result — demonstration data only.")


# ---------------------------------------------------------------------------
# Shared page-header and footer-strip helpers
# ---------------------------------------------------------------------------

def _page_header_band(icon: str, title: str, subtitle: str) -> None:
    """Render the gradient page-header band (angled edge, hex icon, title)."""
    st.markdown(
        '<div style="'
        'background:linear-gradient(135deg,#44d7e9 0%,#32b0c7 40%,#2a8393 100%);'
        'clip-path:polygon(0 0,100% 0,100% 75%,97% 100%,0 100%);'
        'padding:1.5rem 1.5rem 2rem;margin-bottom:1.5rem;display:flex;'
        'align-items:flex-start;gap:1rem">'
        f'<div style="width:48px;height:48px;flex-shrink:0;'
        f'clip-path:polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%);'
        f'background:rgba(0,0,0,0.2);display:flex;align-items:center;'
        f'justify-content:center;font-size:1.4rem">{icon}</div>'
        '<div>'
        f'<div style="font-family:Anton,Impact,sans-serif;font-size:clamp(1.3rem,3vw,2rem);'
        f'letter-spacing:0.08em;text-transform:uppercase;color:#001a20;line-height:1.05">'
        f'{title}</div>'
        f'<div style="font-family:Raleway,system-ui,sans-serif;font-size:0.9rem;'
        f'color:rgba(0,20,28,0.75);margin-top:0.3rem">{subtitle}</div>'
        '</div></div>',
        unsafe_allow_html=True,
    )


def _footer_strip(module_number: str) -> None:
    """Render the fixed bottom footer strip with module tab."""
    st.markdown(
        '<div style="position:fixed;bottom:0;left:0;right:0;z-index:99;'
        'background:#040612;border-top:1px solid rgba(68,215,233,0.25);'
        'display:flex;align-items:stretch;min-height:44px">'
        '<a href="#" style="display:flex;align-items:center;gap:0.5rem;'
        'padding:0 1.5rem 0 1rem;'
        'background:linear-gradient(90deg,#2a8393,#32b0c7);'
        'color:#001a20;font-family:Montserrat,sans-serif;font-size:0.75rem;'
        'font-weight:700;letter-spacing:0.06em;text-transform:uppercase;'
        'text-decoration:none;'
        'clip-path:polygon(0 0,calc(100% - 10px) 0,100% 50%,calc(100% - 10px) 100%,0 100%);'
        'padding-right:1.8rem">← DASHBOARD</a>'
        '<div style="flex:1"></div>'
        '<div style="display:flex;align-items:center;'
        'padding:0 1.5rem 0 1.8rem;'
        'background:linear-gradient(270deg,#2a8393,#32b0c7);'
        'color:#001a20;font-family:Anton,Impact,sans-serif;font-size:0.72rem;'
        'letter-spacing:0.12em;text-transform:uppercase;'
        'clip-path:polygon(10px 0,100% 0,100% 100%,10px 100%,0 50%)">'
        f'MODULE {module_number}</div>'
        '</div>',
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    _inject_theme()

    # Default page stored in session state so reload remembers position
    if "active_page" not in st.session_state:
        st.session_state["active_page"] = "Download Guard"

    _sidebar()

    page = st.session_state["active_page"]

    if page == "Fraud Call Detector":
        _page_header_band(
            icon="📞",
            title="FRAUD CALL DETECTOR",
            subtitle=(
                "Analyse call transcripts for social-engineering indicators — "
                "pattern matching only, never proof of fraud"
            ),
        )
        page_fraud_call_detector()
        _footer_strip("01")
    else:
        # Default: Download Guard
        _page_header_band(
            icon="🛡️",
            title="DOWNLOAD GUARD",
            subtitle="Inspect files and URLs before you open them — read-only, never executes anything",
        )
        page_download_guard()
        _footer_strip("02")


if __name__ == "__main__":
    main()
