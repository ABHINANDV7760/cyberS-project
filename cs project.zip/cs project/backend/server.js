/**
 * Website Security Inspector — Express backend
 *
 * Routes:
 *   POST /api/posture-check   — run Tier 0 (+Tier 1 if authorized)
 *   GET  /api/health          — health check
 *
 * Environment variables:
 *   PORT                         (default 3000)
 *   GOOGLE_SAFE_BROWSING_API_KEY (optional)
 *   VIRUSTOTAL_API_KEY           (optional)
 *   REPUTATION_PROVIDERS         (comma-separated list, optional)
 *   ALLOWED_ORIGINS              (CORS, default localhost:3000)
 */

'use strict';

require('dotenv').config();

const express    = require('express');
const helmet     = require('helmet');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const { runPostureCheck }            = require('./checks/posture');
const { validateUrl }                = require('./safe-fetch');
const { scanRateLimitMiddleware }    = require('./checks/rate-limit');

const app  = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// ─── Security middleware ──────────────────────────────────────────────────────

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:    ["'self'"],
      scriptSrc:     ["'self'", "'wasm-unsafe-eval'"],
      styleSrc:      ["'self'", "'unsafe-inline'"],
      imgSrc:        ["'self'", 'data:'],
      connectSrc:    ["'self'"],
      fontSrc:       ["'self'"],
      objectSrc:     ["'none'"],
      frameSrc:      ["'none'"],
      baseUri:       ["'self'"],
      formAction:    ["'self'"],
    },
  },
}));

const allowedOrigins = (process.env.ALLOWED_ORIGINS || 'http://localhost:3000').split(',').map(s => s.trim());
app.use(cors({ origin: allowedOrigins }));

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// Trust proxy for accurate IP (if behind a reverse proxy)
app.set('trust proxy', 1);

// Global rate limit (100 req/15 min per IP)
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max:      100,
  standardHeaders: true,
  legacyHeaders:   false,
  message: { error: 'Too many requests; please try again later.' },
}));

// ─── Static files (frontend) ──────────────────────────────────────────────────

app.use(express.static(path.join(__dirname, '../frontend')));

// ─── API routes ───────────────────────────────────────────────────────────────

/**
 * POST /api/posture-check
 *
 * Body:
 *   {
 *     target:      string,   // URL to check
 *     authorized:  boolean,  // authorization confirmation
 *     dkimSelector?: string  // optional DKIM selector
 *   }
 */
app.post('/api/posture-check', scanRateLimitMiddleware, async (req, res) => {
  const { target, authorized, dkimSelector } = req.body;

  if (!target || typeof target !== 'string') {
    return res.status(400).json({ error: 'target URL is required' });
  }

  // Server-side: Tier 1 calls require authorization = true
  // (defence in depth — gate is also enforced in posture.js)
  if (authorized !== true && authorized !== false) {
    return res.status(400).json({ error: 'authorized must be a boolean' });
  }

  // Validate URL before even starting
  const urlCheck = validateUrl(target);
  if (!urlCheck.ok) {
    return res.status(400).json({ error: urlCheck.reason });
  }

  const clientIp = req.ip || req.socket?.remoteAddress || 'unknown';

  try {
    const report = await runPostureCheck(target, authorized === true, dkimSelector || null, clientIp);
    // Never log full URLs with query strings server-side
    console.log(`[posture-check] host=${urlCheck.url.hostname} authorized=${authorized} ip=[redacted]`);
    return res.json(report);
  } catch (e) {
    console.error(`[posture-check] error: ${e.message}`);
    return res.status(500).json({ error: 'Internal error; check server logs.' });
  }
});

/**
 * GET /api/health
 */
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', noApiMode: !process.env.GOOGLE_SAFE_BROWSING_API_KEY && !process.env.VIRUSTOTAL_API_KEY });
});

// ─── 404 / SPA fallback ───────────────────────────────────────────────────────

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ─── Start ────────────────────────────────────────────────────────────────────

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Website Security Inspector running on http://localhost:${PORT}`);
    if (!process.env.GOOGLE_SAFE_BROWSING_API_KEY && !process.env.VIRUSTOTAL_API_KEY) {
      console.log('  No-API mode: reputation checks use SYNTHETIC demo data from fixtures/');
    }
  });
}

module.exports = app; // for tests
