/**
 * DNS checker — performs public DNS lookups for the given hostname.
 * All lookups are passive (Tier 0) and do NOT contact the target site.
 */

'use strict';

const dns = require('dns').promises;

/**
 * Lookup all relevant DNS records for a hostname.
 * Returns a structured result object.
 */
async function checkDns(hostname) {
  const results = {};

  const lookup = async (type, fn) => {
    try {
      results[type] = { records: await fn(), error: null };
    } catch (e) {
      // Distinguish "no records" (ENODATA/ENOTFOUND) from other errors
      const noRecord = e.code === 'ENODATA' || e.code === 'ENOTFOUND';
      results[type] = { records: [], error: noRecord ? null : e.message, absent: noRecord };
    }
  };

  // Run all lookups in parallel
  await Promise.all([
    lookup('A',    () => dns.resolve4(hostname)),
    lookup('AAAA', () => dns.resolve6(hostname)),
    lookup('NS',   () => dns.resolveNs(hostname)),
    lookup('MX',   () => dns.resolveMx(hostname)),
    lookup('TXT',  () => dns.resolveTxt(hostname).then(r => r.map(a => a.join('')))),
    lookup('CAA',  () => dns.resolveCaa(hostname)),
  ]);

  // DNSSEC: try to detect via NS + SOA; we flag "possibly present" if SOA resolves
  let dnssecPresent = null;
  try {
    await dns.resolveSoa(hostname);
    dnssecPresent = 'SOA present (DNSSEC status requires DNSSEC-aware resolver; not verified)';
  } catch {
    dnssecPresent = 'Could not determine (SOA lookup failed)';
  }
  results.DNSSEC = { note: dnssecPresent };

  return results;
}

/**
 * Analyse email security records (SPF, DMARC, MTA-STS, TLS-RPT, BIMI, DKIM).
 */
async function checkEmailSecurity(hostname, dkimSelector) {
  const txt = await safeResolveTxt(hostname);
  const dmarcHost = `_dmarc.${hostname}`;
  const mtaStsHost = `_mta-sts.${hostname}`;
  const tlsRptHost = `_smtp._tls.${hostname}`;
  const bimiHost   = `default._bimi.${hostname}`;

  const [dmarcTxt, mtaStsTxt, tlsRptTxt, bimiTxt] = await Promise.all([
    safeResolveTxt(dmarcHost),
    safeResolveTxt(mtaStsHost),
    safeResolveTxt(tlsRptHost),
    safeResolveTxt(bimiHost),
  ]);

  const spf  = parseSpf(txt);
  const dmarc = parseDmarc(dmarcTxt);
  const mtaSts = { present: mtaStsTxt.length > 0, records: mtaStsTxt };
  const tlsRpt = { present: tlsRptTxt.length > 0, records: tlsRptTxt };
  const bimi   = { present: bimiTxt.length > 0, records: bimiTxt };

  let dkim = null;
  if (dkimSelector) {
    const dkimHost = `${dkimSelector}._domainkey.${hostname}`;
    const dkimTxt  = await safeResolveTxt(dkimHost);
    dkim = { selector: dkimSelector, present: dkimTxt.length > 0, records: dkimTxt };
  }

  return { spf, dmarc, mtaSts, tlsRpt, bimi, dkim };
}

async function safeResolveTxt(host) {
  try {
    const recs = await dns.resolveTxt(host);
    return recs.map(a => a.join(''));
  } catch {
    return [];
  }
}

// ─── SPF parser ───────────────────────────────────────────────────────────────

function parseSpf(txtRecords) {
  const spfRecords = txtRecords.filter(r => r.startsWith('v=spf1'));

  if (spfRecords.length === 0) {
    return {
      present:  false,
      findings: [{ issue: 'No SPF record found', severity: 'High' }],
    };
  }

  const findings = [];

  if (spfRecords.length > 1) {
    findings.push({ issue: 'Multiple SPF records found (RFC 7208 §3.2 violation)', severity: 'High' });
  }

  const record = spfRecords[0];
  const parts  = record.split(/\s+/);

  // Check for permissive all qualifiers
  if (parts.includes('+all') || parts.includes('all')) {
    findings.push({ issue: 'SPF has "+all" — permits any sender; effectively no SPF protection', severity: 'Critical' });
  } else if (parts.includes('?all')) {
    findings.push({ issue: 'SPF has "?all" (neutral) — provides minimal protection', severity: 'Medium' });
  } else if (!parts.includes('-all') && !parts.includes('~all')) {
    findings.push({ issue: 'SPF has no "all" mechanism — behaviour undefined', severity: 'Medium' });
  }

  // Count DNS-lookup mechanisms (a, mx, ptr, include, exists, redirect)
  const lookupMechanisms = parts.filter(p =>
    /^[+\-~?]?(a|mx|ptr|include:|exists:|redirect=)/i.test(p)
  );
  if (lookupMechanisms.length > 10) {
    findings.push({
      issue: `SPF record causes >10 DNS lookups (${lookupMechanisms.length} mechanisms) — exceeds RFC limit`,
      severity: 'Medium',
    });
  }

  if (findings.length === 0) {
    findings.push({ issue: 'SPF record looks reasonable', severity: 'Info' });
  }

  return { present: true, record, findings };
}

// ─── DMARC parser ─────────────────────────────────────────────────────────────

function parseDmarc(txtRecords) {
  const dmarcRecords = txtRecords.filter(r => r.startsWith('v=DMARC1'));

  if (dmarcRecords.length === 0) {
    return {
      present:  false,
      findings: [{ issue: 'No DMARC record found', severity: 'High' }],
    };
  }

  const record   = dmarcRecords[0];
  const findings = [];
  const tags     = parseTags(record);

  const policy = tags.p || '';
  if (policy === 'none') {
    findings.push({ issue: 'DMARC policy is "none" — no enforcement; monitoring only', severity: 'Medium' });
  } else if (policy === 'quarantine') {
    findings.push({ issue: 'DMARC policy is "quarantine"', severity: 'Low' });
  } else if (policy === 'reject') {
    findings.push({ issue: 'DMARC policy is "reject" — strongest enforcement', severity: 'Info' });
  } else {
    findings.push({ issue: `DMARC policy is missing or unrecognised ("${policy}")`, severity: 'High' });
  }

  if (!tags.rua) {
    findings.push({ issue: 'DMARC has no rua (aggregate report) destination', severity: 'Low' });
  }

  const pct = parseInt(tags.pct || '100', 10);
  if (pct < 100) {
    findings.push({ issue: `DMARC pct=${pct} — policy applies to only ${pct}% of mail`, severity: 'Low' });
  }

  if (tags.sp && tags.sp !== policy) {
    findings.push({ issue: `DMARC subdomain policy (sp=${tags.sp}) differs from p=${policy}`, severity: 'Info' });
  }

  return { present: true, record, tags, findings };
}

function parseTags(record) {
  const result = {};
  for (const part of record.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k) result[k.trim()] = v.join('=').trim();
  }
  return result;
}

module.exports = { checkDns, checkEmailSecurity };
