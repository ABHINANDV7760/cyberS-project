/**
 * TLS checker — performs a single TLS handshake to the validated, pinned IP.
 * Tier 1 (requires authorization confirmation).
 *
 * Captures: negotiated protocol, cipher, certificate details, chain validity,
 * hostname match, expiry, and self-signed detection.
 * Does NOT send application-layer data beyond the handshake.
 */

'use strict';

const tls   = require('tls');
const forge = require('node-forge');

const CONNECT_TIMEOUT = 3_000;
const TOTAL_TIMEOUT   = 8_000;

/**
 * Perform a TLS handshake to the given IP:port with the specified hostname as SNI.
 *
 * @param {string} hostname  - original hostname (for SNI and cert verification)
 * @param {string} ip        - pre-validated, pinned IP address
 * @param {number} [port=443]
 * @returns {Promise<TlsResult>}
 */
async function checkTls(hostname, ip, port = 443) {
  return new Promise((resolve, reject) => {
    const startMs = Date.now();
    let settled   = false;

    const totalTimer = setTimeout(() => {
      if (!settled) {
        settled = true;
        socket.destroy();
        reject(new Error('TLS check total timeout'));
      }
    }, TOTAL_TIMEOUT);

    const socket = tls.connect(
      {
        host:                ip,       // connect to pinned IP
        port,
        servername:          hostname, // SNI
        rejectUnauthorized:  false,    // capture errors manually
        checkServerIdentity: () => undefined,
        timeout:             CONNECT_TIMEOUT,
      },
      () => {
        clearTimeout(totalTimer);
        if (settled) return;
        settled = true;

        const cert    = socket.getPeerCertificate(true); // full chain
        const proto   = socket.getProtocol();
        const cipher  = socket.getCipher();
        const timingMs = Date.now() - startMs;

        socket.destroy();
        resolve(parseCertResult(cert, proto, cipher, hostname, timingMs));
      }
    );

    socket.on('error', (err) => {
      clearTimeout(totalTimer);
      if (!settled) {
        settled = true;
        reject(err);
      }
    });

    socket.on('timeout', () => {
      socket.destroy(new Error('TLS connect timeout'));
    });
  });
}

// ─── Certificate parsing ──────────────────────────────────────────────────────

function parseCertResult(cert, proto, cipher, hostname, timingMs) {
  const findings = [];

  if (!cert || !cert.subject) {
    return {
      valid: false,
      findings: [{ issue: 'No certificate returned', severity: 'Critical' }],
      timingMs,
    };
  }

  const now       = new Date();
  const notBefore = new Date(cert.valid_from);
  const notAfter  = new Date(cert.valid_to);
  const daysLeft  = Math.floor((notAfter - now) / 86_400_000);
  const expired   = now > notAfter;
  const notYetValid = now < notBefore;

  // Protocol version
  const weakProtocol = ['TLSv1', 'TLSv1.1', 'SSLv3', 'SSLv2'].includes(proto);
  if (weakProtocol) {
    findings.push({ issue: `Weak TLS version in use: ${proto}`, severity: 'High' });
  }

  // Cipher
  const cipherName = cipher ? cipher.name : 'unknown';
  if (/RC4|DES|3DES|NULL|EXPORT|anon/i.test(cipherName)) {
    findings.push({ issue: `Weak cipher suite: ${cipherName}`, severity: 'High' });
  }

  // Expiry
  if (expired) {
    findings.push({ issue: `Certificate expired on ${cert.valid_to}`, severity: 'Critical' });
  } else if (notYetValid) {
    findings.push({ issue: `Certificate not yet valid (starts ${cert.valid_from})`, severity: 'High' });
  } else if (daysLeft < 14) {
    findings.push({ issue: `Certificate expires in ${daysLeft} days`, severity: 'High' });
  } else if (daysLeft < 30) {
    findings.push({ issue: `Certificate expires in ${daysLeft} days`, severity: 'Medium' });
  }

  // Self-signed (issuer === subject at leaf, no chain)
  const subjectCN = cert.subject?.CN || '';
  const issuerCN  = cert.issuer?.CN  || '';
  const selfSigned = subjectCN === issuerCN && !cert.issuerCertificate?.subject?.CN;
  if (selfSigned) {
    findings.push({ issue: 'Certificate appears self-signed', severity: 'High' });
  }

  // Hostname match (check SAN first, then CN)
  const sanMatch = checkSanMatch(cert, hostname);
  if (!sanMatch.matched) {
    findings.push({ issue: `Certificate hostname mismatch: ${sanMatch.reason}`, severity: 'Critical' });
  }

  if (findings.length === 0) {
    findings.push({ issue: 'TLS certificate looks valid', severity: 'Info' });
  }

  // Build SAN list for display
  const sans = [];
  if (cert.subjectaltname) {
    const matches = cert.subjectaltname.match(/DNS:[^,]+/g) || [];
    sans.push(...matches.map(m => m.replace('DNS:', '')));
  }

  return {
    valid:       !expired && !selfSigned && sanMatch.matched,
    protocol:    proto,
    cipher:      cipherName,
    subject:     cert.subject,
    issuer:      cert.issuer,
    validFrom:   cert.valid_from,
    validTo:     cert.valid_to,
    daysLeft,
    expired,
    selfSigned,
    hostnameMatch: sanMatch.matched,
    sans,
    serialNumber: cert.serialNumber,
    fingerprint:  cert.fingerprint,
    findings,
    timingMs,
  };
}

function checkSanMatch(cert, hostname) {
  const sans = [];

  if (cert.subjectaltname) {
    const matches = cert.subjectaltname.match(/DNS:[^,]+/g) || [];
    for (const m of matches) {
      sans.push(m.replace('DNS:', '').trim());
    }
  }

  // Also include CN as a fallback (legacy)
  const cn = cert.subject?.CN || '';

  const allNames = sans.length > 0 ? sans : (cn ? [cn] : []);

  for (const name of allNames) {
    if (matchesHostname(name, hostname)) {
      return { matched: true, matchedName: name };
    }
  }

  return {
    matched: false,
    reason: `Hostname "${hostname}" not in certificate names: ${allNames.join(', ') || '(none)'}`,
  };
}

function matchesHostname(certName, hostname) {
  const cn = certName.toLowerCase();
  const hn = hostname.toLowerCase();
  if (cn === hn) return true;
  if (cn.startsWith('*.')) {
    const suffix = cn.slice(2);
    const hostParts = hn.split('.');
    // Wildcard covers exactly one label
    if (hostParts.length >= 2 && hostParts.slice(1).join('.') === suffix) return true;
  }
  return false;
}

module.exports = { checkTls };
