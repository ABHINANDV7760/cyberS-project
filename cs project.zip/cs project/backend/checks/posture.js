/**
 * Posture check orchestrator — coordinates all Tier 0 and Tier 1 checks.
 *
 * Tier 0 (passive, no confirmation needed):
 *   - URL/hostname validation
 *   - Public DNS records
 *   - Email security records (SPF, DMARC, MTA-STS, TLS-RPT, BIMI)
 *   - Domain reputation (optional, no target contact)
 *
 * Tier 1 (active, requires authorization confirmation):
 *   - TLS certificate check (one handshake)
 *   - HTTP security headers (one HTTPS GET)
 *   - HTTPS redirect check (one HTTP HEAD)
 *   - /.well-known/security.txt fetch
 *   - /robots.txt fetch
 *
 * Request budget: max 6 requests per Tier 1 run (documented).
 */

'use strict';

const { validateUrl, resolveHostname, safeFetch, SafeFetchError } = require('../safe-fetch');
const { checkDns, checkEmailSecurity } = require('./dns');
const { checkTls }     = require('./tls');
const { checkHeaders } = require('./headers');
const { checkReputation } = require('./reputation');
const { recordScanStart, recordScanEnd } = require('./rate-limit');

const REQUEST_BUDGET = 6; // Tier 1 max requests

/**
 * Run the full posture check for a URL.
 *
 * @param {string}  rawUrl
 * @param {boolean} authorized        - true if user has confirmed authorization (Tier 1)
 * @param {string}  [dkimSelector]    - optional DKIM selector
 * @param {string}  clientIp          - for rate limiting
 * @returns {Promise<PostureReport>}
 */
async function runPostureCheck(rawUrl, authorized, dkimSelector, clientIp) {
  const reportTimestamp = new Date().toISOString();
  const checks          = [];
  const skipped         = [];
  let requestsUsed      = 0;

  // ── Step 1: URL validation (Tier 0) ─────────────────────────────────────────
  const urlValidation = validateUrl(rawUrl);
  if (!urlValidation.ok) {
    return {
      ok:              false,
      error:           urlValidation.reason,
      reportTimestamp,
    };
  }
  const targetUrl  = urlValidation.url;
  const hostname   = targetUrl.hostname;

  checks.push({
    id:         'url-validation',
    tier:       0,
    name:       'URL and hostname validation',
    severity:   'Info',
    confidence: 'High',
    issue:      `URL parsed successfully: ${hostname}`,
    evidence:   targetUrl.href,
    timestamp:  new Date().toISOString(),
  });

  // ── Step 2: DNS records (Tier 0) ─────────────────────────────────────────────
  let dnsRecords = null;
  try {
    dnsRecords = await checkDns(hostname);
    checks.push({
      id:         'dns-records',
      tier:       0,
      name:       'Public DNS records',
      severity:   'Info',
      confidence: 'High',
      issue:      'DNS records retrieved',
      evidence:   sanitizeDnsRecords(dnsRecords),
      timestamp:  new Date().toISOString(),
    });
  } catch (e) {
    skipped.push({ check: 'DNS records', reason: e.message, tier: 0 });
  }

  // ── Step 3: Email security records (Tier 0) ──────────────────────────────────
  let emailSecurity = null;
  try {
    emailSecurity = await checkEmailSecurity(hostname, dkimSelector);
    const allFindings = [
      ...(emailSecurity.spf?.findings   || []),
      ...(emailSecurity.dmarc?.findings || []),
    ];
    for (const f of allFindings) {
      checks.push({
        id:         `email-security-${f.issue.slice(0, 30).replace(/\s+/g, '-').toLowerCase()}`,
        tier:       0,
        name:       'Email security records',
        severity:   f.severity,
        confidence: 'High',
        issue:      f.issue,
        evidence:   emailSecurity.spf?.record || emailSecurity.dmarc?.record || null,
        remediation: f.remediation,
        timestamp:  new Date().toISOString(),
      });
    }
    // MTA-STS / TLS-RPT
    if (!emailSecurity.mtaSts?.present) {
      checks.push({
        id: 'mta-sts-missing', tier: 0, name: 'MTA-STS',
        severity: 'Low', confidence: 'Medium',
        issue: 'MTA-STS policy not found (_mta-sts TXT record absent)',
        remediation: 'Consider publishing an MTA-STS policy to enforce TLS for inbound mail.',
        timestamp: new Date().toISOString(),
      });
    }
  } catch (e) {
    skipped.push({ check: 'Email security records', reason: e.message, tier: 0 });
  }

  // ── Step 4: Domain reputation (Tier 0, optional) ──────────────────────────────
  let reputation = null;
  try {
    reputation = await checkReputation(hostname);
    for (const r of reputation.results) {
      checks.push({
        id:         `reputation-${(r.provider || 'unknown').replace(/\s+/g, '-').toLowerCase()}`,
        tier:       0,
        name:       `Domain reputation (${r.provider || 'unknown'})`,
        severity:   r.status === 'reported_malicious' ? 'Critical' : 'Info',
        confidence: r.status === 'reported_malicious' ? 'High' : 'Low',
        issue:      r.status === 'reported_malicious'
          ? `Reported as malicious by ${r.provider}`
          : `Not found in ${r.provider}${reputation.syntheticData ? ' (SYNTHETIC demo data)' : ''}`,
        evidence:   r,
        timestamp:  new Date().toISOString(),
      });
    }
  } catch (e) {
    skipped.push({ check: 'Domain reputation', reason: e.message, tier: 0 });
  }

  // ── Tier 1 gate ───────────────────────────────────────────────────────────────
  if (!authorized) {
    skipped.push({
      check:  'TLS certificate check',
      reason: 'Locked — authorization confirmation required for Tier 1 checks',
      tier:   1,
    });
    skipped.push({
      check:  'HTTP security headers',
      reason: 'Locked — authorization confirmation required for Tier 1 checks',
      tier:   1,
    });
    skipped.push({
      check:  'HTTPS redirect check',
      reason: 'Locked — authorization confirmation required for Tier 1 checks',
      tier:   1,
    });
    skipped.push({
      check:  'security.txt fetch',
      reason: 'Locked — authorization confirmation required for Tier 1 checks',
      tier:   1,
    });
    skipped.push({
      check:  'robots.txt fetch',
      reason: 'Locked — authorization confirmation required for Tier 1 checks',
      tier:   1,
    });

    return buildReport({ checks, skipped, hostname, targetUrl, dnsRecords, emailSecurity, reputation, requestsUsed, authorized, reportTimestamp });
  }

  // ── Tier 1 active checks ──────────────────────────────────────────────────────
  recordScanStart(clientIp, hostname);

  try {
    // Resolve IP once and pin it for all Tier 1 requests
    let pinnedIp;
    try {
      const resolved = await resolveHostname(hostname);
      pinnedIp = resolved.ip;
    } catch (e) {
      skipped.push({ check: 'All Tier 1 checks', reason: `DNS resolution failed: ${e.message}`, tier: 1 });
      return buildReport({ checks, skipped, hostname, targetUrl, dnsRecords, emailSecurity, reputation, requestsUsed, authorized, reportTimestamp });
    }

    const port = targetUrl.port ? parseInt(targetUrl.port, 10) : 443;

    // Request 1: TLS handshake
    try {
      requestsUsed++;
      const tlsResult = await checkTls(hostname, pinnedIp, port);
      for (const f of tlsResult.findings) {
        checks.push({
          id:         `tls-${f.issue.slice(0, 30).replace(/\s+/g, '-').toLowerCase()}`,
          tier:       1,
          name:       'TLS certificate',
          severity:   f.severity,
          confidence: 'High',
          issue:      f.issue,
          evidence:   { protocol: tlsResult.protocol, cipher: tlsResult.cipher, validTo: tlsResult.validTo, daysLeft: tlsResult.daysLeft, subject: tlsResult.subject, sans: tlsResult.sans },
          timestamp:  new Date().toISOString(),
        });
      }
    } catch (e) {
      skipped.push({ check: 'TLS certificate', reason: e.message, tier: 1 });
    }

    // Request 2: HTTPS GET for headers
    let headersResponse = null;
    try {
      requestsUsed++;
      headersResponse = await safeFetch(targetUrl.href, { method: 'GET' });
      const headerFindings = checkHeaders(headersResponse.headers);
      for (const f of headerFindings) {
        checks.push({
          id:         `header-${f.header.replace(/[^a-z0-9]/gi, '-').toLowerCase()}`,
          tier:       1,
          name:       `HTTP header: ${f.header}`,
          severity:   f.severity,
          confidence: f.confidence || 'High',
          issue:      f.issue,
          evidence:   f.evidence || null,
          remediation: f.remediation || null,
          timestamp:  new Date().toISOString(),
        });
      }
    } catch (e) {
      skipped.push({ check: 'HTTP security headers', reason: e.message, tier: 1 });
    }

    // Request 3: HTTP HEAD (redirect check)
    let httpRedirect = null;
    try {
      requestsUsed++;
      const httpUrl = targetUrl.href.replace(/^https:/, 'http:');
      httpRedirect = await safeFetch(httpUrl, { method: 'HEAD', followRedirects: true });
      const redirectedToHttps = httpRedirect.finalUrl.startsWith('https://');
      checks.push({
        id:         'https-redirect',
        tier:       1,
        name:       'HTTPS redirect',
        severity:   redirectedToHttps ? 'Info' : 'High',
        confidence: 'High',
        issue:      redirectedToHttps
          ? `HTTP redirects to HTTPS (final URL: ${httpRedirect.finalUrl})`
          : 'HTTP does not redirect to HTTPS',
        evidence:   { redirectChain: httpRedirect.redirectChain, finalUrl: httpRedirect.finalUrl },
        remediation: redirectedToHttps ? null : 'Configure a permanent (301) redirect from HTTP to HTTPS.',
        timestamp:  new Date().toISOString(),
      });
    } catch (e) {
      // HTTPS_DOWNGRADE is a finding, not just an error
      if (e.code === 'HTTPS_DOWNGRADE') {
        checks.push({
          id: 'https-downgrade', tier: 1, name: 'HTTPS redirect',
          severity: 'High', confidence: 'High',
          issue: `HTTP redirect chain contains an HTTPS→HTTP downgrade: ${e.message}`,
          timestamp: new Date().toISOString(),
        });
      } else {
        skipped.push({ check: 'HTTPS redirect check', reason: e.message, tier: 1 });
      }
    }

    // Request 4: security.txt
    try {
      requestsUsed++;
      const secTxtUrl = `https://${hostname}/.well-known/security.txt`;
      const resp = await safeFetch(secTxtUrl, { method: 'GET' });
      const found = resp.statusCode === 200;
      checks.push({
        id:         'security-txt',
        tier:       1,
        name:       'security.txt (RFC 9116)',
        severity:   found ? 'Info' : 'Low',
        confidence: 'High',
        issue:      found
          ? '/.well-known/security.txt is present (RFC 9116)'
          : `/.well-known/security.txt not found (HTTP ${resp.statusCode})`,
        remediation: found ? null : 'Consider publishing a security.txt to help researchers report vulnerabilities.',
        timestamp:  new Date().toISOString(),
      });
    } catch (e) {
      skipped.push({ check: 'security.txt', reason: e.message, tier: 1 });
    }

    // Request 5: robots.txt
    try {
      requestsUsed++;
      const robotsUrl = `https://${hostname}/robots.txt`;
      const resp = await safeFetch(robotsUrl, { method: 'GET' });
      checks.push({
        id:         'robots-txt',
        tier:       1,
        name:       'robots.txt',
        severity:   'Info',
        confidence: 'High',
        issue:      resp.statusCode === 200
          ? '/robots.txt is present'
          : `/robots.txt returned HTTP ${resp.statusCode}`,
        evidence:   { status: resp.statusCode },
        timestamp:  new Date().toISOString(),
      });
    } catch (e) {
      skipped.push({ check: 'robots.txt', reason: e.message, tier: 1 });
    }

  } finally {
    recordScanEnd(clientIp);
  }

  return buildReport({ checks, skipped, hostname, targetUrl, dnsRecords, emailSecurity, reputation, requestsUsed, authorized, reportTimestamp });
}

// ─── Report builder ───────────────────────────────────────────────────────────

function buildReport({ checks, skipped, hostname, targetUrl, dnsRecords, emailSecurity, reputation, requestsUsed, authorized, reportTimestamp }) {
  return {
    ok:              true,
    reportTimestamp,
    hostname,
    targetUrl:       targetUrl.href,
    authorized,
    requestBudget:   { used: requestsUsed, max: REQUEST_BUDGET },
    authorizationConfirmation: authorized
      ? { confirmed: true, timestamp: reportTimestamp, note: 'User confirmed authorization (identity not logged)' }
      : { confirmed: false },
    checks,
    skipped,
    dnsRecords:    sanitizeDnsRecords(dnsRecords),
    emailSecurity,
    reputation,
    persistentNotice: 'These checks observe publicly visible configuration at one point in time. They do not prove a website is secure or uncompromised, and a clean result is not an assurance.',
    limitations: [
      'Passive checks are a point-in-time snapshot.',
      'Reputation data is not a compromise test.',
      'Header and DNS checks cannot detect a breach.',
      'Results depend on what is publicly visible at the time of scanning.',
    ],
  };
}

function sanitizeDnsRecords(dnsRecords) {
  if (!dnsRecords) return null;
  // Escape all TXT record values before returning
  const safe = { ...dnsRecords };
  if (safe.TXT?.records) {
    safe.TXT = {
      ...safe.TXT,
      records: safe.TXT.records.map(r => escapeString(r)),
    };
  }
  return safe;
}

function escapeString(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/[<>&"']/g, c => ({ '<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&#x27;' }[c]));
}

module.exports = { runPostureCheck };
