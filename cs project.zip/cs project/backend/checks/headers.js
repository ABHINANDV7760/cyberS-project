/**
 * HTTP header checker — evaluates security headers from a single HTTP response.
 * Tier 1 (requires authorization confirmation).
 *
 * Headers checked:
 *  - Strict-Transport-Security
 *  - Content-Security-Policy
 *  - X-Content-Type-Options
 *  - X-Frame-Options / CSP frame-ancestors
 *  - Referrer-Policy
 *  - Permissions-Policy
 *  - Cross-Origin-Opener-Policy
 *  - Set-Cookie attributes (metadata only)
 *  - Information-leaking headers (Server, X-Powered-By)
 */

'use strict';

/**
 * Evaluate security-relevant HTTP response headers.
 *
 * @param {object} headers  - Node http.IncomingMessage headers (lower-cased keys)
 * @returns {HeaderCheckResult[]}
 */
function checkHeaders(headers) {
  const results = [];

  results.push(...checkHsts(headers));
  results.push(...checkCsp(headers));
  results.push(...checkXContentTypeOptions(headers));
  results.push(...checkFrameOptions(headers));
  results.push(...checkReferrerPolicy(headers));
  results.push(...checkPermissionsPolicy(headers));
  results.push(...checkCoop(headers));
  results.push(...checkCookies(headers));
  results.push(...checkLeakyHeaders(headers));

  return results;
}

// ─── Individual header checks ─────────────────────────────────────────────────

function checkHsts(headers) {
  const val = headers['strict-transport-security'];
  if (!val) {
    return [{
      header:      'Strict-Transport-Security',
      present:     false,
      severity:    'High',
      confidence:  'High',
      issue:       'HSTS header is missing',
      remediation: 'Add: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload',
      evidence:    null,
    }];
  }

  const findings = [];
  const maxAgeMatch = val.match(/max-age\s*=\s*(\d+)/i);
  const maxAge = maxAgeMatch ? parseInt(maxAgeMatch[1], 10) : 0;

  if (maxAge < 31536000) {
    findings.push({
      header:      'Strict-Transport-Security',
      present:     true,
      severity:    'Medium',
      confidence:  'High',
      issue:       `HSTS max-age is ${maxAge}s (recommended ≥ 31536000 / 1 year)`,
      remediation: 'Increase max-age to at least 31536000.',
      evidence:    val,
    });
  }
  if (!/includeSubDomains/i.test(val)) {
    findings.push({
      header:      'Strict-Transport-Security',
      present:     true,
      severity:    'Low',
      confidence:  'Medium',
      issue:       'HSTS does not include includeSubDomains',
      remediation: 'Add includeSubDomains to protect subdomains.',
      evidence:    val,
    });
  }
  if (findings.length === 0) {
    findings.push({
      header: 'Strict-Transport-Security', present: true,
      severity: 'Info', confidence: 'High',
      issue: 'HSTS header is present and configured well', evidence: val,
    });
  }
  return findings;
}

function checkCsp(headers) {
  const val = headers['content-security-policy'];
  if (!val) {
    return [{
      header:      'Content-Security-Policy',
      present:     false,
      severity:    'High',
      confidence:  'High',
      issue:       'Content-Security-Policy header is missing',
      remediation: "Add a CSP. Start with: Content-Security-Policy: default-src 'self'",
      evidence:    null,
    }];
  }

  const findings = [];

  if (/unsafe-inline/i.test(val)) {
    findings.push({
      header: 'Content-Security-Policy', present: true,
      severity: 'Medium', confidence: 'High',
      issue: "CSP contains 'unsafe-inline' — allows inline scripts/styles",
      remediation: "Remove 'unsafe-inline'; use nonces or hashes instead.",
      evidence: val,
    });
  }
  if (/unsafe-eval/i.test(val)) {
    findings.push({
      header: 'Content-Security-Policy', present: true,
      severity: 'Medium', confidence: 'High',
      issue: "CSP contains 'unsafe-eval' — allows eval() and similar",
      remediation: "Remove 'unsafe-eval'; refactor code to avoid eval.",
      evidence: val,
    });
  }
  // Wildcard source
  if (/\*(?!\.)/.test(val)) {
    findings.push({
      header: 'Content-Security-Policy', present: true,
      severity: 'Medium', confidence: 'Medium',
      issue: 'CSP contains a bare wildcard (*) source',
      remediation: 'Replace wildcards with explicit source origins.',
      evidence: val,
    });
  }

  if (findings.length === 0) {
    findings.push({
      header: 'Content-Security-Policy', present: true,
      severity: 'Info', confidence: 'Medium',
      issue: 'CSP header present; no obvious weak patterns detected (full audit requires manual review)',
      evidence: val,
    });
  }
  return findings;
}

function checkXContentTypeOptions(headers) {
  const val = headers['x-content-type-options'];
  if (!val || val.trim().toLowerCase() !== 'nosniff') {
    return [{
      header:      'X-Content-Type-Options',
      present:     !!val,
      severity:    'Low',
      confidence:  'High',
      issue:       val ? `X-Content-Type-Options is "${val}" instead of "nosniff"` : 'X-Content-Type-Options missing',
      remediation: 'Add: X-Content-Type-Options: nosniff',
      evidence:    val || null,
    }];
  }
  return [{
    header: 'X-Content-Type-Options', present: true,
    severity: 'Info', confidence: 'High',
    issue: 'X-Content-Type-Options: nosniff is set', evidence: val,
  }];
}

function checkFrameOptions(headers) {
  const xfo = headers['x-frame-options'];
  const csp = headers['content-security-policy'] || '';
  const hasFrameAncestors = /frame-ancestors/i.test(csp);

  if (!xfo && !hasFrameAncestors) {
    return [{
      header:      'X-Frame-Options / frame-ancestors',
      present:     false,
      severity:    'Medium',
      confidence:  'High',
      issue:       'Neither X-Frame-Options nor CSP frame-ancestors is set — clickjacking risk',
      remediation: "Add CSP frame-ancestors 'self' or X-Frame-Options: DENY",
      evidence:    null,
    }];
  }
  const findings = [];
  if (xfo && /ALLOW-FROM/i.test(xfo)) {
    findings.push({
      header: 'X-Frame-Options', present: true,
      severity: 'Low', confidence: 'High',
      issue: 'X-Frame-Options: ALLOW-FROM is deprecated; use CSP frame-ancestors instead',
      evidence: xfo,
    });
  }
  if (findings.length === 0) {
    findings.push({
      header: 'X-Frame-Options / frame-ancestors', present: true,
      severity: 'Info', confidence: 'High',
      issue: 'Frame embedding controls are present', evidence: xfo || csp,
    });
  }
  return findings;
}

function checkReferrerPolicy(headers) {
  const val = headers['referrer-policy'];
  if (!val) {
    return [{
      header:      'Referrer-Policy',
      present:     false,
      severity:    'Low',
      confidence:  'Medium',
      issue:       'Referrer-Policy is missing (browser default may leak URLs)',
      remediation: 'Add: Referrer-Policy: strict-origin-when-cross-origin',
      evidence:    null,
    }];
  }
  const weak = ['unsafe-url', 'no-referrer-when-downgrade'];
  if (weak.includes(val.toLowerCase())) {
    return [{
      header: 'Referrer-Policy', present: true,
      severity: 'Low', confidence: 'High',
      issue: `Referrer-Policy "${val}" may leak full URLs cross-origin`,
      remediation: 'Use: strict-origin-when-cross-origin or stricter.',
      evidence: val,
    }];
  }
  return [{
    header: 'Referrer-Policy', present: true,
    severity: 'Info', confidence: 'High',
    issue: `Referrer-Policy: ${val}`, evidence: val,
  }];
}

function checkPermissionsPolicy(headers) {
  const val = headers['permissions-policy'];
  if (!val) {
    return [{
      header:      'Permissions-Policy',
      present:     false,
      severity:    'Low',
      confidence:  'Medium',
      issue:       'Permissions-Policy (formerly Feature-Policy) is missing',
      remediation: 'Add: Permissions-Policy: geolocation=(), microphone=(), camera=()',
      evidence:    null,
    }];
  }
  return [{
    header: 'Permissions-Policy', present: true,
    severity: 'Info', confidence: 'Medium',
    issue: 'Permissions-Policy is present', evidence: val,
  }];
}

function checkCoop(headers) {
  const val = headers['cross-origin-opener-policy'];
  if (!val) {
    return [{
      header:      'Cross-Origin-Opener-Policy',
      present:     false,
      severity:    'Low',
      confidence:  'Medium',
      issue:       'Cross-Origin-Opener-Policy is missing',
      remediation: 'Add: Cross-Origin-Opener-Policy: same-origin',
      evidence:    null,
    }];
  }
  return [{
    header: 'Cross-Origin-Opener-Policy', present: true,
    severity: 'Info', confidence: 'High',
    issue: `COOP: ${val}`, evidence: val,
  }];
}

function checkCookies(headers) {
  // headers['set-cookie'] is an array (or undefined) in Node.js http module
  const raw = headers['set-cookie'];
  if (!raw || (Array.isArray(raw) && raw.length === 0)) {
    return [{
      header: 'Set-Cookie', present: false,
      severity: 'Info', confidence: 'High',
      issue: 'No Set-Cookie headers in this response', evidence: null,
    }];
  }

  const cookies = Array.isArray(raw) ? raw : [raw];
  const findings = [];

  for (const cookie of cookies) {
    // Only inspect attributes; never log/store values
    const parts  = cookie.split(';').map(p => p.trim());
    const name   = (parts[0].split('=')[0] || '').trim();
    const attrs  = parts.slice(1).map(p => p.toLowerCase());

    if (!attrs.some(a => a === 'secure')) {
      findings.push({
        header: 'Set-Cookie', present: true,
        severity: 'High', confidence: 'High',
        issue: `Cookie "${escapeForDisplay(name)}" is missing the Secure attribute`,
        remediation: 'Add Secure to all cookies to prevent transmission over HTTP.',
        evidence: '[Set-Cookie attributes only; value redacted]',
      });
    }
    if (!attrs.some(a => a === 'httponly')) {
      findings.push({
        header: 'Set-Cookie', present: true,
        severity: 'Medium', confidence: 'High',
        issue: `Cookie "${escapeForDisplay(name)}" is missing the HttpOnly attribute`,
        remediation: 'Add HttpOnly to cookies that do not need JavaScript access.',
        evidence: '[Set-Cookie attributes only; value redacted]',
      });
    }
    if (!attrs.some(a => a.startsWith('samesite'))) {
      findings.push({
        header: 'Set-Cookie', present: true,
        severity: 'Medium', confidence: 'Medium',
        issue: `Cookie "${escapeForDisplay(name)}" is missing SameSite attribute`,
        remediation: 'Add SameSite=Lax or SameSite=Strict.',
        evidence: '[Set-Cookie attributes only; value redacted]',
      });
    }
  }

  if (findings.length === 0) {
    findings.push({
      header: 'Set-Cookie', present: true,
      severity: 'Info', confidence: 'Medium',
      issue: `${cookies.length} cookie(s) checked; Secure, HttpOnly, SameSite all present`,
      evidence: '[Set-Cookie attributes only; values redacted]',
    });
  }
  return findings;
}

function checkLeakyHeaders(headers) {
  const findings = [];
  const leaky = ['server', 'x-powered-by', 'x-aspnet-version', 'x-aspnetmvc-version'];

  for (const hdr of leaky) {
    const val = headers[hdr];
    if (val) {
      // Check if value contains a version number
      const hasVersion = /\d+\.\d+/.test(val);
      findings.push({
        header: hdr,
        present: true,
        severity: hasVersion ? 'Low' : 'Info',
        confidence: 'High',
        issue: hasVersion
          ? `"${hdr}: ${escapeForDisplay(val)}" discloses software version information`
          : `"${hdr}: ${escapeForDisplay(val)}" discloses server technology`,
        remediation: `Remove or sanitise the "${hdr}" header to avoid fingerprinting.`,
        evidence: escapeForDisplay(val),
      });
    }
  }
  return findings;
}

// ─── Helper ───────────────────────────────────────────────────────────────────

function escapeForDisplay(str) {
  if (typeof str !== 'string') return String(str);
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}

module.exports = { checkHeaders, escapeForDisplay };
