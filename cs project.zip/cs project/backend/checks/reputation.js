/**
 * Reputation checker — optional adapter interface for third-party domain reputation.
 *
 * Providers are enabled via env vars. If none are configured, the module
 * operates in "No-API mode" and returns clearly labeled SYNTHETIC demo data
 * from fixtures (no network contact for demo entries).
 *
 * Supported providers (set via env vars):
 *   GOOGLE_SAFE_BROWSING_API_KEY  — Google Safe Browsing v4
 *   VIRUSTOTAL_API_KEY            — VirusTotal domain lookup
 *
 * The hostname/URL is sent only to configured providers — never to the target.
 */

'use strict';

const https = require('https');
const path  = require('path');

const DEMO_FIXTURES_PATH = path.join(__dirname, '../../fixtures/reputation-demo.json');

// Lazy-loaded fixture data
let demoFixtures = null;
function getDemoFixtures() {
  if (!demoFixtures) {
    try {
      demoFixtures = require(DEMO_FIXTURES_PATH);
    } catch {
      demoFixtures = {};
    }
  }
  return demoFixtures;
}

/**
 * Check domain reputation across configured providers.
 *
 * @param {string} hostname
 * @returns {Promise<ReputationResult>}
 */
async function checkReputation(hostname) {
  const gsbKey = process.env.GOOGLE_SAFE_BROWSING_API_KEY;
  const vtKey  = process.env.VIRUSTOTAL_API_KEY;

  const results = [];
  const noApiMode = !gsbKey && !vtKey;

  if (noApiMode) {
    // Return synthetic demo data (clearly labeled)
    const fixtures = getDemoFixtures();
    const demo = fixtures[hostname] || {
      status:   'not_found',
      provider: 'Demo (No-API mode)',
      note:     'No reputation API keys configured. This is SYNTHETIC demo data — not a real lookup.',
    };
    return {
      noApiMode: true,
      syntheticData: true,
      results: [demo],
      disclaimer: 'No reputation data. This does NOT mean the site is uncompromised. Configure API keys for real lookups.',
    };
  }

  if (gsbKey) {
    try {
      const gsb = await checkGoogleSafeBrowsing(hostname, gsbKey);
      results.push(gsb);
    } catch (e) {
      results.push({ provider: 'Google Safe Browsing', status: 'error', error: e.message });
    }
  }

  if (vtKey) {
    try {
      const vt = await checkVirusTotal(hostname, vtKey);
      results.push(vt);
    } catch (e) {
      results.push({ provider: 'VirusTotal', status: 'error', error: e.message });
    }
  }

  return {
    noApiMode:     false,
    syntheticData: false,
    results,
    disclaimer: 'Not found in checked databases does NOT mean the site is uncompromised.',
  };
}

// ─── Provider adapters ────────────────────────────────────────────────────────

async function checkGoogleSafeBrowsing(hostname, apiKey) {
  const body = JSON.stringify({
    client:    { clientId: 'website-security-inspector', clientVersion: '1.0' },
    threatInfo: {
      threatTypes:      ['MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE', 'POTENTIALLY_HARMFUL_APPLICATION'],
      platformTypes:    ['ANY_PLATFORM'],
      threatEntryTypes: ['URL'],
      threatEntries:    [{ url: `https://${hostname}/` }],
    },
  });

  const data = await httpsPost(
    `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${apiKey}`,
    body
  );

  const parsed = JSON.parse(data);
  const matches = parsed.matches || [];
  return {
    provider: 'Google Safe Browsing',
    status:   matches.length > 0 ? 'reported_malicious' : 'not_found',
    matches:  matches.map(m => ({
      threatType:  m.threatType,
      platformType: m.platformType,
    })),
  };
}

async function checkVirusTotal(hostname, apiKey) {
  const data = await httpsGet(
    `https://www.virustotal.com/api/v3/domains/${encodeURIComponent(hostname)}`,
    { 'x-apikey': apiKey }
  );

  const parsed = JSON.parse(data);
  const stats  = parsed.data?.attributes?.last_analysis_stats || {};
  const malicious = (stats.malicious || 0) + (stats.suspicious || 0);

  return {
    provider:  'VirusTotal',
    status:    malicious > 0 ? 'reported_malicious' : 'not_found',
    stats,
    maliciousEngineCount: malicious,
    totalEngines: Object.values(stats).reduce((a, b) => a + b, 0),
  };
}

// ─── HTTP helpers (no safe-fetch needed; these contact third-party APIs, not the target) ─

function httpsPost(url, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const req = https.request({
      hostname: u.hostname,
      path:     u.pathname + u.search,
      method:   'POST',
      headers:  { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      timeout:  8000,
    }, (res) => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks).toString()));
    });
    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('Reputation API timeout')));
    req.write(body);
    req.end();
  });
}

function httpsGet(url, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const req = https.request({
      hostname: u.hostname,
      path:     u.pathname + u.search,
      method:   'GET',
      headers:  { ...extraHeaders },
      timeout:  8000,
    }, (res) => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks).toString()));
    });
    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('Reputation API timeout')));
    req.end();
  });
}

module.exports = { checkReputation };
