/**
 * Rate limiter and request budget tracker for the posture check.
 *
 * Per-client (IP): one scan per target per minute, concurrency cap.
 * Request budget: max 6 requests per run (Tier 1), documented in the UI.
 */

'use strict';

// In-memory store: clientIp → Map<target, lastScanTimestamp>
const scanHistory = new Map();
// clientIp → currentConcurrency
const concurrency = new Map();

const SCAN_COOLDOWN_MS   = 60_000;  // one scan per target per minute
const MAX_CONCURRENCY    = 3;       // max concurrent scans per client IP

/**
 * Check if a client may start a new scan for the given target.
 * Returns { allowed: boolean, retryAfterMs?: number }
 */
function checkScanAllowed(clientIp, targetHostname) {
  const clientScans = scanHistory.get(clientIp);
  if (clientScans) {
    const last = clientScans.get(targetHostname);
    if (last) {
      const elapsed = Date.now() - last;
      if (elapsed < SCAN_COOLDOWN_MS) {
        return { allowed: false, retryAfterMs: SCAN_COOLDOWN_MS - elapsed };
      }
    }
  }
  const cc = concurrency.get(clientIp) || 0;
  if (cc >= MAX_CONCURRENCY) {
    return { allowed: false, retryAfterMs: null };
  }
  return { allowed: true };
}

/**
 * Record the start of a scan.
 */
function recordScanStart(clientIp, targetHostname) {
  if (!scanHistory.has(clientIp)) scanHistory.set(clientIp, new Map());
  scanHistory.get(clientIp).set(targetHostname, Date.now());
  concurrency.set(clientIp, (concurrency.get(clientIp) || 0) + 1);
}

/**
 * Record the end of a scan (decrement concurrency).
 */
function recordScanEnd(clientIp) {
  const cc = concurrency.get(clientIp) || 1;
  concurrency.set(clientIp, Math.max(0, cc - 1));
}

/**
 * Express middleware: enforce scan rate limit.
 */
function scanRateLimitMiddleware(req, res, next) {
  const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
  const { target } = req.body || {};
  if (!target) return next();

  let hostname;
  try {
    hostname = new URL(target).hostname;
  } catch {
    return next();
  }

  const { allowed, retryAfterMs } = checkScanAllowed(clientIp, hostname);
  if (!allowed) {
    const msg = retryAfterMs
      ? `Rate limit: please wait ${Math.ceil(retryAfterMs / 1000)}s before re-scanning this target`
      : 'Too many concurrent scans; please wait';
    return res.status(429).json({ error: msg });
  }
  next();
}

module.exports = { checkScanAllowed, recordScanStart, recordScanEnd, scanRateLimitMiddleware };
