/**
 * safe-fetch — shared SSRF-safe HTTP/DNS fetch module
 *
 * Enforces:
 *  - Hostname-to-IP resolution server-side
 *  - Rejection of all non-public IP ranges (loopback, RFC1918, link-local,
 *    CGNAT, 169.254.169.254, multicast, unspecified, ULA IPv6, IPv4-mapped)
 *  - DNS-rebinding defence by pinning the validated IP
 *  - Manual redirect handling with per-hop revalidation
 *  - Strict timeouts and response body cap
 *  - No cookie persistence, no auth headers forwarded
 *  - Fixed identifying User-Agent
 *  - No env-proxy usage (agent is explicit)
 */

'use strict';

const dns   = require('dns').promises;
const net   = require('net');
const tls   = require('tls');
const http  = require('http');
const https = require('https');
const { Address4, Address6 } = require('ip-address');

// ─── Constants ───────────────────────────────────────────────────────────────

const USER_AGENT       = 'WebsiteSecurityInspector/1.0 (defensive-security-tool)';
const CONNECT_TIMEOUT  = 3_000;   // ms
const TOTAL_TIMEOUT    = 8_000;   // ms
const BODY_CAP         = 64_000;  // bytes (64 KB)
const MAX_REDIRECTS    = 5;
const ALLOWED_SCHEMES  = new Set(['http:', 'https:']);
const ALLOWED_PORTS    = new Set([80, 443, 8080, 8443]);

// ─── IP classification ────────────────────────────────────────────────────────

/**
 * Returns true if the IPv4 address (dotted-decimal string) is NOT publicly
 * routable (i.e., is loopback, private, link-local, CGNAT, multicast, etc.)
 */
function isNonPublicIPv4(addr) {
  try {
    const a = new Address4(addr);
    // Loopback 127.0.0.0/8
    if (a.isInSubnet(new Address4('127.0.0.0/8')))   return true;
    // RFC1918 private
    if (a.isInSubnet(new Address4('10.0.0.0/8')))     return true;
    if (a.isInSubnet(new Address4('172.16.0.0/12')))  return true;
    if (a.isInSubnet(new Address4('192.168.0.0/16'))) return true;
    // Link-local (includes 169.254.169.254)
    if (a.isInSubnet(new Address4('169.254.0.0/16'))) return true;
    // CGNAT 100.64.0.0/10
    if (a.isInSubnet(new Address4('100.64.0.0/10')))  return true;
    // Multicast 224.0.0.0/4
    if (a.isInSubnet(new Address4('224.0.0.0/4')))    return true;
    // Broadcast / limited
    if (a.isInSubnet(new Address4('255.255.255.255/32'))) return true;
    // Unspecified 0.0.0.0/8
    if (a.isInSubnet(new Address4('0.0.0.0/8')))      return true;
    // Documentation ranges
    if (a.isInSubnet(new Address4('192.0.2.0/24')))   return true;
    if (a.isInSubnet(new Address4('198.51.100.0/24'))) return true;
    if (a.isInSubnet(new Address4('203.0.113.0/24'))) return true;
    return false;
  } catch {
    return true; // unparseable → reject
  }
}

/**
 * Returns true if the IPv6 address string is NOT publicly routable.
 */
function isNonPublicIPv6(addr) {
  try {
    // Strip brackets if present
    const cleaned = addr.replace(/^\[|\]$/g, '');
    const a = new Address6(cleaned);

    // Loopback ::1/128
    if (a.isLoopback())      return true;
    // Link-local fe80::/10
    if (a.isLinkLocal())     return true;
    // ULA fc00::/7
    if (a.isInSubnet(new Address6('fc00::/7')))  return true;
    // Multicast ff00::/8
    if (a.isInSubnet(new Address6('ff00::/8')))  return true;
    // Unspecified ::/128
    if (a.isInSubnet(new Address6('::/128')))    return true;
    // IPv4-mapped ::ffff:0:0/96
    if (a.isInSubnet(new Address6('::ffff:0:0/96'))) {
      // Extract the IPv4 portion and check it
      const v4 = a.to4().address;
      if (isNonPublicIPv4(v4)) return true;
    }
    // 6to4 2002::/16 (may embed private IPv4)
    if (a.isInSubnet(new Address6('2002::/16'))) {
      // Bits 16-47 encode the IPv4
      const groups = a.toGroup();
      if (groups) {
        const g = groups.split(':');
        const v4hex = (g[1] || '0000') + (g[2] || '0000');
        const v4 = [
          parseInt(v4hex.slice(0, 2), 16),
          parseInt(v4hex.slice(2, 4), 16),
          parseInt(v4hex.slice(4, 6), 16),
          parseInt(v4hex.slice(6, 8), 16),
        ].join('.');
        if (isNonPublicIPv4(v4)) return true;
      }
    }
    return false;
  } catch {
    return true;
  }
}

/**
 * Classifies any IP address string.
 * Returns { isPublic: boolean, reason: string }
 */
function classifyIP(addr) {
  const cleaned = addr.replace(/^\[|\]$/g, '');
  if (net.isIPv4(cleaned)) {
    const bad = isNonPublicIPv4(cleaned);
    return { isPublic: !bad, reason: bad ? `IPv4 address ${cleaned} is in a non-public range` : 'ok' };
  }
  if (net.isIPv6(cleaned)) {
    const bad = isNonPublicIPv6(cleaned);
    return { isPublic: !bad, reason: bad ? `IPv6 address ${cleaned} is in a non-public range` : 'ok' };
  }
  return { isPublic: false, reason: `Unrecognised IP format: ${addr}` };
}

// ─── URL Validation ───────────────────────────────────────────────────────────

/**
 * Validate and normalise a URL for safe-fetch usage.
 * Returns { ok: true, url: URL } or { ok: false, reason: string }.
 */
function validateUrl(rawUrl) {
  if (typeof rawUrl !== 'string' || rawUrl.length > 2048) {
    return { ok: false, reason: 'URL must be a string ≤ 2048 characters' };
  }
  let u;
  try {
    u = new URL(rawUrl);
  } catch {
    return { ok: false, reason: 'URL is not parseable' };
  }

  if (!ALLOWED_SCHEMES.has(u.protocol)) {
    return { ok: false, reason: `Scheme "${u.protocol}" is not allowed; use http or https` };
  }

  if (u.username || u.password) {
    return { ok: false, reason: 'Embedded credentials in URLs are not allowed' };
  }

  const port = u.port ? parseInt(u.port, 10) : (u.protocol === 'https:' ? 443 : 80);
  if (!ALLOWED_PORTS.has(port)) {
    return { ok: false, reason: `Port ${port} is not in the allowed set: ${[...ALLOWED_PORTS].join(', ')}` };
  }

  const hostname = u.hostname;

  // Reject bare IP literals (IPv4 and IPv6)
  if (net.isIPv4(hostname) || net.isIPv6(hostname.replace(/^\[|\]$/g, ''))) {
    return { ok: false, reason: 'IP-literal hosts are not accepted; use a hostname (organisation sites should use domain names)' };
  }

  if (!hostname || hostname.length < 1) {
    return { ok: false, reason: 'URL has no hostname' };
  }

  return { ok: true, url: u };
}

// ─── DNS resolution with IP validation ───────────────────────────────────────

/**
 * Resolve a hostname to its first public IP address.
 * Returns { ip: string, family: 4|6, allAddresses: string[] }
 * Throws SafeFetchError on failure.
 */
async function resolveHostname(hostname) {
  let records;
  try {
    records = await dns.resolve(hostname);
  } catch (e) {
    // Try resolve6 as fallback
    try {
      records = await dns.resolve6(hostname);
    } catch {
      throw new SafeFetchError(`DNS resolution failed for "${hostname}": ${e.message}`, 'DNS_FAIL');
    }
  }

  if (!records || records.length === 0) {
    throw new SafeFetchError(`DNS returned no records for "${hostname}"`, 'DNS_EMPTY');
  }

  // Validate every resolved address
  const publicAddresses = [];
  const rejectedReasons = [];

  for (const addr of records) {
    const { isPublic, reason } = classifyIP(addr);
    if (isPublic) {
      publicAddresses.push(addr);
    } else {
      rejectedReasons.push(`${addr}: ${reason}`);
    }
  }

  if (publicAddresses.length === 0) {
    throw new SafeFetchError(
      `All resolved addresses for "${hostname}" are non-public: ${rejectedReasons.join('; ')}`,
      'SSRF_BLOCKED'
    );
  }

  const chosen = publicAddresses[0];
  const family = net.isIPv6(chosen) ? 6 : 4;
  return { ip: chosen, family, allAddresses: publicAddresses };
}

// ─── SafeFetchError ───────────────────────────────────────────────────────────

class SafeFetchError extends Error {
  constructor(message, code) {
    super(message);
    this.name  = 'SafeFetchError';
    this.code  = code;
  }
}

// ─── Core safe HTTP/HTTPS request ────────────────────────────────────────────

/**
 * Perform a single HTTP/HTTPS request to a pre-validated, pinned IP.
 *
 * @param {object} opts
 * @param {'http:'|'https:'} opts.protocol
 * @param {string}  opts.hostname   - original hostname (used for SNI + Host header)
 * @param {string}  opts.ip         - pinned, pre-validated IP
 * @param {number}  opts.port
 * @param {string}  opts.path
 * @param {'GET'|'HEAD'} opts.method
 * @returns {Promise<{statusCode, headers, bodySnippet, timingMs}>}
 */
function rawRequest(opts) {
  return new Promise((resolve, reject) => {
    const { protocol, hostname, ip, port, path, method } = opts;

    const isHttps = protocol === 'https:';
    const lib = isHttps ? https : http;

    const startMs = Date.now();

    const reqOptions = {
      host: ip,             // connect to pinned IP → SSRF-safe
      port,
      path: path || '/',
      method: method || 'GET',
      headers: {
        Host: hostname,     // preserve original Host header
        'User-Agent': USER_AGENT,
        Accept: '*/*',
        Connection: 'close',
      },
      // TLS options
      ...(isHttps ? {
        servername: hostname,   // correct SNI
        rejectUnauthorized: false, // we capture cert errors ourselves
        checkServerIdentity: () => undefined, // manual cert checks
      } : {}),
      timeout: CONNECT_TIMEOUT,
    };

    let timedOut = false;
    const totalTimer = setTimeout(() => {
      timedOut = true;
      req.destroy(new SafeFetchError('Total request timeout', 'TIMEOUT'));
    }, TOTAL_TIMEOUT);

    const req = lib.request(reqOptions, (res) => {
      clearTimeout(totalTimer);
      if (timedOut) return;

      const chunks = [];
      let bytesRead = 0;
      let truncated = false;

      res.on('data', (chunk) => {
        if (bytesRead >= BODY_CAP) {
          truncated = true;
          res.destroy();
          return;
        }
        const remaining = BODY_CAP - bytesRead;
        const slice = chunk.length > remaining ? chunk.slice(0, remaining) : chunk;
        chunks.push(slice);
        bytesRead += slice.length;
      });

      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers:    res.headers,
          bodySnippet: Buffer.concat(chunks).toString('utf8', 0, 512), // tiny excerpt for error context only
          truncated,
          timingMs: Date.now() - startMs,
        });
      });

      res.on('error', reject);
    });

    req.on('error', (err) => {
      clearTimeout(totalTimer);
      reject(err);
    });

    req.on('timeout', () => {
      req.destroy(new SafeFetchError('Connect timeout', 'TIMEOUT'));
    });

    req.end();
  });
}

// ─── Public API ──────────────────────────────────────────────────────────────

/**
 * Perform a safe HTTP/HTTPS fetch with:
 *  - URL validation
 *  - DNS resolution and IP validation
 *  - SSRF blocking
 *  - Optional redirect following (with per-hop revalidation)
 *
 * @param {string}  rawUrl
 * @param {object}  [options]
 * @param {'GET'|'HEAD'}  [options.method='GET']
 * @param {boolean} [options.followRedirects=false]
 * @param {number}  [options.maxRedirects=MAX_REDIRECTS]
 * @returns {Promise<SafeFetchResult>}
 */
async function safeFetch(rawUrl, options = {}) {
  const {
    method         = 'GET',
    followRedirects = false,
    maxRedirects   = MAX_REDIRECTS,
  } = options;

  // Validate initial URL
  const validation = validateUrl(rawUrl);
  if (!validation.ok) {
    throw new SafeFetchError(validation.reason, 'INVALID_URL');
  }

  let currentUrl = validation.url;
  const redirectChain = [];
  let hopsLeft = maxRedirects;

  while (true) {
    const hostname = currentUrl.hostname;
    const port     = currentUrl.port
      ? parseInt(currentUrl.port, 10)
      : (currentUrl.protocol === 'https:' ? 443 : 80);

    // Resolve and validate IPs
    const resolved = await resolveHostname(hostname);

    const response = await rawRequest({
      protocol: currentUrl.protocol,
      hostname,
      ip: resolved.ip,
      port,
      path: currentUrl.pathname + currentUrl.search,
      method,
    });

    response.resolvedIp = resolved.ip;
    response.url        = currentUrl.href;

    const isRedirect = response.statusCode >= 300 && response.statusCode < 400;

    if (!followRedirects || !isRedirect || hopsLeft === 0) {
      return {
        finalUrl:      currentUrl.href,
        redirectChain,
        statusCode:    response.statusCode,
        headers:       response.headers,
        bodySnippet:   response.bodySnippet,
        truncated:     response.truncated,
        timingMs:      response.timingMs,
        resolvedIp:    resolved.ip,
      };
    }

    // Follow redirect
    const location = response.headers['location'];
    if (!location) {
      return {
        finalUrl:      currentUrl.href,
        redirectChain,
        statusCode:    response.statusCode,
        headers:       response.headers,
        bodySnippet:   response.bodySnippet,
        truncated:     response.truncated,
        timingMs:      response.timingMs,
        resolvedIp:    resolved.ip,
      };
    }

    // Resolve Location (may be relative)
    let nextUrl;
    try {
      nextUrl = new URL(location, currentUrl.href);
    } catch {
      throw new SafeFetchError(`Invalid redirect Location: ${location}`, 'INVALID_REDIRECT');
    }

    // Validate redirect URL
    const nextValidation = validateUrl(nextUrl.href);
    if (!nextValidation.ok) {
      throw new SafeFetchError(`Redirect target invalid: ${nextValidation.reason}`, 'INVALID_REDIRECT');
    }

    // Detect HTTPS → HTTP downgrade
    const downgrade = currentUrl.protocol === 'https:' && nextUrl.protocol === 'http:';

    // Detect cross-domain hop (compare registrable domain naively by eTLD+1)
    const origDomain = getRegistrableDomain(currentUrl.hostname);
    const nextDomain = getRegistrableDomain(nextUrl.hostname);
    const crossDomain = origDomain !== nextDomain;

    redirectChain.push({
      from:        currentUrl.href,
      to:          nextUrl.href,
      statusCode:  response.statusCode,
      downgrade,
      crossDomain,
    });

    if (downgrade) {
      throw new SafeFetchError(
        `Redirect from HTTPS to HTTP detected (${currentUrl.href} → ${nextUrl.href}); aborting for security`,
        'HTTPS_DOWNGRADE'
      );
    }

    currentUrl = nextUrl;
    hopsLeft--;
  }
}

/**
 * Naïve registrable domain extraction (last two labels).
 * Sufficient for cross-domain redirect detection; not a full Public Suffix List.
 */
function getRegistrableDomain(hostname) {
  const parts = hostname.split('.');
  return parts.slice(-2).join('.');
}

module.exports = {
  safeFetch,
  validateUrl,
  resolveHostname,
  classifyIP,
  isNonPublicIPv4,
  isNonPublicIPv6,
  SafeFetchError,
  USER_AGENT,
  BODY_CAP,
  MAX_REDIRECTS,
};
