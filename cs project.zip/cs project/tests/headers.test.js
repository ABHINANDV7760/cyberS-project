/**
 * Tests: HTTP security header evaluation.
 */

'use strict';

const { checkHeaders } = require('../backend/checks/headers');

// ─── HSTS ─────────────────────────────────────────────────────────────────────

describe('checkHeaders — HSTS', () => {
  test('flags missing HSTS as High', () => {
    const results = checkHeaders({});
    const hsts = results.filter(f => f.header === 'Strict-Transport-Security');
    expect(hsts.some(f => f.severity === 'High')).toBe(true);
  });

  test('accepts HSTS max-age=31536000; includeSubDomains', () => {
    const results = checkHeaders({ 'strict-transport-security': 'max-age=31536000; includeSubDomains' });
    const hsts    = results.filter(f => f.header === 'Strict-Transport-Security');
    expect(hsts.every(f => f.severity === 'Info' || f.severity === 'Low')).toBe(true);
  });

  test('flags low HSTS max-age as Medium', () => {
    const results = checkHeaders({ 'strict-transport-security': 'max-age=3600' });
    const hsts    = results.filter(f => f.header === 'Strict-Transport-Security');
    expect(hsts.some(f => f.severity === 'Medium')).toBe(true);
  });

  test('flags missing includeSubDomains as Low', () => {
    const results = checkHeaders({ 'strict-transport-security': 'max-age=31536000' });
    const hsts    = results.filter(f => f.header === 'Strict-Transport-Security');
    expect(hsts.some(f => f.severity === 'Low')).toBe(true);
  });
});

// ─── CSP ──────────────────────────────────────────────────────────────────────

describe('checkHeaders — CSP', () => {
  test('flags missing CSP as High', () => {
    const results = checkHeaders({});
    const csp = results.filter(f => f.header === 'Content-Security-Policy');
    expect(csp.some(f => f.severity === 'High')).toBe(true);
  });

  test("flags 'unsafe-inline' as Medium", () => {
    const results = checkHeaders({ 'content-security-policy': "default-src 'self'; script-src 'unsafe-inline'" });
    const csp     = results.filter(f => f.header === 'Content-Security-Policy');
    expect(csp.some(f => f.severity === 'Medium' && f.issue.includes('unsafe-inline'))).toBe(true);
  });

  test("flags 'unsafe-eval' as Medium", () => {
    const results = checkHeaders({ 'content-security-policy': "default-src 'self'; script-src 'unsafe-eval'" });
    const csp     = results.filter(f => f.header === 'Content-Security-Policy');
    expect(csp.some(f => f.severity === 'Medium' && f.issue.includes('unsafe-eval'))).toBe(true);
  });

  test('flags wildcard source as Medium', () => {
    const results = checkHeaders({ 'content-security-policy': "default-src *" });
    const csp     = results.filter(f => f.header === 'Content-Security-Policy');
    expect(csp.some(f => f.severity === 'Medium')).toBe(true);
  });

  test('accepts strict CSP as Info', () => {
    const results = checkHeaders({ 'content-security-policy': "default-src 'self'; object-src 'none'" });
    const csp     = results.filter(f => f.header === 'Content-Security-Policy');
    expect(csp.some(f => f.severity === 'Info')).toBe(true);
    expect(csp.filter(f => f.severity !== 'Info')).toHaveLength(0);
  });
});

// ─── X-Content-Type-Options ───────────────────────────────────────────────────

describe('checkHeaders — X-Content-Type-Options', () => {
  test('flags missing header as Low', () => {
    const results = checkHeaders({});
    const xcto = results.filter(f => f.header === 'X-Content-Type-Options');
    expect(xcto.some(f => f.severity === 'Low')).toBe(true);
  });

  test('accepts nosniff as Info', () => {
    const results = checkHeaders({ 'x-content-type-options': 'nosniff' });
    const xcto    = results.filter(f => f.header === 'X-Content-Type-Options');
    expect(xcto.some(f => f.severity === 'Info')).toBe(true);
  });
});

// ─── X-Frame-Options ─────────────────────────────────────────────────────────

describe('checkHeaders — X-Frame-Options / frame-ancestors', () => {
  test('flags absence of both as Medium', () => {
    const results = checkHeaders({});
    const xfo = results.filter(f => f.header.startsWith('X-Frame-Options'));
    expect(xfo.some(f => f.severity === 'Medium')).toBe(true);
  });

  test('accepts X-Frame-Options: DENY as Info', () => {
    const results = checkHeaders({ 'x-frame-options': 'DENY' });
    const xfo     = results.filter(f => f.header.startsWith('X-Frame-Options'));
    expect(xfo.some(f => f.severity === 'Info')).toBe(true);
  });

  test('accepts CSP frame-ancestors as Info', () => {
    const results = checkHeaders({ 'content-security-policy': "frame-ancestors 'self'" });
    const xfo     = results.filter(f => f.header.startsWith('X-Frame-Options'));
    expect(xfo.some(f => f.severity === 'Info' || f.severity === 'Low')).toBe(true);
  });
});

// ─── Cookie attributes ────────────────────────────────────────────────────────

describe('checkHeaders — Set-Cookie', () => {
  test('flags missing Secure attribute as High', () => {
    const results = checkHeaders({ 'set-cookie': ['session=abc; HttpOnly; SameSite=Strict'] });
    const cookies = results.filter(f => f.header === 'Set-Cookie');
    expect(cookies.some(f => f.severity === 'High' && f.issue.includes('Secure'))).toBe(true);
  });

  test('flags missing HttpOnly as Medium', () => {
    const results = checkHeaders({ 'set-cookie': ['session=abc; Secure; SameSite=Strict'] });
    const cookies = results.filter(f => f.header === 'Set-Cookie');
    expect(cookies.some(f => f.severity === 'Medium' && f.issue.includes('HttpOnly'))).toBe(true);
  });

  test('flags missing SameSite as Medium', () => {
    const results = checkHeaders({ 'set-cookie': ['session=abc; Secure; HttpOnly'] });
    const cookies = results.filter(f => f.header === 'Set-Cookie');
    expect(cookies.some(f => f.severity === 'Medium' && f.issue.includes('SameSite'))).toBe(true);
  });

  test('accepts fully-attributed cookie as Info', () => {
    const results = checkHeaders({ 'set-cookie': ['session=abc; Secure; HttpOnly; SameSite=Strict'] });
    const cookies = results.filter(f => f.header === 'Set-Cookie');
    expect(cookies.every(f => f.severity === 'Info')).toBe(true);
  });
});

// ─── Leaky headers ────────────────────────────────────────────────────────────

describe('checkHeaders — leaky headers', () => {
  test('flags Server header with version as Low', () => {
    const results = checkHeaders({ server: 'Apache/2.4.51' });
    const server  = results.filter(f => f.header === 'server');
    expect(server.some(f => f.severity === 'Low')).toBe(true);
  });

  test('flags X-Powered-By with version as Low', () => {
    const results = checkHeaders({ 'x-powered-by': 'Express/4.18.2' });
    const xpb     = results.filter(f => f.header === 'x-powered-by');
    expect(xpb.some(f => f.severity === 'Low')).toBe(true);
  });
});
