/**
 * Tests: TLS result handling (mocked handshake output).
 */

'use strict';

const tls    = require('tls');
const { checkTls } = require('../backend/checks/tls');

// ─── Mock TLS socket ──────────────────────────────────────────────────────────

function makeMockSocket(opts = {}) {
  const {
    cert = {
      subject:        { CN: 'example.com', O: 'Example Corp' },
      issuer:         { CN: 'Let\'s Encrypt R3', O: 'Let\'s Encrypt' },
      valid_from:     'Jan 1 00:00:00 2024 GMT',
      valid_to:       'Jan 1 00:00:00 2030 GMT',
      subjectaltname: 'DNS:example.com, DNS:www.example.com',
      serialNumber:   'AABB',
      fingerprint:    'AA:BB:CC',
    },
    protocol = 'TLSv1.3',
    cipher   = { name: 'TLS_AES_256_GCM_SHA384' },
  } = opts;

  // socket is created lazily so that tls.connect mock can assign it first
  const socketObj = {
    getPeerCertificate: jest.fn(() => cert),
    getProtocol:        jest.fn(() => protocol),
    getCipher:          jest.fn(() => cipher),
    destroy:            jest.fn(),
    on: jest.fn().mockReturnThis(),
  };

  // triggerConnect fires the connect callback asynchronously (after tls.connect returns)
  return {
    socket: socketObj,
    triggerConnect: (cb) => setImmediate(cb),
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('checkTls', () => {
  afterEach(() => jest.restoreAllMocks());

  test('returns valid result for a good certificate', async () => {
    const { socket, triggerConnect } = makeMockSocket();

    jest.spyOn(tls, 'connect').mockImplementation((_opts, connectCb) => {
      triggerConnect(connectCb);
      return socket;
    });

    const result = await checkTls('example.com', '93.184.216.34', 443);
    expect(result.valid).toBe(true);
    expect(result.protocol).toBe('TLSv1.3');
    expect(result.findings.some(f => f.severity === 'Info')).toBe(true);
  });

  test('flags expired certificate as Critical', async () => {
    const pastDate = 'Jan 1 00:00:00 2020 GMT';
    const { socket, triggerConnect } = makeMockSocket({
      cert: {
        subject:        { CN: 'example.com' },
        issuer:         { CN: 'R3' },
        valid_from:     'Jan 1 00:00:00 2019 GMT',
        valid_to:       pastDate, // expired
        subjectaltname: 'DNS:example.com',
        serialNumber:   'AA',
        fingerprint:    'AA',
      },
    });

    jest.spyOn(tls, 'connect').mockImplementation((_opts, connectCb) => {
      triggerConnect(connectCb);
      return socket;
    });

    const result = await checkTls('example.com', '93.184.216.34', 443);
    expect(result.expired).toBe(true);
    expect(result.findings.some(f => f.severity === 'Critical')).toBe(true);
  });

  test('flags self-signed certificate as High', async () => {
    const { socket, triggerConnect } = makeMockSocket({
      cert: {
        subject:        { CN: 'example.com' },
        issuer:         { CN: 'example.com' }, // same as subject = self-signed
        valid_from:     'Jan 1 00:00:00 2024 GMT',
        valid_to:       'Jan 1 00:00:00 2030 GMT',
        subjectaltname: 'DNS:example.com',
        serialNumber:   'AA',
        fingerprint:    'AA',
        // No issuerCertificate chain
      },
    });

    jest.spyOn(tls, 'connect').mockImplementation((_opts, connectCb) => {
      triggerConnect(connectCb);
      return socket;
    });

    const result = await checkTls('example.com', '93.184.216.34', 443);
    expect(result.selfSigned).toBe(true);
    expect(result.findings.some(f => f.severity === 'High')).toBe(true);
  });

  test('flags hostname mismatch as Critical', async () => {
    const { socket, triggerConnect } = makeMockSocket({
      cert: {
        subject:        { CN: 'other.com' },
        issuer:         { CN: 'R3' },
        valid_from:     'Jan 1 00:00:00 2024 GMT',
        valid_to:       'Jan 1 00:00:00 2030 GMT',
        subjectaltname: 'DNS:other.com',
        serialNumber:   'AA',
        fingerprint:    'AA',
      },
    });

    jest.spyOn(tls, 'connect').mockImplementation((_opts, connectCb) => {
      triggerConnect(connectCb);
      return socket;
    });

    const result = await checkTls('example.com', '93.184.216.34', 443);
    expect(result.hostnameMatch).toBe(false);
    expect(result.findings.some(f => f.severity === 'Critical')).toBe(true);
  });

  test('flags weak TLS protocol as High', async () => {
    const { socket, triggerConnect } = makeMockSocket({ protocol: 'TLSv1' });

    jest.spyOn(tls, 'connect').mockImplementation((_opts, connectCb) => {
      triggerConnect(connectCb);
      return socket;
    });

    const result = await checkTls('example.com', '93.184.216.34', 443);
    expect(result.findings.some(f => f.severity === 'High' && f.issue.includes('TLSv1'))).toBe(true);
  });

  test('rejects on connection error', async () => {
    jest.spyOn(tls, 'connect').mockImplementation((_opts, _connectCb) => {
      const errorCallbacks = [];
      const errSocket = {
        getPeerCertificate: jest.fn(),
        getProtocol:        jest.fn(),
        getCipher:          jest.fn(),
        destroy:            jest.fn(),
        on: jest.fn((evt, cb) => {
          if (evt === 'error') errorCallbacks.push(cb);
          return errSocket;
        }),
      };
      // Fire error after tls.connect returns the socket
      setImmediate(() => errorCallbacks.forEach(cb => cb(new Error('ECONNREFUSED'))));
      return errSocket;
    });

    await expect(checkTls('example.com', '93.184.216.34', 443)).rejects.toThrow(/ECONNREFUSED/);
  });
});
