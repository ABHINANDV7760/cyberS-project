/**
 * Tests: SPF and DMARC record parsing.
 */

'use strict';

const { checkEmailSecurity } = require('../backend/checks/dns');

// We test the parsers indirectly; extract them for direct testing too
// by requiring the module with a mock
const dns = require('dns').promises;

// ─── Helper: mock TXT lookups ─────────────────────────────────────────────────

function mockResolveTxt(map) {
  // map: { host: ['record1', 'record2'] }
  jest.spyOn(dns, 'resolveTxt').mockImplementation(async (host) => {
    const records = map[host];
    if (!records || records.length === 0) throw Object.assign(new Error('ENODATA'), { code: 'ENODATA' });
    return records.map(r => [r]); // dns.resolveTxt returns arrays of strings per record
  });
}

afterEach(() => jest.restoreAllMocks());

// ─── SPF ──────────────────────────────────────────────────────────────────────

describe('SPF parsing', () => {
  test('detects missing SPF record', async () => {
    jest.spyOn(dns, 'resolve4').mockResolvedValue(['1.1.1.1']);
    jest.spyOn(dns, 'resolve6').mockRejectedValue(new Error('ENODATA'));
    jest.spyOn(dns, 'resolveNs').mockResolvedValue(['ns1.example.com']);
    jest.spyOn(dns, 'resolveMx').mockResolvedValue([]);
    jest.spyOn(dns, 'resolveCaa').mockResolvedValue([]);
    jest.spyOn(dns, 'resolveSoa').mockResolvedValue({});

    mockResolveTxt({
      'example.com': [],          // no TXT records
      '_dmarc.example.com': [],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    expect(result.spf.present).toBe(false);
    expect(result.spf.findings[0].severity).toBe('High');
  });

  test('detects +all (permit-all) as Critical', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 +all'],
      '_dmarc.example.com': [],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    const critFinding = result.spf.findings.find(f => f.severity === 'Critical');
    expect(critFinding).toBeDefined();
    expect(critFinding.issue).toMatch(/\+all/);
  });

  test('detects ?all as Medium', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 ?all'],
      '_dmarc.example.com': [],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    const med = result.spf.findings.find(f => f.severity === 'Medium');
    expect(med).toBeDefined();
  });

  test('detects multiple SPF records as High', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 -all', 'v=spf1 include:other.com -all'],
      '_dmarc.example.com': [],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    const multiFinding = result.spf.findings.find(f => f.issue.toLowerCase().includes('multiple'));
    expect(multiFinding).toBeDefined();
    expect(multiFinding.severity).toBe('High');
  });

  test('accepts well-formed SPF -all as Info', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 include:_spf.example.com -all'],
      '_dmarc.example.com': [],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    expect(result.spf.present).toBe(true);
    // No Critical or High findings
    const bad = result.spf.findings.filter(f => ['Critical','High'].includes(f.severity));
    expect(bad).toHaveLength(0);
  });
});

// ─── DMARC ────────────────────────────────────────────────────────────────────

describe('DMARC parsing', () => {
  test('detects missing DMARC record', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 -all'],
      '_dmarc.example.com': [],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    expect(result.dmarc.present).toBe(false);
    expect(result.dmarc.findings[0].severity).toBe('High');
  });

  test('detects p=none as Medium', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 -all'],
      '_dmarc.example.com': ['v=DMARC1; p=none; rua=mailto:dmarc@example.com'],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    expect(result.dmarc.present).toBe(true);
    const noneFinding = result.dmarc.findings.find(f => f.issue.includes('none'));
    expect(noneFinding).toBeDefined();
    expect(noneFinding.severity).toBe('Medium');
  });

  test('detects p=reject as Info', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 -all'],
      '_dmarc.example.com': ['v=DMARC1; p=reject; rua=mailto:dmarc@example.com; pct=100'],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    const rejectFinding = result.dmarc.findings.find(f => f.issue.includes('reject'));
    expect(rejectFinding).toBeDefined();
    expect(rejectFinding.severity).toBe('Info');
  });

  test('flags missing rua as Low', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 -all'],
      '_dmarc.example.com': ['v=DMARC1; p=reject'],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    const ruaFinding = result.dmarc.findings.find(f => f.issue.includes('rua'));
    expect(ruaFinding).toBeDefined();
    expect(ruaFinding.severity).toBe('Low');
  });

  test('flags pct < 100 as Low', async () => {
    mockResolveTxt({
      'example.com': ['v=spf1 -all'],
      '_dmarc.example.com': ['v=DMARC1; p=reject; rua=mailto:dmarc@example.com; pct=50'],
      '_mta-sts.example.com': [],
      '_smtp._tls.example.com': [],
      'default._bimi.example.com': [],
    });

    const result = await checkEmailSecurity('example.com', null);
    const pctFinding = result.dmarc.findings.find(f => f.issue.includes('pct=50'));
    expect(pctFinding).toBeDefined();
    expect(pctFinding.severity).toBe('Low');
  });
});
