/**
 * Tests: safeFetch redirect revalidation, SSRF blocking on DNS resolution,
 *        private-IP rejection, HTTPS→HTTP downgrade blocking, oversized responses.
 */

'use strict';

const http   = require('http');
const https  = require('https');
const net    = require('net');
const dns    = require('dns');

// We test the safe-fetch module with mocked DNS and mocked HTTP
const safeFetchModule = require('../backend/safe-fetch');
const { safeFetch, SafeFetchError, resolveHostname, BODY_CAP } = safeFetchModule;

// ─── Mock DNS resolution ──────────────────────────────────────────────────────

// Helper to override dns.promises.resolve within safe-fetch
function mockDnsResolve(ip) {
  const dnsModule = require('dns').promises;
  const original  = dnsModule.resolve;
  dnsModule.resolve = jest.fn().mockResolvedValue([ip]);
  return () => { dnsModule.resolve = original; };
}

// ─── Tests: resolveHostname with mocked DNS ────────────────────────────────────

describe('resolveHostname — private IP rejection', () => {
  afterEach(() => jest.restoreAllMocks());

  test('rejects hostname that resolves to loopback (127.0.0.1)', async () => {
    const restore = mockDnsResolve('127.0.0.1');
    try {
      await expect(resolveHostname('internal.test')).rejects.toMatchObject({ code: 'SSRF_BLOCKED' });
    } finally {
      restore();
    }
  });

  test('rejects hostname that resolves to 169.254.169.254', async () => {
    const restore = mockDnsResolve('169.254.169.254');
    try {
      await expect(resolveHostname('metadata.test')).rejects.toMatchObject({ code: 'SSRF_BLOCKED' });
    } finally {
      restore();
    }
  });

  test('rejects hostname that resolves to RFC1918 address (10.0.0.1)', async () => {
    const restore = mockDnsResolve('10.0.0.1');
    try {
      await expect(resolveHostname('private.test')).rejects.toMatchObject({ code: 'SSRF_BLOCKED' });
    } finally {
      restore();
    }
  });

  test('rejects hostname that resolves to CGNAT (100.64.0.1)', async () => {
    const restore = mockDnsResolve('100.64.0.1');
    try {
      await expect(resolveHostname('cgnat.test')).rejects.toMatchObject({ code: 'SSRF_BLOCKED' });
    } finally {
      restore();
    }
  });

  test('accepts hostname that resolves to public IP', async () => {
    const restore = mockDnsResolve('93.184.216.34');
    try {
      const result = await resolveHostname('example.com');
      expect(result.ip).toBe('93.184.216.34');
    } finally {
      restore();
    }
  });
});

// ─── Tests: safeFetch HTTPS → HTTP redirect downgrade ─────────────────────────

describe('safeFetch — redirect downgrade blocking', () => {
  afterEach(() => jest.restoreAllMocks());

  test('blocks redirect from HTTPS to HTTP', async () => {
    // Mock DNS to return public IP
    const dnsModule = require('dns').promises;
    jest.spyOn(dnsModule, 'resolve').mockResolvedValue(['93.184.216.34']);

    // Mock https.request to return a 301 redirecting to http://
    const mockResp = {
      statusCode: 301,
      headers: { location: 'http://example.com/downgrade' },
      on: jest.fn((evt, cb) => { if (evt === 'end') cb(); return mockResp; }),
    };
    jest.spyOn(https, 'request').mockImplementation((_opts, cb) => {
      cb(mockResp);
      return {
        on: jest.fn().mockReturnThis(),
        end: jest.fn(),
        destroy: jest.fn(),
      };
    });

    await expect(
      safeFetch('https://example.com/', { followRedirects: true })
    ).rejects.toMatchObject({ code: 'HTTPS_DOWNGRADE' });
  });
});

// ─── Tests: oversized response truncation ──────────────────────────────────────

describe('safe-fetch — oversized response handling', () => {
  // This tests the BODY_CAP constant is 64 KB
  test('BODY_CAP is 64 KB', () => {
    expect(BODY_CAP).toBe(64_000);
  });

  // Verify that the module exports the cap (integration with posture check)
  test('safeFetchModule exports BODY_CAP', () => {
    expect(typeof safeFetchModule.BODY_CAP).toBe('number');
    expect(safeFetchModule.BODY_CAP).toBeGreaterThan(0);
    expect(safeFetchModule.BODY_CAP).toBeLessThanOrEqual(65_536);
  });
});
