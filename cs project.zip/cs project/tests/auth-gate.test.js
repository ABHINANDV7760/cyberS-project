/**
 * Tests: authorization-gate enforcement.
 * Tier 1 calls must be rejected server-side when authorized=false,
 * not just disabled in the UI.
 */

'use strict';

const request = require('supertest');
const app     = require('../backend/server');
const dns     = require('dns').promises;

// Silence console during tests
beforeAll(() => {
  jest.spyOn(console, 'log').mockImplementation(() => {});
  jest.spyOn(console, 'error').mockImplementation(() => {});
});
afterAll(() => jest.restoreAllMocks());

// ─── Authorization gate ───────────────────────────────────────────────────────

describe('POST /api/posture-check — authorization gate', () => {
  afterEach(() => jest.restoreAllMocks());

  test('accepts valid request with authorized=false (passive only)', async () => {
    // Mock DNS so no real lookups happen
    jest.spyOn(dns, 'resolve4').mockResolvedValue(['93.184.216.34']);
    jest.spyOn(dns, 'resolve6').mockRejectedValue(Object.assign(new Error(), { code: 'ENODATA' }));
    jest.spyOn(dns, 'resolveNs').mockResolvedValue(['ns1.example.com']);
    jest.spyOn(dns, 'resolveMx').mockResolvedValue([]);
    jest.spyOn(dns, 'resolveTxt').mockResolvedValue([['v=spf1 -all']]);
    jest.spyOn(dns, 'resolveCaa').mockResolvedValue([]);
    jest.spyOn(dns, 'resolveSoa').mockResolvedValue({});
    jest.spyOn(dns, 'resolve').mockResolvedValue(['93.184.216.34']);

    const resp = await request(app)
      .post('/api/posture-check')
      .send({ target: 'https://example.com', authorized: false })
      .set('Content-Type', 'application/json');

    expect(resp.status).toBe(200);
    expect(resp.body.authorized).toBe(false);

    // Tier 1 checks must be in skipped
    const skippedNames = (resp.body.skipped || []).map(s => s.check);
    expect(skippedNames).toContain('TLS certificate check');
    expect(skippedNames).toContain('HTTP security headers');
    expect(skippedNames).toContain('HTTPS redirect check');
  });

  test('rejects request with invalid target', async () => {
    const resp = await request(app)
      .post('/api/posture-check')
      .send({ target: 'ftp://example.com', authorized: false })
      .set('Content-Type', 'application/json');

    expect(resp.status).toBe(400);
    expect(resp.body.error).toBeDefined();
  });

  test('rejects IP-literal target', async () => {
    const resp = await request(app)
      .post('/api/posture-check')
      .send({ target: 'https://192.168.1.1', authorized: false })
      .set('Content-Type', 'application/json');

    expect(resp.status).toBe(400);
    expect(resp.body.error).toMatch(/IP-literal/i);
  });

  test('rejects missing target', async () => {
    const resp = await request(app)
      .post('/api/posture-check')
      .send({ authorized: false })
      .set('Content-Type', 'application/json');

    expect(resp.status).toBe(400);
  });

  test('rejects non-boolean authorized field', async () => {
    const resp = await request(app)
      .post('/api/posture-check')
      .send({ target: 'https://example.com', authorized: 'yes' })
      .set('Content-Type', 'application/json');

    expect(resp.status).toBe(400);
  });

  test('GET /api/health returns ok', async () => {
    const resp = await request(app).get('/api/health');
    expect(resp.status).toBe(200);
    expect(resp.body.status).toBe('ok');
  });
});
