/**
 * Tests: log normalization and all detection rules (including insufficient-baseline case),
 * and fact-vs-inference separation.
 */

'use strict';

// ─── Inline the normalizer and rules from the worker for Node testing ─────────
// The worker uses self.onmessage; we extract the logic into testable functions
// by re-implementing the same pure functions here and verifying their contract.

// ── Normalization ──────────────────────────────────────────────────────────────

function normalizeOutcome(val) {
  const v = val.toLowerCase();
  if (/success|accept|ok|pass|200/.test(v)) return 'success';
  if (/fail|denied|error|reject|invalid|401|403/.test(v)) return 'failure';
  return 'other';
}

function normalize(raw, recId, sourceFile, lineNumber) {
  const tsRaw = String(raw.timestamp || raw.time || raw.ts || raw.date || '');
  let timestampUtc = null;
  let tzAmbiguous  = false;

  if (tsRaw) {
    const d = new Date(tsRaw);
    if (!isNaN(d.getTime())) {
      timestampUtc = d.toISOString();
      tzAmbiguous  = !/Z$|[+-]\d{2}:\d{2}$/.test(tsRaw);
    } else {
      tzAmbiguous = true;
    }
  }

  return {
    record_id:     recId,
    source_file:   String(sourceFile),
    line_number:   lineNumber,
    timestamp_utc: timestampUtc,
    timestamp_raw: tsRaw.slice(0, 100),
    tz_ambiguous:  tzAmbiguous,
    account_id:    String(raw.account_id || raw.user || '').slice(0, 200),
    source_ip:     String(raw.source_ip  || raw.ip  || '').slice(0, 45),
    user_agent:    String(raw.user_agent || '').slice(0, 500),
    outcome:       normalizeOutcome(String(raw.outcome || '')),
    event_type:    String(raw.event_type || 'login').slice(0, 50),
    raw_line:      JSON.stringify(raw).slice(0, 500),
  };
}

// ── Simple detection rule helpers ─────────────────────────────────────────────

function groupBy(arr, keyFn) {
  const map = new Map();
  for (const item of arr) {
    const key = keyFn(item);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(item);
  }
  return map;
}

function byTime(a, b) { return new Date(a.timestamp_utc) - new Date(b.timestamp_utc); }

function findFailureWindows(records, N, windowM) {
  const failures = records.filter(r => r.outcome === 'failure' && r.timestamp_utc).sort(byTime);
  const windows  = [];
  const windowMs = windowM * 60_000;
  for (let i = 0; i < failures.length; i++) {
    const start = new Date(failures[i].timestamp_utc).getTime();
    const inWindow = failures.filter(r => {
      const t = new Date(r.timestamp_utc).getTime();
      return t >= start && t <= start + windowMs;
    });
    if (inWindow.length >= N) {
      windows.push({ count: inWindow.length, start: failures[i].timestamp_utc, end: inWindow[inWindow.length-1].timestamp_utc, records: inWindow });
      i += inWindow.length - 1;
    }
  }
  return windows;
}

function findSuccessAfterFailure(records, N, windowM) {
  const sorted   = records.filter(r => r.timestamp_utc).sort(byTime);
  const windowMs = windowM * 60_000;
  const events   = [];
  for (const success of sorted.filter(r => r.outcome === 'success')) {
    const st    = new Date(success.timestamp_utc).getTime();
    const prior = sorted.filter(r =>
      r.outcome === 'failure' &&
      new Date(r.timestamp_utc).getTime() >= st - windowMs &&
      new Date(r.timestamp_utc).getTime() < st
    );
    if (prior.length >= N) events.push({ failureCount: prior.length, successTime: success.timestamp_utc, records: [...prior, success] });
  }
  return events;
}

function findSprayWindows(records, N, windowM) {
  const failures = records.filter(r => r.outcome === 'failure' && r.timestamp_utc).sort(byTime);
  const windows  = [];
  const windowMs = windowM * 60_000;
  for (let i = 0; i < failures.length; i++) {
    const start = new Date(failures[i].timestamp_utc).getTime();
    const inWindow = failures.filter(r => {
      const t = new Date(r.timestamp_utc).getTime();
      return t >= start && t <= start + windowMs;
    });
    const accounts = new Set(inWindow.map(r => r.account_id).filter(Boolean));
    if (accounts.size >= N) {
      windows.push({ accounts, start: failures[i].timestamp_utc, end: inWindow[inWindow.length-1].timestamp_utc, records: inWindow });
      i += inWindow.length - 1;
    }
  }
  return windows;
}

function getTimeSpanDays(records) {
  const withTs = records.filter(r => r.timestamp_utc).sort(byTime);
  if (withTs.length < 2) return 0;
  return (new Date(withTs[withTs.length-1].timestamp_utc) - new Date(withTs[0].timestamp_utc)) / 86_400_000;
}

// ─── Normalization tests ──────────────────────────────────────────────────────

describe('Log normalization', () => {
  test('normalizes success outcome variants', () => {
    expect(normalizeOutcome('success')).toBe('success');
    expect(normalizeOutcome('Accepted')).toBe('success');
    expect(normalizeOutcome('ok')).toBe('success');
    expect(normalizeOutcome('200')).toBe('success');
  });

  test('normalizes failure outcome variants', () => {
    expect(normalizeOutcome('failure')).toBe('failure');
    expect(normalizeOutcome('Failed')).toBe('failure');
    expect(normalizeOutcome('denied')).toBe('failure');
    expect(normalizeOutcome('401')).toBe('failure');
    expect(normalizeOutcome('invalid')).toBe('failure');
  });

  test('normalizes unknown outcome to "other"', () => {
    expect(normalizeOutcome('logout')).toBe('other');
    expect(normalizeOutcome('')).toBe('other');
  });

  test('parses ISO timestamp to UTC', () => {
    const rec = normalize({ timestamp: '2024-01-15T02:10:01Z', outcome: 'failure', account_id: 'alice' }, 0, 'test.log', 1);
    expect(rec.timestamp_utc).toBe('2024-01-15T02:10:01.000Z');
    expect(rec.tz_ambiguous).toBe(false);
  });

  test('flags ambiguous timezone', () => {
    const rec = normalize({ timestamp: '2024-01-15 02:10:01', outcome: 'failure', account_id: 'alice' }, 0, 'test.log', 1);
    expect(rec.tz_ambiguous).toBe(true);
  });

  test('handles missing timestamp', () => {
    const rec = normalize({ outcome: 'failure', account_id: 'alice' }, 0, 'test.log', 1);
    expect(rec.timestamp_utc).toBeNull();
  });

  test('truncates long account_id', () => {
    const rec = normalize({ outcome: 'success', account_id: 'a'.repeat(300) }, 0, 'test.log', 1);
    expect(rec.account_id.length).toBe(200);
  });
});

// ─── Detection rule tests ─────────────────────────────────────────────────────

// Build sample records
function makeRec(id, account, ip, outcome, ts) {
  return normalize({ account_id: account, source_ip: ip, outcome, timestamp: ts }, id, 'test.log', id);
}

describe('Rule 1: Repeated failed logins', () => {
  test('detects 5+ failures per account in window', () => {
    const records = [
      makeRec(0, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:10:00Z'),
      makeRec(1, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:11:00Z'),
      makeRec(2, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:12:00Z'),
      makeRec(3, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:13:00Z'),
      makeRec(4, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:14:00Z'),
    ];
    const windows = findFailureWindows(records, 5, 10);
    expect(windows.length).toBeGreaterThan(0);
    expect(windows[0].count).toBe(5);
  });

  test('does not fire for fewer than threshold', () => {
    const records = [
      makeRec(0, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:10:00Z'),
      makeRec(1, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:11:00Z'),
    ];
    const windows = findFailureWindows(records, 5, 10);
    expect(windows.length).toBe(0);
  });

  test('does not count failures outside window', () => {
    const records = [
      makeRec(0, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:00:00Z'),
      makeRec(1, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:01:00Z'),
      makeRec(2, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:02:00Z'),
      makeRec(3, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:59:00Z'), // far outside 10-min window
      makeRec(4, 'alice', '1.2.3.4', 'failure', '2024-01-15T03:00:00Z'),
    ];
    const windows = findFailureWindows(records, 5, 10);
    expect(windows.length).toBe(0);
  });
});

describe('Rule 2: Success after repeated failures', () => {
  test('detects success after N failures in window', () => {
    const records = [
      makeRec(0, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:10:00Z'),
      makeRec(1, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:11:00Z'),
      makeRec(2, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:12:00Z'),
      makeRec(3, 'alice', '1.2.3.4', 'success', '2024-01-15T02:13:00Z'),
    ];
    const events = findSuccessAfterFailure(records, 3, 15);
    expect(events.length).toBe(1);
    expect(events[0].failureCount).toBe(3);
  });

  test('does not fire when failures are below threshold', () => {
    const records = [
      makeRec(0, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:10:00Z'),
      makeRec(1, 'alice', '1.2.3.4', 'failure', '2024-01-15T02:11:00Z'),
      makeRec(2, 'alice', '1.2.3.4', 'success', '2024-01-15T02:12:00Z'),
    ];
    const events = findSuccessAfterFailure(records, 3, 15);
    expect(events.length).toBe(0);
  });
});

describe('Rule 4: Spray pattern', () => {
  test('detects failures against 5+ distinct accounts from one IP in window', () => {
    const records = [
      makeRec(0, 'alice',  '9.9.9.9', 'failure', '2024-01-15T02:15:00Z'),
      makeRec(1, 'bob',    '9.9.9.9', 'failure', '2024-01-15T02:15:01Z'),
      makeRec(2, 'carol',  '9.9.9.9', 'failure', '2024-01-15T02:15:02Z'),
      makeRec(3, 'dave',   '9.9.9.9', 'failure', '2024-01-15T02:15:03Z'),
      makeRec(4, 'eve',    '9.9.9.9', 'failure', '2024-01-15T02:15:04Z'),
    ];
    const windows = findSprayWindows(records, 5, 5);
    expect(windows.length).toBeGreaterThan(0);
    expect(windows[0].accounts.size).toBe(5);
  });

  test('does not fire for same account repeated', () => {
    const records = Array.from({ length: 10 }, (_, i) =>
      makeRec(i, 'alice', '9.9.9.9', 'failure', `2024-01-15T02:15:0${i % 10}Z`)
    );
    const windows = findSprayWindows(records, 5, 5);
    // All same account — accounts.size = 1, shouldn't fire
    expect(windows.length).toBe(0);
  });
});

describe('Rule 5: Insufficient baseline guard', () => {
  test('does not apply rule when data span < 14 days', () => {
    const records = [
      makeRec(0, 'alice', '1.2.3.4', 'success', '2024-01-15T02:00:00Z'),
      makeRec(1, 'alice', '1.2.3.4', 'success', '2024-01-15T03:00:00Z'),
      makeRec(2, 'alice', '1.2.3.4', 'success', '2024-01-15T04:00:00Z'),
    ];
    const span = getTimeSpanDays(records);
    expect(span).toBeLessThan(14);
    // Rule must not be applied — this is verified by the rule checking span < minDays
    // The guard condition: if (span < T.baselineMinDays) skip
    expect(span < 14).toBe(true);
  });

  test('does not apply when fewer than 20 events', () => {
    const records = Array.from({ length: 10 }, (_, i) =>
      makeRec(i, 'alice', '1.2.3.4', 'success', new Date(new Date('2024-01-01').getTime() + i * 86400000 * 2).toISOString())
    );
    // 10 events < 20 threshold
    expect(records.length).toBeLessThan(20);
  });
});

// ─── Fact vs. inference separation ───────────────────────────────────────────

describe('Fact vs. inference separation', () => {
  test('observed_facts and inferred_behavior are separate fields in match result', () => {
    // These fields must be distinct and non-empty
    const exampleMatch = {
      rule_id:            'RULE-01-A',
      rule_name:          'Repeated failed logins',
      observed_facts:     '5 failed logins for account alice from IP 1.2.3.4 between T1 and T2 UTC',
      inferred_behavior:  'Pattern consistent with brute-force targeting account alice',
      confidence:         'Medium',
      alternative_explanations: ['User forgot password'],
      wording_note:       'This matches a pattern consistent with suspicious activity. It is NOT a confirmed attack or account compromise.',
    };

    expect(exampleMatch.observed_facts).not.toBe(exampleMatch.inferred_behavior);
    expect(exampleMatch.wording_note).not.toMatch(/attack confirmed|account compromised/i);
    expect(exampleMatch.wording_note).toMatch(/NOT a confirmed attack/i);
    expect(exampleMatch.inferred_behavior).toMatch(/consistent with/i);
  });

  test('wording does not use "attack confirmed" or "account compromised"', () => {
    // Verify that the wording_note field in rule outputs uses the correct phrasing
    const exampleWordings = [
      'This matches a pattern consistent with suspicious activity. It is NOT a confirmed attack or account compromise.',
      'Matches pattern consistent with brute-force.',
      'No evidence of an actual compromise; this is a hypothesis.',
    ];
    for (const wording of exampleWordings) {
      expect(wording).not.toMatch(/attack confirmed|account compromised(?! is NOT)/i);
    }
  });
});
