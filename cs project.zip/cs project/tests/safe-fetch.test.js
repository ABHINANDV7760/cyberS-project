/**
 * Tests: IP classification (IPv4, IPv6, mapped, encoded addresses)
 *        and SSRF blocking.
 */

'use strict';

const {
  classifyIP,
  isNonPublicIPv4,
  isNonPublicIPv6,
  validateUrl,
  SafeFetchError,
} = require('../backend/safe-fetch');

// ─── IPv4 classification ──────────────────────────────────────────────────────

describe('isNonPublicIPv4', () => {
  // Loopback
  test('127.0.0.1 is non-public (loopback)', () => expect(isNonPublicIPv4('127.0.0.1')).toBe(true));
  test('127.255.255.255 is non-public (loopback range)', () => expect(isNonPublicIPv4('127.255.255.255')).toBe(true));

  // RFC1918 private
  test('10.0.0.1 is non-public (RFC1918)', ()       => expect(isNonPublicIPv4('10.0.0.1')).toBe(true));
  test('172.16.0.1 is non-public (RFC1918)', ()     => expect(isNonPublicIPv4('172.16.0.1')).toBe(true));
  test('172.31.255.255 is non-public (RFC1918)', () => expect(isNonPublicIPv4('172.31.255.255')).toBe(true));
  test('192.168.1.1 is non-public (RFC1918)', ()    => expect(isNonPublicIPv4('192.168.1.1')).toBe(true));

  // Link-local (includes metadata IP)
  test('169.254.0.0 is non-public (link-local)', ()      => expect(isNonPublicIPv4('169.254.0.0')).toBe(true));
  test('169.254.169.254 is non-public (AWS metadata)', () => expect(isNonPublicIPv4('169.254.169.254')).toBe(true));
  test('169.254.255.255 is non-public (link-local)',()   => expect(isNonPublicIPv4('169.254.255.255')).toBe(true));

  // CGNAT
  test('100.64.0.1 is non-public (CGNAT)', ()   => expect(isNonPublicIPv4('100.64.0.1')).toBe(true));
  test('100.127.255.255 is non-public (CGNAT)', () => expect(isNonPublicIPv4('100.127.255.255')).toBe(true));

  // Multicast
  test('224.0.0.1 is non-public (multicast)', ()   => expect(isNonPublicIPv4('224.0.0.1')).toBe(true));
  test('239.255.255.255 is non-public (multicast)', () => expect(isNonPublicIPv4('239.255.255.255')).toBe(true));

  // Unspecified
  test('0.0.0.0 is non-public', () => expect(isNonPublicIPv4('0.0.0.0')).toBe(true));

  // Documentation ranges
  test('192.0.2.1 is non-public (TEST-NET-1)', ()     => expect(isNonPublicIPv4('192.0.2.1')).toBe(true));
  test('198.51.100.1 is non-public (TEST-NET-2)', ()  => expect(isNonPublicIPv4('198.51.100.1')).toBe(true));
  test('203.0.113.1 is non-public (TEST-NET-3)', ()   => expect(isNonPublicIPv4('203.0.113.1')).toBe(true));

  // Public IPs
  test('1.1.1.1 is public', ()        => expect(isNonPublicIPv4('1.1.1.1')).toBe(false));
  test('8.8.8.8 is public', ()        => expect(isNonPublicIPv4('8.8.8.8')).toBe(false));
  test('93.184.216.34 is public', ()  => expect(isNonPublicIPv4('93.184.216.34')).toBe(false));
  test('172.15.255.255 is public (just below RFC1918)', () => expect(isNonPublicIPv4('172.15.255.255')).toBe(false));
  test('172.32.0.0 is public (just above RFC1918)', ()     => expect(isNonPublicIPv4('172.32.0.0')).toBe(false));
});

// ─── IPv6 classification ──────────────────────────────────────────────────────

describe('isNonPublicIPv6', () => {
  test('::1 is non-public (loopback)',          () => expect(isNonPublicIPv6('::1')).toBe(true));
  test('fe80::1 is non-public (link-local)',    () => expect(isNonPublicIPv6('fe80::1')).toBe(true));
  test('fc00::1 is non-public (ULA)',           () => expect(isNonPublicIPv6('fc00::1')).toBe(true));
  test('fd12:3456::1 is non-public (ULA)',      () => expect(isNonPublicIPv6('fd12:3456::1')).toBe(true));
  test('ff02::1 is non-public (multicast)',     () => expect(isNonPublicIPv6('ff02::1')).toBe(true));
  test(':: is non-public (unspecified)',        () => expect(isNonPublicIPv6('::')).toBe(true));
  // IPv4-mapped
  test('::ffff:127.0.0.1 is non-public (IPv4-mapped loopback)',     () => expect(isNonPublicIPv6('::ffff:127.0.0.1')).toBe(true));
  test('::ffff:192.168.1.1 is non-public (IPv4-mapped RFC1918)',    () => expect(isNonPublicIPv6('::ffff:192.168.1.1')).toBe(true));
  test('::ffff:169.254.169.254 is non-public (IPv4-mapped metadata)', () => expect(isNonPublicIPv6('::ffff:169.254.169.254')).toBe(true));

  // Public
  test('2606:4700:4700::1111 is public (Cloudflare DNS)', () => expect(isNonPublicIPv6('2606:4700:4700::1111')).toBe(false));
  test('2001:4860:4860::8888 is public (Google DNS)',     () => expect(isNonPublicIPv6('2001:4860:4860::8888')).toBe(false));
});

// ─── classifyIP ───────────────────────────────────────────────────────────────

describe('classifyIP', () => {
  test('classifies public IPv4 as public', () => {
    expect(classifyIP('8.8.8.8').isPublic).toBe(true);
  });
  test('classifies private IPv4 as non-public', () => {
    expect(classifyIP('192.168.0.1').isPublic).toBe(false);
  });
  test('provides reason for non-public', () => {
    const { reason } = classifyIP('10.0.0.1');
    expect(reason).toMatch(/non-public/i);
  });
  test('handles bracketed IPv6', () => {
    expect(classifyIP('[::1]').isPublic).toBe(false);
  });
  test('returns false for garbage input', () => {
    expect(classifyIP('not-an-ip').isPublic).toBe(false);
  });
});

// ─── validateUrl ─────────────────────────────────────────────────────────────

describe('validateUrl', () => {
  test('accepts valid https URL', () => {
    expect(validateUrl('https://example.com').ok).toBe(true);
  });
  test('accepts http URL', () => {
    expect(validateUrl('http://example.com').ok).toBe(true);
  });
  test('accepts port 8443', () => {
    expect(validateUrl('https://example.com:8443').ok).toBe(true);
  });
  test('rejects ftp scheme', () => {
    const r = validateUrl('ftp://example.com');
    expect(r.ok).toBe(false);
    expect(r.reason).toMatch(/scheme/i);
  });
  test('rejects URL with embedded credentials', () => {
    const r = validateUrl('https://user:pass@example.com');
    expect(r.ok).toBe(false);
    expect(r.reason).toMatch(/credentials/i);
  });
  test('rejects IPv4 literal host', () => {
    const r = validateUrl('https://1.2.3.4');
    expect(r.ok).toBe(false);
    expect(r.reason).toMatch(/IP-literal/i);
  });
  test('rejects IPv6 literal host', () => {
    const r = validateUrl('https://[::1]');
    expect(r.ok).toBe(false);
    expect(r.reason).toMatch(/IP-literal/i);
  });
  test('rejects non-standard port', () => {
    const r = validateUrl('https://example.com:9999');
    expect(r.ok).toBe(false);
    expect(r.reason).toMatch(/port/i);
  });
  test('rejects URL longer than 2048 chars', () => {
    const r = validateUrl('https://example.com/' + 'a'.repeat(2100));
    expect(r.ok).toBe(false);
  });
  test('rejects unparseable URL', () => {
    const r = validateUrl('not a url');
    expect(r.ok).toBe(false);
  });
});
