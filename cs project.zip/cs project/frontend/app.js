/**
 * Website Security Inspector — frontend application
 *
 * Handles:
 *  - Tab navigation
 *  - Section A: Posture check form, authorization gate, result rendering
 *  - Section B: Log analysis, file upload, Web Worker communication, result rendering
 *  - Export (JSON / CSV / Markdown)
 *  - No eval(); all untrusted values escaped before DOM insertion
 */

'use strict';

// ─── Utility ──────────────────────────────────────────────────────────────────

function esc(str) {
  if (str === null || str === undefined) return '';
  const s = String(str);
  return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#x27;'}[c]));
}

function setText(el, text) {
  if (el) el.textContent = text;
}

function show(el) { if (el) el.hidden = false; }
function hide(el) { if (el) el.hidden = true; }

function setAttr(el, k, v) { if (el) el.setAttribute(k, v); }

function severityIcon(sev) {
  const icons = { Critical:'🔴', High:'🟠', Medium:'🟡', Low:'🔵', Info:'⚪' };
  return icons[sev] || '⚪';
}

function severityClass(sev) {
  return `sev-border-${(sev || 'info').toLowerCase()}`;
}

function sevPill(sev) {
  return `<span class="sev sev-${(sev||'info').toLowerCase()}" aria-label="Severity: ${esc(sev)}">${esc(sev)}</span>`;
}

function confClass(conf) {
  return `conf-${(conf||'low').toLowerCase()}`;
}

// ─── Tab navigation ────────────────────────────────────────────────────────────

const tabs   = document.querySelectorAll('.tab-btn');
const panels = document.querySelectorAll('.tab-panel');

tabs.forEach(tab => {
  tab.addEventListener('click', () => activateTab(tab));
  tab.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight') {
      const next = tab.nextElementSibling;
      if (next) { next.focus(); activateTab(next); }
    } else if (e.key === 'ArrowLeft') {
      const prev = tab.previousElementSibling;
      if (prev) { prev.focus(); activateTab(prev); }
    }
  });
});

function activateTab(tab) {
  tabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); t.tabIndex = -1; });
  panels.forEach(p => p.hidden = true);
  tab.classList.add('active');
  tab.setAttribute('aria-selected', 'true');
  tab.tabIndex = 0;
  const panelId = tab.getAttribute('aria-controls');
  const panel   = document.getElementById(panelId);
  if (panel) panel.hidden = false;
}

// ─── Section A: Posture check ─────────────────────────────────────────────────

const postureForm     = document.getElementById('posture-form');
const targetUrlInput  = document.getElementById('target-url');
const authConfirm     = document.getElementById('auth-confirm');
const authLockedNotice= document.getElementById('auth-locked-notice');
const startScanBtn    = document.getElementById('start-scan-btn');
const cancelScanBtn   = document.getElementById('cancel-scan-btn');
const urlError        = document.getElementById('url-error');
const dkimInput       = document.getElementById('dkim-selector');

const postureProgress = document.getElementById('posture-progress');
const progressBar     = document.getElementById('posture-progress-bar');
const progressMsg     = document.getElementById('posture-progress-msg');
const postureResults  = document.getElementById('posture-results');

let currentAbortController = null;

// Auth gate toggle
authConfirm.addEventListener('change', () => {
  const authorized = authConfirm.checked;
  authLockedNotice.textContent = authorized
    ? '✅ Active checks are enabled. Authorization confirmation logged with timestamp.'
    : '🔒 Active checks are locked until you confirm authorization above.';
  authLockedNotice.classList.toggle('unlocked', authorized);
  startScanBtn.textContent = authorized ? 'Run Full Check (Tier 0 + 1)' : 'Run Passive Checks';
});

// Form submit
postureForm.addEventListener('submit', async e => {
  e.preventDefault();
  await runPostureCheck();
});

cancelScanBtn?.addEventListener('click', () => {
  if (currentAbortController) currentAbortController.abort();
  hide(postureProgress);
  show(startScanBtn);
});

async function runPostureCheck() {
  const rawUrl    = targetUrlInput.value.trim();
  const authorized= authConfirm.checked;
  const dkim      = dkimInput.value.trim() || null;

  // Client-side URL validation (defence in depth)
  if (!rawUrl) {
    showUrlError('Please enter a URL.');
    return;
  }
  if (!/^https?:\/\//i.test(rawUrl)) {
    showUrlError('URL must start with http:// or https://');
    return;
  }
  clearUrlError();

  // Show progress
  hide(postureResults);
  show(postureProgress);
  setProgress(10, 'Sending to server…');
  startScanBtn.disabled = true;

  currentAbortController = new AbortController();

  try {
    const resp = await fetch('/api/posture-check', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ target: rawUrl, authorized, dkimSelector: dkim }),
      signal:  currentAbortController.signal,
    });

    setProgress(80, 'Processing results…');

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({ error: 'Unknown error' }));
      showUrlError(err.error || `Server error: ${resp.status}`);
      hide(postureProgress);
      return;
    }

    const report = await resp.json();
    setProgress(100, 'Done');

    setTimeout(() => {
      hide(postureProgress);
      renderPostureReport(report);
      show(postureResults);
      postureResults.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 400);

  } catch (err) {
    if (err.name === 'AbortError') return;
    showUrlError('Request failed: ' + esc(err.message));
    hide(postureProgress);
  } finally {
    startScanBtn.disabled = false;
  }
}

function setProgress(pct, msg) {
  progressBar.style.width = pct + '%';
  progressBar.parentElement.setAttribute('aria-valuenow', pct);
  setText(progressMsg, msg);
}

function showUrlError(msg) {
  urlError.textContent = msg;
  show(urlError);
  targetUrlInput.setAttribute('aria-invalid', 'true');
}
function clearUrlError() {
  hide(urlError);
  targetUrlInput.removeAttribute('aria-invalid');
}

// ─── Report rendering ─────────────────────────────────────────────────────────

let currentReport = null;

function renderPostureReport(report) {
  currentReport = report;

  // Report meta
  const metaEl = document.getElementById('report-meta');
  if (metaEl) {
    metaEl.textContent = [
      `Target: ${report.hostname}`,
      `Scanned: ${report.reportTimestamp}`,
      report.authorized ? `Authorized (Tier 0+1)` : 'Passive only (Tier 0)',
      report.requestBudget ? `Requests: ${report.requestBudget.used}/${report.requestBudget.max}` : '',
    ].filter(Boolean).join(' · ');
  }

  // Summary pills
  const summaryEl = document.getElementById('findings-summary');
  if (summaryEl) {
    const counts = { Critical: 0, High: 0, Medium: 0, Low: 0, Info: 0 };
    for (const c of (report.checks || [])) {
      counts[c.severity] = (counts[c.severity] || 0) + 1;
    }
    summaryEl.innerHTML = Object.entries(counts)
      .filter(([, v]) => v > 0)
      .map(([sev, count]) =>
        `<div class="summary-pill pill-${sev.toLowerCase()}" role="img" aria-label="${count} ${esc(sev)} findings">
          <span aria-hidden="true">${severityIcon(sev)}</span>
          <span>${count} ${esc(sev)}</span>
        </div>`
      ).join('');
  }

  // Findings list
  const listEl = document.getElementById('findings-list');
  if (listEl) {
    const checks = (report.checks || []).sort(sortBySeverity);
    if (checks.length === 0) {
      listEl.innerHTML = '<p>No findings returned.</p>';
    } else {
      listEl.innerHTML = checks.map(renderFindingCard).join('');
    }
  }

  // DNS section
  if (report.dnsRecords) {
    const dnsSection = document.getElementById('dns-section');
    const dnsBody    = document.getElementById('dns-records-body');
    if (dnsBody) dnsBody.innerHTML = renderDnsRecords(report.dnsRecords);
    show(dnsSection);
  }

  // Skipped checks
  const skippedEl   = document.getElementById('skipped-checks');
  const skippedList = document.getElementById('skipped-list');
  if (skippedList && report.skipped?.length > 0) {
    skippedList.innerHTML = report.skipped.map(s =>
      `<li class="skipped-item">
        <span class="tier-tag">Tier ${s.tier ?? '?'}</span>
        <span><strong>${esc(s.check)}</strong>: ${esc(s.reason)}</span>
      </li>`
    ).join('');
    show(skippedEl);
  }

  // Export handlers
  document.getElementById('export-json-btn')?.addEventListener('click', () => exportReport('json'));
  document.getElementById('export-csv-btn')?.addEventListener('click',  () => exportReport('csv'));
  document.getElementById('export-md-btn')?.addEventListener('click',   () => exportReport('markdown'));
}

function renderFindingCard(c) {
  const evidenceStr = c.evidence
    ? (typeof c.evidence === 'object' ? JSON.stringify(c.evidence, null, 2) : String(c.evidence))
    : null;

  return `<div class="finding-card ${severityClass(c.severity)}" role="article" aria-label="${esc(c.name)}: ${esc(c.issue)}">
    <div class="finding-header">
      <span aria-hidden="true">${severityIcon(c.severity)}</span>
      ${sevPill(c.severity)}
      <span class="finding-name">${esc(c.name)}</span>
      ${c.tier !== undefined ? `<span class="tier-badge tier-${c.tier}" title="Tier ${c.tier} check">T${c.tier}</span>` : ''}
    </div>
    <div class="finding-issue">${esc(c.issue)}</div>
    <div class="finding-meta">
      ${c.confidence ? `<span>Confidence: <strong>${esc(c.confidence)}</strong></span>` : ''}
      ${c.timestamp  ? `<span>Checked: ${esc(c.timestamp)}</span>` : ''}
    </div>
    ${evidenceStr ? `<pre class="finding-evidence" aria-label="Evidence">${esc(evidenceStr)}</pre>` : ''}
    ${c.remediation ? `<div class="finding-remediation" role="note"><strong>Remediation:</strong> ${esc(c.remediation)}</div>` : ''}
  </div>`;
}

function renderDnsRecords(dns) {
  const types = ['A', 'AAAA', 'NS', 'MX', 'TXT', 'CAA', 'DNSSEC'];
  return types.map(type => {
    const data = dns[type];
    if (!data) return '';
    let content = '';
    if (type === 'DNSSEC') {
      content = esc(data.note || '');
    } else if (data.absent) {
      content = '<em>Record absent</em>';
    } else if (data.error) {
      content = `<span class="form-error">Lookup error: ${esc(data.error)}</span>`;
    } else if (!data.records?.length) {
      content = '<em>No records returned</em>';
    } else {
      content = data.records.map(r =>
        `<div class="dns-record">${esc(typeof r === 'object' ? JSON.stringify(r) : r)}</div>`
      ).join('');
    }
    return `<div class="dns-type">
      <div class="dns-type-label">${esc(type)}</div>
      ${content}
    </div>`;
  }).join('');
}

function sortBySeverity(a, b) {
  const order = { Critical: 0, High: 1, Medium: 2, Low: 3, Info: 4 };
  return (order[a.severity] ?? 5) - (order[b.severity] ?? 5);
}

// ─── Export ────────────────────────────────────────────────────────────────────

function exportReport(format) {
  if (!currentReport) return;
  let content, mime, ext;

  if (format === 'json') {
    content = JSON.stringify(currentReport, null, 2);
    mime    = 'application/json';
    ext     = 'json';
  } else if (format === 'csv') {
    const rows = [['severity','tier','name','issue','confidence','timestamp','evidence','remediation']];
    for (const c of currentReport.checks || []) {
      rows.push([
        c.severity, c.tier ?? '', c.name, c.issue, c.confidence ?? '',
        c.timestamp ?? '', JSON.stringify(c.evidence ?? ''), c.remediation ?? '',
      ].map(v => `"${String(v).replace(/"/g, '""')}"`));
    }
    content = rows.map(r => r.join(',')).join('\n');
    mime    = 'text/csv';
    ext     = 'csv';
  } else {
    const md = [`# Security Posture Report`, `**Target:** ${currentReport.hostname}`, `**Scanned:** ${currentReport.reportTimestamp}`, '', `## Findings`, ''];
    for (const c of (currentReport.checks || []).sort(sortBySeverity)) {
      md.push(`### ${c.severity}: ${c.name}`);
      md.push(c.issue);
      if (c.evidence) md.push(`\`\`\`\n${JSON.stringify(c.evidence, null, 2)}\n\`\`\``);
      if (c.remediation) md.push(`**Remediation:** ${c.remediation}`);
      md.push('');
    }
    md.push('---');
    md.push('> ' + (currentReport.persistentNotice || ''));
    content = md.join('\n');
    mime    = 'text/markdown';
    ext     = 'md';
  }

  downloadBlob(content, mime, `posture-report-${currentReport.hostname}-${Date.now()}.${ext}`);
}

function downloadBlob(content, mime, filename) {
  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ─── Section B: Log analysis ──────────────────────────────────────────────────

const logAuthConfirm = document.getElementById('log-auth-confirm');
const uploadBtn      = document.getElementById('upload-btn');
const loadSampleBtn  = document.getElementById('load-sample-btn');
const logFileInput   = document.getElementById('log-file-input');
const uploadArea     = document.getElementById('upload-area');
const columnMapArea  = document.getElementById('column-map-area');
const pseudoRow      = document.getElementById('pseudo-row');
const pseudoToggle   = document.getElementById('pseudo-toggle');
const thresholdConfig= document.getElementById('threshold-config');
const thresholdGrid  = document.getElementById('threshold-grid');
const logProgress    = document.getElementById('log-progress');
const logProgressBar = document.getElementById('log-progress-bar');
const logProgressMsg = document.getElementById('log-progress-msg');
const logResults     = document.getElementById('log-results');
const cancelLogBtn   = document.getElementById('cancel-log-btn');
const closeDrawerBtn = document.getElementById('close-drawer-btn');
const recordDrawer   = document.getElementById('record-drawer');

let logWorker    = null;
let parsedRecords= [];
let ruleMatches  = [];
let parsedStats  = null;
let currentFile  = null;

// Auth gate
logAuthConfirm?.addEventListener('change', () => {
  const ok = logAuthConfirm.checked;
  uploadBtn.disabled    = !ok;
  loadSampleBtn.disabled= !ok;
  logFileInput.disabled = !ok;
  uploadBtn.setAttribute('aria-disabled', String(!ok));
  loadSampleBtn.setAttribute('aria-disabled', String(!ok));
});

// Upload button
uploadBtn?.addEventListener('click', () => logFileInput.click());

logFileInput?.addEventListener('change', e => {
  const file = e.target.files?.[0];
  if (file) handleFileUpload(file);
});

// Drag-and-drop
uploadArea?.addEventListener('dragover', e => { e.preventDefault(); uploadArea.classList.add('drag-over'); });
uploadArea?.addEventListener('dragleave', () => uploadArea.classList.remove('drag-over'));
uploadArea?.addEventListener('drop', e => {
  e.preventDefault();
  uploadArea.classList.remove('drag-over');
  if (!logAuthConfirm.checked) return;
  const file = e.dataTransfer.files?.[0];
  if (file) handleFileUpload(file);
});

// Load sample log
loadSampleBtn?.addEventListener('click', async () => {
  const resp = await fetch('/fixtures/sample-auth.log.csv');
  const text = await resp.text();
  currentFile = { text, name: 'sample-auth.log.csv (SYNTHETIC)' };
  showColumnMapping(text, 'csv', 'sample-auth.log.csv');
});

// Close drawer
closeDrawerBtn?.addEventListener('click', () => {
  hide(recordDrawer);
  recordDrawer.removeAttribute('open');
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !recordDrawer.hidden) {
    hide(recordDrawer);
    closeDrawerBtn?.focus();
  }
});

// Cancel log analysis
cancelLogBtn?.addEventListener('click', () => {
  logWorker?.terminate();
  logWorker = null;
  hide(logProgress);
});

function handleFileUpload(file) {
  if (file.size > 100 * 1024 * 1024) {
    alert('File exceeds 100 MB limit.');
    return;
  }
  const reader = new FileReader();
  reader.onload = e => {
    currentFile = { text: e.target.result, name: file.name };
    const format = detectFormat(file.name, e.target.result);
    showColumnMapping(e.target.result, format, file.name);
  };
  reader.readAsText(file);
}

function detectFormat(name, text) {
  if (name.endsWith('.csv')) return 'csv';
  if (name.endsWith('.json')) return 'json';
  if (name.endsWith('.ndjson')) return 'ndjson';
  const first = text.slice(0, 200);
  if (first.trimStart().startsWith('{') || first.trimStart().startsWith('[')) return 'json';
  return 'syslog';
}

function showColumnMapping(text, format, filename) {
  show(columnMapArea);
  show(pseudoRow);
  show(thresholdConfig);
  buildThresholdUI();

  const fieldsEl = document.getElementById('column-map-fields');
  if (!fieldsEl) return;

  const expectedFields = ['timestamp', 'account_id', 'source_ip', 'user_agent', 'outcome', 'event_type'];

  // For CSV, show header columns as hints
  let detectedCols = [];
  if (format === 'csv') {
    const firstLine = text.split('\n')[0];
    detectedCols = firstLine.split(',').map(c => c.trim());
  }

  fieldsEl.innerHTML = expectedFields.map((field, i) => {
    const hint = detectedCols[i] ? ` (detected: ${esc(detectedCols[i])})` : '';
    return `<div class="column-map-field threshold-field">
      <label for="col-${field}">${esc(field)}${hint}</label>
      <input type="text" id="col-${field}" name="${field}" value="${i}" placeholder="column index or name" aria-label="Column for ${esc(field)}">
    </div>`;
  }).join('');

  // Run analysis button
  const runBtn = document.getElementById('run-analysis-btn');
  runBtn.onclick = () => startLogAnalysis(text, format, filename);
}

function buildThresholdUI() {
  if (!thresholdGrid) return;
  if (thresholdGrid.innerHTML) return; // already built

  const defaults = {
    failedLoginN:            { label: 'Failed login threshold (N per account/IP)', default: 5 },
    failedLoginWindowM:      { label: 'Failed login window (minutes)',              default: 10 },
    successAfterFailN:       { label: 'Failures before suspicious success (N)',     default: 3 },
    successAfterFailWindowM: { label: 'Success-after-fail window (minutes)',        default: 15 },
    unusualFreqRatePerHour:  { label: 'Unusual frequency rate (logins/hour)',       default: 30 },
    sprayDistinctAccounts:   { label: 'Spray: distinct accounts from one IP (N)',   default: 5 },
    sprayWindowM:            { label: 'Spray window (minutes)',                     default: 5 },
    multiAccountSuccessN:    { label: 'Multi-account success from one IP (N)',      default: 4 },
    multiAccountWindowM:     { label: 'Multi-account success window (minutes)',     default: 10 },
    baselineMinDays:         { label: 'Baseline: minimum days of data',             default: 14 },
    baselineMinEvents:       { label: 'Baseline: minimum events per account',       default: 20 },
  };

  thresholdGrid.innerHTML = Object.entries(defaults).map(([key, cfg]) =>
    `<div class="threshold-field">
      <label for="t-${key}">${esc(cfg.label)}</label>
      <input type="number" id="t-${key}" name="${key}" value="${cfg.default}" min="1" aria-label="${esc(cfg.label)}">
    </div>`
  ).join('');
}

function getThresholds() {
  const keys = ['failedLoginN','failedLoginWindowM','successAfterFailN','successAfterFailWindowM',
    'unusualFreqRatePerHour','sprayDistinctAccounts','sprayWindowM','multiAccountSuccessN',
    'multiAccountWindowM','baselineMinDays','baselineMinEvents'];
  const t = {};
  for (const k of keys) {
    const el = document.getElementById(`t-${k}`);
    if (el) t[k] = parseInt(el.value, 10) || undefined;
  }
  return t;
}

function getColumnMap() {
  const fields = ['timestamp','account_id','source_ip','user_agent','outcome','event_type'];
  const map = {};
  for (const f of fields) {
    const el = document.getElementById(`col-${f}`);
    if (el && el.value.trim() !== '') {
      const v = el.value.trim();
      map[f] = isNaN(v) ? v : parseInt(v, 10);
    }
  }
  return map;
}

function startLogAnalysis(text, format, filename) {
  if (logWorker) { logWorker.terminate(); logWorker = null; }

  hide(logResults);
  show(logProgress);
  setLogProgress(0, 'Starting analysis…');

  const pseudonymize = pseudoToggle?.checked || false;
  const salt         = pseudonymize ? Math.random().toString(36).slice(2) : '';
  const thresholds   = getThresholds();
  const columnMap    = getColumnMap();

  logWorker = new Worker('/log-worker.js');

  logWorker.onmessage = e => {
    const { type, payload } = e.data;
    if (type === 'PROGRESS') {
      setLogProgress(payload.pct, payload.message);
    } else if (type === 'PARSE_RESULT') {
      parsedRecords = payload.records;
      parsedStats   = payload.stats;
      if (payload.errors?.length) renderParseErrors(payload.errors);
    } else if (type === 'RULE_RESULT') {
      ruleMatches = payload.matches;
      hide(logProgress);
      renderLogResults(parsedStats, ruleMatches, payload.thresholds);
      show(logResults);
      logResults.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else if (type === 'ERROR') {
      setLogProgress(0, 'Error: ' + payload.message);
      setTimeout(() => hide(logProgress), 2000);
    }
  };

  logWorker.postMessage({
    type: 'PARSE',
    payload: { text, filename, format, columnMap, pseudonymize, salt, thresholds },
  });
}

function setLogProgress(pct, msg) {
  logProgressBar.style.width = pct + '%';
  logProgressBar.parentElement.setAttribute('aria-valuenow', pct);
  setText(logProgressMsg, msg);
}

function renderParseErrors(errors) {
  const section = document.getElementById('parse-errors-section');
  const list    = document.getElementById('parse-errors-list');
  if (!list || !section) return;
  list.innerHTML = errors.slice(0, 50).map(e =>
    `<li>Line ${esc(e.lineNumber)}: ${esc(e.message)}</li>`
  ).join('');
  if (errors.length > 50) list.innerHTML += `<li>… and ${errors.length - 50} more</li>`;
  show(section);
}

// ─── Log results rendering ────────────────────────────────────────────────────

function renderLogResults(stats, matches, thresholds) {
  // Stats
  const statsEl = document.getElementById('log-stats');
  if (statsEl && stats) {
    statsEl.innerHTML = [
      `<div class="stat-pill">Records: <strong>${stats.totalRecords}</strong></div>`,
      `<div class="stat-pill">Successes: <strong>${stats.outcomes?.success || 0}</strong></div>`,
      `<div class="stat-pill">Failures: <strong>${stats.outcomes?.failure || 0}</strong></div>`,
      `<div class="stat-pill">Accounts: <strong>${stats.distinctAccounts}</strong></div>`,
      `<div class="stat-pill">IPs: <strong>${stats.distinctIps}</strong></div>`,
      stats.earliest ? `<div class="stat-pill">From: <strong>${esc(stats.earliest)}</strong></div>` : '',
      stats.latest   ? `<div class="stat-pill">To: <strong>${esc(stats.latest)}</strong></div>` : '',
      stats.parseErrors ? `<div class="stat-pill">Parse warnings: <strong>${stats.parseErrors}</strong></div>` : '',
    ].join('');
  }

  // Timeline (simple SVG-free dot representation)
  renderTimeline(parsedRecords);

  // Rule filter dropdown
  const filterSelect = document.getElementById('filter-rule');
  if (filterSelect) {
    const ruleIds = [...new Set(matches.map(m => m.rule_id))];
    filterSelect.innerHTML = '<option value="">All rules</option>' +
      ruleIds.map(id => {
        const name = matches.find(m => m.rule_id === id)?.rule_name || id;
        return `<option value="${esc(id)}">${esc(id)}: ${esc(name)}</option>`;
      }).join('');
    filterSelect.onchange = () => renderMatchesTable(getFilteredMatches());
  }

  const sortSelect = document.getElementById('sort-matches');
  if (sortSelect) sortSelect.onchange = () => renderMatchesTable(getFilteredMatches());

  renderMatchesTable(matches);

  // Export handlers
  document.getElementById('log-export-json-btn')?.addEventListener('click', () => exportLogReport('json'));
  document.getElementById('log-export-csv-btn')?.addEventListener('click',  () => exportLogReport('csv'));
  document.getElementById('log-export-md-btn')?.addEventListener('click',   () => exportLogReport('markdown'));
  document.getElementById('clear-logs-btn')?.addEventListener('click', clearLogs);
}

function renderTimeline(records) {
  const timelineEl = document.getElementById('log-timeline');
  if (!timelineEl || !records.length) return;

  const withTs = records.filter(r => r.timestamp_utc).sort((a,b) => a.timestamp_utc > b.timestamp_utc ? 1 : -1);
  if (withTs.length < 2) return;

  const minT = new Date(withTs[0].timestamp_utc).getTime();
  const maxT = new Date(withTs[withTs.length-1].timestamp_utc).getTime();
  const span = maxT - minT || 1;

  timelineEl.innerHTML = '';
  // Plot every record as a dot (cap at 500 for performance)
  for (const r of withTs.slice(0, 500)) {
    const t   = new Date(r.timestamp_utc).getTime();
    const pct = ((t - minT) / span) * 100;
    const dot = document.createElement('div');
    dot.className = `timeline-dot ${r.outcome}`;
    dot.style.left  = pct + '%';
    dot.style.top   = '50%';
    dot.title       = `${r.outcome} · ${r.account_id} · ${r.timestamp_utc}`;
    dot.setAttribute('aria-label', `${r.outcome} login at ${r.timestamp_utc}`);
    timelineEl.appendChild(dot);
  }
}

function getFilteredMatches() {
  const ruleFilter = document.getElementById('filter-rule')?.value || '';
  const sortBy     = document.getElementById('sort-matches')?.value || 'time';

  let filtered = ruleMatches;
  if (ruleFilter) filtered = filtered.filter(m => m.rule_id === ruleFilter);

  filtered = [...filtered].sort((a, b) => {
    if (sortBy === 'rule')    return a.rule_id.localeCompare(b.rule_id);
    if (sortBy === 'account') return (a.account_id || '').localeCompare(b.account_id || '');
    // default: time (use match_id as proxy)
    return a.match_id.localeCompare(b.match_id);
  });

  return filtered;
}

function renderMatchesTable(matches) {
  const tbody = document.getElementById('matches-tbody');
  if (!tbody) return;

  if (!matches.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--text-muted); padding:1.5rem">No rule matches found.</td></tr>`;
    return;
  }

  tbody.innerHTML = matches.map((m, idx) => `
    <tr>
      <td><strong>${esc(m.rule_id)}</strong><br><small>${esc(m.rule_name)}</small></td>
      <td>${m.account_id ? esc(m.account_id) : '<em>N/A</em>'}</td>
      <td>${m.source_ip  ? esc(m.source_ip)  : '<em>N/A</em>'}</td>
      <td><span class="${confClass(m.confidence)}">${esc(m.confidence)}</span></td>
      <td><small>${esc(m.observed_facts?.slice(0, 80) || '')}…</small></td>
      <td><button class="btn btn-sm btn-outline match-details-btn" type="button" data-match-idx="${idx}" aria-label="View details for match ${esc(m.rule_id)}">Details</button></td>
    </tr>`).join('');

  tbody.querySelectorAll('.match-details-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.matchIdx, 10);
      openMatchDrawer(getFilteredMatches()[idx]);
    });
  });
}

function openMatchDrawer(match) {
  const drawerBody  = document.getElementById('drawer-body');
  const drawerTitle = document.getElementById('drawer-title');
  if (!drawerBody || !match) return;

  setText(drawerTitle, `${match.rule_id}: ${match.rule_name}`);

  drawerBody.innerHTML = `
    <div class="drawer-section">
      <h5>Observed Facts</h5>
      <div class="fact-block" role="note">${esc(match.observed_facts)}</div>
    </div>
    <div class="drawer-section">
      <h5>Inferred Suspicious Behavior (hypothesis — not proof)</h5>
      <div class="inference-block" role="note">${esc(match.inferred_behavior)}</div>
      <p style="font-size:0.82rem;color:var(--text-muted);margin-top:0.4rem"><strong>Alternative explanations:</strong> ${esc((match.alternative_explanations||[]).join(' · '))}</p>
      <p style="font-size:0.82rem;font-style:italic;margin-top:0.3rem">${esc(match.wording_note)}</p>
    </div>
    <div class="drawer-section">
      <h5>Recommended Next Steps (for administrators)</h5>
      <ul style="font-size:0.82rem;padding-left:1rem">${(match.recommended_next_steps||[]).map(s=>`<li>${esc(s)}</li>`).join('')}</ul>
    </div>
    <div class="drawer-section">
      <h5>Rule Parameters</h5>
      <pre class="drawer-raw">${esc(JSON.stringify(match.params, null, 2))}</pre>
    </div>
    <div class="drawer-section">
      <h5>Supporting Log Records</h5>
      ${renderSupportingRecords(match.supporting_record_ids)}
    </div>`;

  show(recordDrawer);
  recordDrawer.focus();
}

function renderSupportingRecords(ids) {
  if (!ids?.length) return '<em>No record IDs.</em>';
  const records = parsedRecords.filter(r => ids.includes(r.record_id));
  if (!records.length) return `<em>${ids.length} record IDs (records cleared from memory).</em>`;
  return records.map(r => `
    <div style="margin-bottom:0.6rem; border:1px solid var(--border); border-radius:4px; padding:0.5rem 0.75rem">
      <div style="font-size:0.8rem;color:var(--text-muted)">
        ${esc(r.source_file)} line ${esc(r.line_number)} · ${esc(r.timestamp_utc || 'no timestamp')}
        ${r.tz_ambiguous ? '<span style="color:orange" title="Timezone may be ambiguous">⚠️ TZ</span>' : ''}
      </div>
      <div style="font-size:0.85rem">
        <strong>Account:</strong> ${esc(r.account_id)} ·
        <strong>IP:</strong> ${esc(r.source_ip || 'N/A')} ·
        <strong>Outcome:</strong> ${esc(r.outcome)}
      </div>
      <pre class="drawer-raw" aria-label="Escaped raw log entry">${esc(r.raw_line)}</pre>
    </div>`).join('');
}

function clearLogs() {
  parsedRecords = [];
  ruleMatches   = [];
  parsedStats   = null;
  currentFile   = null;
  hide(logResults);
  hide(columnMapArea);
  hide(pseudoRow);
  hide(thresholdConfig);
  if (logWorker) { logWorker.terminate(); logWorker = null; }
  hide(recordDrawer);
  logFileInput.value = '';
}

// ─── Log export ───────────────────────────────────────────────────────────────

function exportLogReport(format) {
  if (!ruleMatches.length) return;
  let content, mime, ext;

  const report = {
    generated:    new Date().toISOString(),
    stats:        parsedStats,
    thresholds:   getThresholds(),
    matchCount:   ruleMatches.length,
    dataQualityNote: 'Results depend on log completeness, accuracy, and sanitization.',
    matches:      ruleMatches.map(m => ({
      rule_id:               m.rule_id,
      rule_name:             m.rule_name,
      observed_facts:        m.observed_facts,
      inferred_behavior:     m.inferred_behavior,
      confidence:            m.confidence,
      alternative_explanations: m.alternative_explanations,
      account_id:            m.account_id,
      source_ip:             m.source_ip,
      params:                m.params,
    })),
  };

  if (format === 'json') {
    content = JSON.stringify(report, null, 2);
    mime    = 'application/json';
    ext     = 'json';
  } else if (format === 'csv') {
    const rows = [['rule_id','rule_name','confidence','account_id','source_ip','observed_facts','inferred_behavior']];
    for (const m of ruleMatches) {
      rows.push([m.rule_id, m.rule_name, m.confidence, m.account_id||'', m.source_ip||'', m.observed_facts, m.inferred_behavior]
        .map(v => `"${String(v).replace(/"/g, '""')}"`));
    }
    content = rows.map(r => r.join(',')).join('\n');
    mime    = 'text/csv';
    ext     = 'csv';
  } else {
    const md = ['# Authentication Log Analysis Findings', `Generated: ${report.generated}`, ''];
    for (const m of ruleMatches) {
      md.push(`## ${m.rule_id}: ${m.rule_name}`);
      md.push(`**Confidence:** ${m.confidence}`);
      md.push(`\n**Observed Facts:**\n${m.observed_facts}`);
      md.push(`\n**Inferred Behavior (hypothesis):**\n${m.inferred_behavior}`);
      md.push(`\n**Alternative Explanations:** ${(m.alternative_explanations||[]).join('; ')}`);
      md.push('');
    }
    md.push('---');
    md.push('> Results depend on log completeness. Matches are patterns, not confirmed attacks.');
    content = md.join('\n');
    mime    = 'text/markdown';
    ext     = 'md';
  }

  downloadBlob(content, mime, `log-findings-${Date.now()}.${ext}`);
}

// ─── Load sample fixture for demo ────────────────────────────────────────────

// Provide fixture sample log via inline fetch to /fixtures/sample-auth.log.csv
// The server must serve the fixtures/ directory statically, or we serve it from a data URL.
// Since Express serves only frontend/ as static, we embed a tiny sample inline:
const SAMPLE_LOG_CSV = `timestamp,account_id,source_ip,user_agent,outcome,event_type
2024-01-15T02:10:01Z,alice@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:10:15Z,alice@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:10:29Z,alice@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:10:43Z,alice@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:10:57Z,alice@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:11:14Z,alice@example.com,198.51.100.77,Mozilla/5.0,success,login
2024-01-15T02:15:00Z,bob@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:15:05Z,carol@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:15:10Z,dave@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:15:15Z,eve@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T02:15:20Z,frank@example.com,198.51.100.77,Mozilla/5.0,failure,login
2024-01-15T09:00:00Z,grace@example.com,203.0.113.10,Chrome/120.0,success,login
2024-01-15T14:00:00Z,alice@example.com,203.0.113.50,Firefox/121.0,success,login`;

loadSampleBtn?.addEventListener('click', () => {
  if (!logAuthConfirm?.checked) return;
  currentFile = { text: SAMPLE_LOG_CSV, name: 'SYNTHETIC sample-auth.log.csv' };
  showColumnMapping(SAMPLE_LOG_CSV, 'csv', 'SYNTHETIC sample-auth.log.csv');
});
// Remove duplicate listener if any (override the earlier one that tried to fetch)
