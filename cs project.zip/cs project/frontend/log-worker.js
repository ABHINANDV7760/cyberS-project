/**
 * Log Analysis Web Worker
 *
 * Runs entirely in the browser. Logs never leave the machine.
 * Receives:
 *   { type: 'PARSE', payload: { text, filename, format, columnMap, pseudonymize, salt } }
 *   { type: 'CANCEL' }
 *
 * Posts back:
 *   { type: 'PROGRESS', payload: { pct, message } }
 *   { type: 'PARSE_RESULT', payload: { records, errors, stats } }
 *   { type: 'RULE_RESULT', payload: { matches } }
 *   { type: 'ERROR', payload: { message } }
 */

'use strict';

let cancelled = false;

self.onmessage = function(event) {
  const { type, payload } = event.data;
  if (type === 'CANCEL') {
    cancelled = true;
    return;
  }
  if (type === 'PARSE') {
    cancelled = false;
    runAnalysis(payload).catch(err => {
      self.postMessage({ type: 'ERROR', payload: { message: err.message } });
    });
  }
};

// ─── Constants ────────────────────────────────────────────────────────────────

const FILE_SIZE_CAP  = 100 * 1024 * 1024; // 100 MB
const ROW_COUNT_CAP  = 500_000;
const CHUNK_SIZE     = 1000; // rows per processing chunk

// ─── Main analysis pipeline ───────────────────────────────────────────────────

async function runAnalysis({ text, filename, format, columnMap, pseudonymize, salt, thresholds }) {
  if (text.length > FILE_SIZE_CAP) {
    throw new Error(`File exceeds size cap of ${FILE_SIZE_CAP / 1024 / 1024} MB`);
  }

  self.postMessage({ type: 'PROGRESS', payload: { pct: 5, message: 'Parsing log file…' } });

  // Parse
  const { records, errors } = parseLog(text, filename, format, columnMap);

  self.postMessage({ type: 'PROGRESS', payload: { pct: 40, message: `Parsed ${records.length} records, ${errors.length} errors` } });

  if (records.length > ROW_COUNT_CAP) {
    throw new Error(`Record count (${records.length}) exceeds cap of ${ROW_COUNT_CAP}`);
  }

  if (cancelled) return;

  // Pseudonymize if requested
  const processedRecords = pseudonymize ? pseudonymizeRecords(records, salt) : records;

  self.postMessage({ type: 'PROGRESS', payload: { pct: 60, message: 'Running detection rules…' } });

  // Run detection rules
  const effectiveThresholds = Object.assign(defaultThresholds(), thresholds || {});
  const matches = runRules(processedRecords, effectiveThresholds);

  self.postMessage({ type: 'PROGRESS', payload: { pct: 90, message: 'Preparing results…' } });

  const stats = computeStats(processedRecords, errors);

  self.postMessage({ type: 'PARSE_RESULT', payload: { records: processedRecords, errors, stats } });
  self.postMessage({ type: 'RULE_RESULT',  payload: { matches, thresholds: effectiveThresholds } });
  self.postMessage({ type: 'PROGRESS',     payload: { pct: 100, message: 'Done' } });
}

// ─── Thresholds ───────────────────────────────────────────────────────────────

function defaultThresholds() {
  return {
    failedLoginN:        5,      // failures per account/IP
    failedLoginWindowM:  10,     // minutes
    successAfterFailN:   3,      // failures before suspicious success
    successAfterFailWindowM: 15,
    unusualFreqRatePerHour: 30,
    sprayDistinctAccounts:  5,   // distinct accounts from one IP
    sprayWindowM:           5,
    multiAccountSuccessN:   4,   // one IP succeeds on N accounts
    multiAccountWindowM:    10,
    baselineMinDays:        14,
    baselineMinEvents:      20,
  };
}

// ─── Log parser ───────────────────────────────────────────────────────────────

function parseLog(text, filename, format, columnMap) {
  const lines   = text.split(/\r?\n/);
  const records = [];
  const errors  = [];
  let recId     = 0;

  const effectiveFormat = format || detectFormat(text);

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (records.length >= ROW_COUNT_CAP) {
      errors.push({ lineNumber: i + 1, message: 'Row cap reached; remaining lines skipped' });
      break;
    }

    try {
      const entry = parseLine(line, effectiveFormat, columnMap, i + 1, filename, recId);
      if (entry) {
        records.push(entry);
        recId++;
      }
    } catch (e) {
      errors.push({ lineNumber: i + 1, message: e.message, rawLine: escapeHtml(line.slice(0, 200)) });
    }
  }

  return { records, errors };
}

function detectFormat(text) {
  const first = text.slice(0, 500);
  if (/^timestamp[,;|\t]/i.test(first)) return 'csv';
  if (first.trimStart().startsWith('{') || first.trimStart().startsWith('[')) return 'json';
  if (/\w+=\S+/.test(first)) return 'kv';
  return 'syslog';
}

function parseLine(line, format, columnMap, lineNumber, filename, recId) {
  let raw = {};

  switch (format) {
    case 'csv': {
      // Header line
      if (lineNumber === 1 && /timestamp|account|outcome/i.test(line)) return null;
      const cols = line.split(',').map(c => c.trim());
      const map  = columnMap || { timestamp: 0, account_id: 1, source_ip: 2, user_agent: 3, outcome: 4, event_type: 5 };
      for (const [key, idx] of Object.entries(map)) {
        raw[key] = cols[idx] !== undefined ? cols[idx] : '';
      }
      break;
    }
    case 'json':
    case 'ndjson': {
      raw = JSON.parse(line);
      if (columnMap) {
        const mapped = {};
        for (const [to, from] of Object.entries(columnMap)) {
          mapped[to] = raw[from];
        }
        raw = mapped;
      }
      break;
    }
    case 'kv': {
      for (const match of line.matchAll(/(\w+)=("([^"]*)"|(\S+))/g)) {
        raw[match[1]] = match[3] !== undefined ? match[3] : match[4];
      }
      break;
    }
    case 'syslog': {
      // Generic: Jan 15 02:10:01 host sshd[1234]: Accepted/Failed password for USER from IP
      const syslogRe = /^(\w{3}\s+\d+\s+\d+:\d+:\d+)\s+\S+\s+\S+:\s+(Accepted|Failed)\s+\S+\s+for\s+(\S+)\s+from\s+(\S+)/i;
      const m = syslogRe.exec(line);
      if (m) {
        raw = {
          timestamp:  m[1],
          outcome:    m[2].toLowerCase() === 'accepted' ? 'success' : 'failure',
          account_id: m[3],
          source_ip:  m[4],
          event_type: 'login',
        };
      } else {
        throw new Error(`Could not parse syslog line`);
      }
      break;
    }
    default:
      throw new Error(`Unknown format: ${format}`);
  }

  // Normalize
  return normalize(raw, recId, filename, lineNumber);
}

function normalize(raw, recId, sourceFile, lineNumber) {
  const tsRaw = String(raw.timestamp || raw.time || raw.ts || raw.date || '');
  let timestampUtc = null;
  let tzAmbiguous  = false;

  if (tsRaw) {
    const d = new Date(tsRaw);
    if (!isNaN(d.getTime())) {
      timestampUtc = d.toISOString();
      // Flag missing timezone
      tzAmbiguous = !/Z$|[+-]\d{2}:\d{2}$/.test(tsRaw);
    } else {
      tzAmbiguous = true;
    }
  }

  const outcome = normalizeOutcome(String(raw.outcome || raw.status || raw.result || ''));

  return {
    record_id:       recId,
    source_file:     String(sourceFile),
    line_number:     lineNumber,
    timestamp_utc:   timestampUtc,
    timestamp_raw:   escapeHtml(tsRaw.slice(0, 100)),
    tz_ambiguous:    tzAmbiguous,
    account_id:      String(raw.account_id || raw.user || raw.username || raw.account || '').slice(0, 200),
    source_ip:       String(raw.source_ip  || raw.ip  || raw.src_ip || '').slice(0, 45),
    user_agent:      String(raw.user_agent || raw.ua  || '').slice(0, 500),
    outcome,
    event_type:      String(raw.event_type || raw.type || 'login').slice(0, 50),
    raw_line:        escapeHtml(JSON.stringify(raw).slice(0, 500)),
  };
}

function normalizeOutcome(val) {
  const v = val.toLowerCase();
  if (/success|accept|ok|pass|200/.test(v)) return 'success';
  if (/fail|denied|error|reject|invalid|401|403/.test(v)) return 'failure';
  return 'other';
}

// ─── Pseudonymization ─────────────────────────────────────────────────────────

function pseudonymizeRecords(records, salt) {
  const cache = new Map();
  function hash(val) {
    if (!val) return val;
    if (cache.has(val)) return cache.get(val);
    // Simple FNV-1a hash (no crypto API needed in worker context for this purpose)
    const str  = salt + val;
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    const result = 'pseudo-' + (h >>> 0).toString(16).padStart(8, '0');
    cache.set(val, result);
    return result;
  }

  return records.map(r => ({
    ...r,
    account_id: hash(r.account_id),
    source_ip:  r.source_ip ? hash(r.source_ip) : r.source_ip,
  }));
}

// ─── Detection rules ──────────────────────────────────────────────────────────

function runRules(records, T) {
  const matches = [];
  // Group records by account and IP
  const byAccount = groupBy(records, r => r.account_id);
  const byIp      = groupBy(records, r => r.source_ip || '__noip__');

  // Rule 1: Repeated failed logins (per account)
  for (const [account, recs] of byAccount) {
    const windows = findFailureWindows(recs, T.failedLoginN, T.failedLoginWindowM);
    for (const w of windows) {
      matches.push(buildMatch('RULE-01-A', 'Repeated failed logins (per account)', T, {
        account_id: account,
        source_ip:  null,
        facts: `${w.count} failed logins for account ${account} between ${w.start} and ${w.end} UTC`,
        hypothesis: `Pattern consistent with brute-force or credential stuffing targeting account ${account}`,
        alternativeExplanations: ['User forgot password', 'Password manager misconfiguration', 'Shared NAT causing multiple failures'],
        confidence: 'Medium',
        supportingRecords: w.records.map(r => r.record_id),
        params: { N: T.failedLoginN, windowM: T.failedLoginWindowM },
      }));
    }
  }

  // Rule 1 (by IP)
  for (const [ip, recs] of byIp) {
    if (ip === '__noip__') continue;
    const windows = findFailureWindows(recs, T.failedLoginN, T.failedLoginWindowM);
    for (const w of windows) {
      matches.push(buildMatch('RULE-01-I', 'Repeated failed logins (per source IP)', T, {
        account_id: null,
        source_ip:  ip,
        facts: `${w.count} failed logins from IP ${ip} between ${w.start} and ${w.end} UTC`,
        hypothesis: `Pattern consistent with brute-force or credential stuffing from IP ${ip}`,
        alternativeExplanations: ['Shared NAT', 'Load test / monitoring traffic', 'Multiple users on same network'],
        confidence: 'Low',
        supportingRecords: w.records.map(r => r.record_id),
        params: { N: T.failedLoginN, windowM: T.failedLoginWindowM },
      }));
    }
  }

  // Rule 2: Success after repeated failures
  for (const [account, recs] of byAccount) {
    const events = findSuccessAfterFailure(recs, T.successAfterFailN, T.successAfterFailWindowM);
    for (const e of events) {
      matches.push(buildMatch('RULE-02', 'Success after repeated failures', T, {
        account_id: account,
        source_ip:  e.ip,
        facts: `${e.failureCount} failed logins for account ${account} followed by success at ${e.successTime} UTC`,
        hypothesis: `Pattern consistent with successful account compromise after authentication attempts`,
        alternativeExplanations: ['User resolved forgotten password', 'Password reset flow', 'Monitoring system testing'],
        confidence: 'Medium',
        supportingRecords: e.records.map(r => r.record_id),
        params: { N: T.successAfterFailN, windowM: T.successAfterFailWindowM },
      }));
    }
  }

  // Rule 3: Unusual login frequency (per account)
  for (const [account, recs] of byAccount) {
    const hourlyRate = computeHourlyRate(recs);
    if (hourlyRate > T.unusualFreqRatePerHour) {
      matches.push(buildMatch('RULE-03', 'Unusual login frequency', T, {
        account_id: account,
        source_ip:  null,
        facts: `Account ${account} has a login event rate of ~${Math.round(hourlyRate)}/hour (threshold: ${T.unusualFreqRatePerHour})`,
        hypothesis: `Rate may indicate automated activity`,
        alternativeExplanations: ['Load test', 'Integration or CI/CD pipeline', 'Password manager polling'],
        confidence: 'Low',
        supportingRecords: recs.map(r => r.record_id),
        params: { ratePerHour: T.unusualFreqRatePerHour },
      }));
    }
  }

  // Rule 4: Credential spraying — one IP, many accounts
  for (const [ip, recs] of byIp) {
    if (ip === '__noip__') continue;
    const windows = findSprayWindows(recs, T.sprayDistinctAccounts, T.sprayWindowM);
    for (const w of windows) {
      matches.push(buildMatch('RULE-04-A', 'Failures across multiple accounts from one IP (spray-like pattern)', T, {
        account_id: null,
        source_ip:  ip,
        facts: `IP ${ip} had failed logins against ${w.accounts.size} distinct accounts between ${w.start} and ${w.end} UTC`,
        hypothesis: `Pattern consistent with password spraying from IP ${ip}`,
        alternativeExplanations: ['Shared NAT (multiple users)', 'Penetration test', 'MFA or SSO misconfiguration affecting many accounts'],
        confidence: 'Medium',
        supportingRecords: w.records.map(r => r.record_id),
        params: { N: T.sprayDistinctAccounts, windowM: T.sprayWindowM },
      }));
    }

    // Rule 4b: one IP succeeds on many accounts
    const successWindows = findMultiAccountSuccessWindows(recs, T.multiAccountSuccessN, T.multiAccountWindowM);
    for (const w of successWindows) {
      matches.push(buildMatch('RULE-04-B', 'Successful logins to multiple accounts from one IP', T, {
        account_id: null,
        source_ip:  ip,
        facts: `IP ${ip} succeeded on ${w.accounts.size} accounts between ${w.start} and ${w.end} UTC`,
        hypothesis: `Pattern may indicate one actor accessing multiple accounts`,
        alternativeExplanations: ['Shared NAT', 'IT admin performing bulk operations', 'Automated deployment'],
        confidence: 'Low',
        supportingRecords: w.records.map(r => r.record_id),
        params: { N: T.multiAccountSuccessN, windowM: T.multiAccountWindowM },
      }));
    }
  }

  // Rule 5: Unusual access vs. baseline (only if sufficient data)
  for (const [account, recs] of byAccount) {
    const span = getTimeSpanDays(recs);
    if (span < T.baselineMinDays || recs.length < T.baselineMinEvents) {
      // Don't apply this rule — not enough data
      continue;
    }
    // Look for new IPs not seen in first half of the period
    const halfPoint = getMedianTime(recs);
    const earlyIps  = new Set(recs.filter(r => r.timestamp_utc && r.timestamp_utc < halfPoint).map(r => r.source_ip).filter(Boolean));
    const lateRecs  = recs.filter(r => r.timestamp_utc && r.timestamp_utc >= halfPoint);
    for (const rec of lateRecs) {
      if (rec.source_ip && !earlyIps.has(rec.source_ip) && rec.outcome === 'success') {
        matches.push(buildMatch('RULE-05', 'New source IP in baseline comparison', T, {
          account_id: account,
          source_ip:  rec.source_ip,
          facts: `Account ${account} had a successful login from ${rec.source_ip} at ${rec.timestamp_utc}, which was not seen in the earlier baseline period`,
          hypothesis: `New IP not previously seen for this account; may be worth review`,
          alternativeExplanations: ['User traveling', 'New device', 'VPN change', 'ISP change', 'Shared office/network'],
          confidence: 'Low',
          supportingRecords: [rec.record_id],
          params: { minDays: T.baselineMinDays, minEvents: T.baselineMinEvents },
        }));
      }
    }
  }

  return matches;
}

// ─── Rule helpers ─────────────────────────────────────────────────────────────

function findFailureWindows(records, N, windowM) {
  const failures = records.filter(r => r.outcome === 'failure' && r.timestamp_utc).sort(byTime);
  const windows = [];
  const windowMs = windowM * 60_000;

  for (let i = 0; i < failures.length; i++) {
    const start = new Date(failures[i].timestamp_utc).getTime();
    const inWindow = failures.filter(r => {
      const t = new Date(r.timestamp_utc).getTime();
      return t >= start && t <= start + windowMs;
    });
    if (inWindow.length >= N) {
      windows.push({
        count:   inWindow.length,
        start:   failures[i].timestamp_utc,
        end:     inWindow[inWindow.length - 1].timestamp_utc,
        records: inWindow,
      });
      // Skip past this window to avoid duplicate reporting
      i += inWindow.length - 1;
    }
  }
  return windows;
}

function findSuccessAfterFailure(records, N, windowM) {
  const sorted = records.filter(r => r.timestamp_utc).sort(byTime);
  const windowMs = windowM * 60_000;
  const events = [];

  for (const success of sorted.filter(r => r.outcome === 'success')) {
    const st = new Date(success.timestamp_utc).getTime();
    const prior = sorted.filter(r =>
      r.outcome === 'failure' &&
      new Date(r.timestamp_utc).getTime() >= st - windowMs &&
      new Date(r.timestamp_utc).getTime() <  st
    );
    if (prior.length >= N) {
      events.push({
        failureCount: prior.length,
        successTime:  success.timestamp_utc,
        ip:           success.source_ip,
        records:      [...prior, success],
      });
    }
  }
  return events;
}

function computeHourlyRate(records) {
  const withTs = records.filter(r => r.timestamp_utc);
  if (withTs.length < 2) return 0;
  const sorted = withTs.sort(byTime);
  const spanHours = (new Date(sorted[sorted.length-1].timestamp_utc) - new Date(sorted[0].timestamp_utc)) / 3_600_000;
  return spanHours > 0 ? withTs.length / spanHours : 0;
}

function findSprayWindows(records, N, windowM) {
  const failures = records.filter(r => r.outcome === 'failure' && r.timestamp_utc).sort(byTime);
  const windows  = [];
  const windowMs = windowM * 60_000;

  for (let i = 0; i < failures.length; i++) {
    const start = new Date(failures[i].timestamp_utc).getTime();
    const inWindow = failures.filter(r => {
      const t = new Date(r.timestamp_utc).getTime();
      return t >= start && t <= start + windowMs;
    });
    const accounts = new Set(inWindow.map(r => r.account_id).filter(Boolean));
    if (accounts.size >= N) {
      windows.push({
        accounts,
        start:   failures[i].timestamp_utc,
        end:     inWindow[inWindow.length - 1].timestamp_utc,
        records: inWindow,
      });
      i += inWindow.length - 1;
    }
  }
  return windows;
}

function findMultiAccountSuccessWindows(records, N, windowM) {
  const successes = records.filter(r => r.outcome === 'success' && r.timestamp_utc).sort(byTime);
  const windows   = [];
  const windowMs  = windowM * 60_000;

  for (let i = 0; i < successes.length; i++) {
    const start = new Date(successes[i].timestamp_utc).getTime();
    const inWindow = successes.filter(r => {
      const t = new Date(r.timestamp_utc).getTime();
      return t >= start && t <= start + windowMs;
    });
    const accounts = new Set(inWindow.map(r => r.account_id).filter(Boolean));
    if (accounts.size >= N) {
      windows.push({
        accounts,
        start:   successes[i].timestamp_utc,
        end:     inWindow[inWindow.length - 1].timestamp_utc,
        records: inWindow,
      });
      i += inWindow.length - 1;
    }
  }
  return windows;
}

function getTimeSpanDays(records) {
  const withTs = records.filter(r => r.timestamp_utc).sort(byTime);
  if (withTs.length < 2) return 0;
  return (new Date(withTs[withTs.length-1].timestamp_utc) - new Date(withTs[0].timestamp_utc)) / 86_400_000;
}

function getMedianTime(records) {
  const withTs = records.filter(r => r.timestamp_utc).sort(byTime);
  const mid = Math.floor(withTs.length / 2);
  return withTs[mid]?.timestamp_utc || '';
}

function byTime(a, b) {
  return new Date(a.timestamp_utc) - new Date(b.timestamp_utc);
}

function groupBy(arr, keyFn) {
  const map = new Map();
  for (const item of arr) {
    const key = keyFn(item);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(item);
  }
  return map;
}

function buildMatch(ruleId, ruleName, thresholds, details) {
  return {
    match_id:   `${ruleId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    rule_id:    ruleId,
    rule_name:  ruleName,
    params:     details.params,
    account_id: details.account_id,
    source_ip:  details.source_ip,
    observed_facts:     details.facts,
    inferred_behavior:  details.hypothesis,
    alternative_explanations: details.alternativeExplanations,
    confidence: details.confidence,
    recommended_next_steps: [
      'Verify this activity with the account owner.',
      'Review MFA and session records for the affected account.',
      'Check related systems for anomalous activity.',
      'Consider forced password reset and enhanced monitoring under your incident response process.',
      'This tool takes no action itself.',
    ],
    supporting_record_ids: details.supportingRecords,
    wording_note: 'This matches a pattern consistent with suspicious activity. It is NOT a confirmed attack or account compromise.',
  };
}

// ─── Statistics ───────────────────────────────────────────────────────────────

function computeStats(records, errors) {
  const outcomes = { success: 0, failure: 0, other: 0 };
  const accounts = new Set();
  const ips       = new Set();
  let earliest = null, latest = null;

  for (const r of records) {
    outcomes[r.outcome] = (outcomes[r.outcome] || 0) + 1;
    if (r.account_id) accounts.add(r.account_id);
    if (r.source_ip)  ips.add(r.source_ip);
    if (r.timestamp_utc) {
      if (!earliest || r.timestamp_utc < earliest) earliest = r.timestamp_utc;
      if (!latest   || r.timestamp_utc > latest)   latest   = r.timestamp_utc;
    }
  }

  return {
    totalRecords:   records.length,
    parseErrors:    errors.length,
    outcomes,
    distinctAccounts: accounts.size,
    distinctIps:      ips.size,
    earliest,
    latest,
  };
}

// ─── Utility ──────────────────────────────────────────────────────────────────

function escapeHtml(str) {
  if (typeof str !== 'string') return String(str);
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}
